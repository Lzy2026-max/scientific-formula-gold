#!/usr/bin/env python3
from __future__ import annotations
import argparse, csv, json, os, shutil
from pathlib import Path

def first(root: Path, patterns):
    for pat in patterns:
        found=sorted(root.rglob(pat))
        if found: return found[0]
    return None

def link_or_copy(src: Path, dst: Path):
    if dst.exists(): dst.unlink()
    try: os.link(src, dst)
    except OSError: shutil.copy2(src, dst)

def main():
    p=argparse.ArgumentParser(); p.add_argument('--run-root',required=True); p.add_argument('--merged-dir',required=True); p.add_argument('--official-dir',required=True)
    a=p.parse_args(); root=Path(a.run_root); merged=Path(a.merged_dir); out=Path(a.official_dir); out.mkdir(parents=True,exist_ok=True)
    choices={
      'formula_records.jsonl':['ocr_results_merged.jsonl'],
      'formula_trees.jsonl':['formula_trees_merged.jsonl'],
      'parse_failures.jsonl':['parse_failures_merged.jsonl'],
      'cluster_records.csv':['*formula_cluster_records*.csv'],
      'class_counts.csv':['*final_m01_m12_counts*.csv'],
      'low_frequency_patterns.csv':['*low_frequency_pruned_signatures*.csv'],
      'representative_examples.csv':['*representative_examples*.csv'],
      'source_summary.csv':['*source_cluster_summary*.csv'],
      'merge_summary.json':['merge_summary.json'],
      'clustering_report.md':['*clustering_report*.md','*聚类链路与结果汇报*.md'],
    }
    for name,pats in choices.items():
        src=first(merged,pats)
        if src: link_or_copy(src,out/name)
    for src,name in [(root/'run_manifest.json','run_manifest.json'),(root/'index'/'execution_manifest.json','dataset_inventory.json')]:
        link_or_copy(src,out/name)
    print(json.dumps({'official_dir':str(out),'files':sorted(x.name for x in out.iterdir())},ensure_ascii=False,indent=2))
if __name__=='__main__': main()
