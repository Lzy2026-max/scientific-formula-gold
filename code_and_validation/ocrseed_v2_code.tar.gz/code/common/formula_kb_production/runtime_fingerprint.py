#!/usr/bin/env python3
"""Create reproducibility fingerprints for production shard processing."""

from __future__ import annotations

import hashlib
import importlib.metadata
import json
import platform
import sys
from pathlib import Path


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def combined_sha256(paths: list[Path]) -> str:
    digest = hashlib.sha256()
    for path in sorted(paths, key=lambda item: str(item)):
        digest.update(path.name.encode("utf-8"))
        digest.update(sha256_file(path).encode("ascii"))
    return digest.hexdigest()


def read_version(package_dir: Path) -> dict[str, str]:
    values: dict[str, str] = {}
    path = package_dir / "VERSION.txt"
    for line in path.read_text(encoding="utf-8").splitlines():
        if "=" in line:
            key, value = line.split("=", 1)
            values[key.strip()] = value.strip()
    if not values.get("version"):
        raise RuntimeError(f"Missing version in {path}")
    return values


def checkpoint_files() -> list[Path]:
    try:
        import pix2tex
    except Exception:
        return []
    root = Path(pix2tex.__file__).resolve().parent / "model" / "checkpoints"
    return [path for path in (root / "weights.pth", root / "image_resizer.pth") if path.exists()]


def static_fingerprint(package_dir: Path, shard_index: Path | None = None) -> dict[str, object]:
    package_dir = package_dir.resolve()
    engine = package_dir / "scripts" / "formula_engine.py"
    registry = package_dir / "scripts" / "latex_command_registry.py"
    semantic_registry = package_dir / "scripts" / "math_semantic_registry.py"
    parser_rules = package_dir / "scripts" / "parser_rule_library.py"
    pipeline = package_dir / "server_pipeline.py"
    checkpoints = checkpoint_files()
    output: dict[str, object] = {
        "package_version": read_version(package_dir)["version"],
        "formula_engine_sha256": sha256_file(engine),
        "server_pipeline_sha256": sha256_file(pipeline),
        "latex_registry_sha256": sha256_file(registry),
        "semantic_registry_sha256": sha256_file(semantic_registry),
        "parser_rule_library_sha256": sha256_file(parser_rules),
        "quality_config_sha256": combined_sha256([
            pipeline, registry, semantic_registry, parser_rules,
        ]),
        "ocr_checkpoint_sha256": combined_sha256(checkpoints) if checkpoints else "missing",
        "ocr_checkpoint_files": [str(path) for path in checkpoints],
    }
    if shard_index is not None:
        output["shard_index_sha256"] = sha256_file(shard_index)
    return output


def runtime_versions() -> dict[str, object]:
    values: dict[str, object] = {
        "python": sys.version,
        "platform": platform.platform(),
    }
    for package in ("pix2tex", "torch", "Pillow"):
        try:
            values[package] = importlib.metadata.version(package)
        except importlib.metadata.PackageNotFoundError:
            values[package] = "missing"
    try:
        import torch
        values.update({
            "cuda_runtime": torch.version.cuda or "none",
            "cuda_available": torch.cuda.is_available(),
            "gpu": torch.cuda.get_device_name(0) if torch.cuda.is_available() else "none",
        })
    except Exception as exc:
        values["torch_runtime_error"] = repr(exc)
    return values


def write_json(path: Path, value: dict[str, object]) -> None:
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2), encoding="utf-8")
