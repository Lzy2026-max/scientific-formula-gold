import sys
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / "scripts"))

from scripts.latex_command_registry import FUNCTION_COMMANDS
from scripts.math_semantic_registry import (
    FUNCTION_SEMANTICS, INVERSE_TRIG_POWER_ALIASES,
    SPECIAL_NESTED_FUNCTIONS, canonical_function_name,
)
from scripts.parser_rule_library import CONDITION_CONNECTOR_WORDS, ordered_parser_rules


class SemanticRegistryTests(unittest.TestCase):
    def test_latex_functions_have_one_semantic_source(self):
        self.assertEqual(FUNCTION_COMMANDS, set(FUNCTION_SEMANTICS))

    def test_inverse_trig_aliases_are_registered(self):
        for source, target in INVERSE_TRIG_POWER_ALIASES.items():
            self.assertIn(source, FUNCTION_SEMANTICS)
            self.assertIn(target, FUNCTION_SEMANTICS)

    def test_arc_spellings_have_canonical_inverse_names(self):
        self.assertEqual(canonical_function_name("arcsin"), "asin")
        self.assertEqual(canonical_function_name("arctan"), "atan")

    def test_m08_policy_does_not_include_inverse_trig(self):
        self.assertIn("sin", SPECIAL_NESTED_FUNCTIONS)
        self.assertIn("asin", SPECIAL_NESTED_FUNCTIONS)
        self.assertNotEqual(FUNCTION_SEMANTICS["asin"]["classification"], "m08_candidate")

    def test_parser_rules_are_unique_and_priority_ordered(self):
        rules = ordered_parser_rules()
        self.assertEqual(list(rules), sorted(rules, key=lambda item: item["priority"]))
        self.assertEqual(len({rule["id"] for rule in rules}), len(rules))
        self.assertIn("where", CONDITION_CONNECTOR_WORDS)


if __name__ == "__main__":
    unittest.main()
