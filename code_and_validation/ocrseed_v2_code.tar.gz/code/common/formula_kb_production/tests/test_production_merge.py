import importlib.util
import json
import sys
import tempfile
import unittest
from pathlib import Path
from unittest import mock


ROOT = Path(__file__).resolve().parents[1]
SPEC = importlib.util.spec_from_file_location("merge_full_formula_results", ROOT / "merge_full_formula_results.py")
MERGE = importlib.util.module_from_spec(SPEC)
assert SPEC.loader is not None
SPEC.loader.exec_module(MERGE)


def write_jsonl(path, rows):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text("".join(json.dumps(row) + "\n" for row in rows), encoding="utf-8")


class ProductionMergeTests(unittest.TestCase):
    def test_incomplete_worker_is_refused_and_never_merged(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            index = root / "index"
            shard1 = index / "formula_index_shard_00001.jsonl"
            shard2 = index / "formula_index_shard_00002.jsonl"
            write_jsonl(shard1, [{"formula_id": "F1"}])
            write_jsonl(shard2, [{"formula_id": "F2"}])
            manifest = index / "full_index_manifest.json"
            manifest.write_text(json.dumps({
                "formula_images": 2,
                "shard_count": 2,
                "shards": [
                    {"shard_no": 1, "path": str(shard1), "records": 1},
                    {"shard_no": 2, "path": str(shard2), "records": 1},
                ],
            }), encoding="utf-8")
            current = {
                "package_version": "test", "formula_engine_sha256": "engine",
                "server_pipeline_sha256": "pipeline", "latex_registry_sha256": "registry",
                "quality_config_sha256": "quality", "ocr_checkpoint_sha256": "checkpoint",
            }
            worker = root / "run" / "workers" / "slot_00" / "shard1"
            write_jsonl(worker / "ocr_results.jsonl", [{"formula_id": "F1"}])
            write_jsonl(worker / "extraction_errors.jsonl", [])
            write_jsonl(worker / "formula_analysis" / "formula_trees.jsonl", [{
                "formula_id": "F1", "tags": [], "record_status": "valid_no_target_pattern",
            }])
            write_jsonl(worker / "formula_analysis" / "parse_failures.jsonl", [])
            marker = {
                "schema_version": 2, "status": "complete", "shard_index": str(shard1),
                "input_records": 1, "accounted_records": 1,
                "fingerprint": {**current, "shard_index_sha256": MERGE.sha256_file(shard1)},
            }
            (worker / "SHARD_COMPLETE.json").write_text(json.dumps(marker), encoding="utf-8")
            base_args = [
                "merge_full_formula_results.py", "--run-root", str(root / "run"),
                "--output-dir", str(root / "merged"), "--package-dir", str(ROOT),
                "--index-manifest", str(manifest),
            ]
            with mock.patch.object(MERGE, "static_fingerprint", return_value=current), mock.patch.object(sys, "argv", base_args):
                with self.assertRaises(SystemExit):
                    MERGE.main()
            with mock.patch.object(MERGE, "static_fingerprint", return_value=current), mock.patch.object(
                sys, "argv", base_args + ["--allow-incomplete"],
            ):
                MERGE.main()
            summary = json.loads((root / "merged" / "merge_summary.json").read_text(encoding="utf-8"))
            self.assertFalse(summary["official_output"])
            self.assertEqual(summary["completed_shards"], 1)
            self.assertEqual(summary["ocr_records"], 1)
            self.assertEqual(summary["missing_shards"], [shard2.name])


if __name__ == "__main__":
    unittest.main()
