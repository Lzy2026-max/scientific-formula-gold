from __future__ import annotations

import importlib.util
import json
import sys
import tempfile
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location("production_v3_engine", ROOT / "scripts/formula_engine.py")
ENGINE = importlib.util.module_from_spec(spec)
sys.modules["production_v3_engine"] = ENGINE
assert spec.loader is not None
spec.loader.exec_module(ENGINE)

server_spec = importlib.util.spec_from_file_location("production_v3_server", ROOT / "server_pipeline.py")
SERVER = importlib.util.module_from_spec(server_spec)
sys.modules["production_v3_server"] = SERVER
assert server_spec.loader is not None
server_spec.loader.exec_module(SERVER)


class ProductionV3SemanticTests(unittest.TestCase):
    def parse(self, latex):
        return ENGINE.parse_formula_with_ocr_fallback(latex)

    def test_spacing_and_formatting_keep_function_boundaries(self):
        _normalized, tree, diagnostics = self.parse(r"d\ln\nu+\beta\mathrm{cos}\theta+\chi\,E")
        preorder = tree.preorder()
        self.assertIn("(ln nu)", preorder)
        self.assertIn("(* beta (cos theta))", preorder)
        self.assertIn("(* chi E)", preorder)
        self.assertEqual(diagnostics.tree_fidelity_status, "passed")

    def test_function_power_attaches_to_function_call(self):
        _normalized, tree, _diagnostics = self.parse(r"y=\cos^{2}\theta")
        self.assertIn("(^ (cos theta) 2)", tree.preorder())

    def test_symbolic_subscripted_function_call(self):
        _normalized, tree, diagnostics = self.parse(r"y=F_L(t)+x_{c,ss}(t)")
        self.assertIn("(F_L t)", tree.preorder())
        self.assertIn("(x_c_ss t)", tree.preorder())
        self.assertEqual(diagnostics.tree_fidelity_status, "passed")

    def test_relation_chain_preserves_all_operators_and_operands(self):
        _normalized, tree, diagnostics = self.parse(r"A=B\simeq C")
        self.assertEqual(tree.kind, "relation_chain")
        self.assertEqual(tree.attributes["operators"], ["=", "~="])
        self.assertEqual(tree.attributes["derived_terminal_relation"], "~=")
        self.assertEqual(len(tree.children), 3)
        self.assertEqual(diagnostics.raw_structure_signature["relations"], ["=", "~="])
        self.assertEqual(ENGINE.normalize_latex(ENGINE.normalize_latex(r"A=B\simeq C")), ENGINE.normalize_latex(r"A=B\simeq C"))

    def test_multiple_expressions_are_not_silently_truncated(self):
        _normalized, tree, diagnostics = self.parse(r"A=B;C=D")
        self.assertEqual(tree.kind, "expression_bundle")
        self.assertEqual(len(tree.children), 2)
        self.assertEqual(diagnostics.raw_expression_count, 2)
        self.assertEqual(diagnostics.parsed_expression_count, 2)

    def test_m08_stays_strict(self):
        _, simple_tree, _ = self.parse(r"y=\sin(\theta)")
        _, nested_tree, _ = self.parse(r"y=\sin(x+y)")
        _, _, simple_tags = ENGINE.classify(simple_tree)
        _, _, nested_tags = ENGINE.classify(nested_tree)
        self.assertNotIn("M08_sin_nested", simple_tags["formula_level_tags"])
        self.assertIn("M08_sin_nested", nested_tags["formula_level_tags"])

    def test_normalization_is_idempotent(self):
        once = ENGINE.normalize_latex(r"y=\beta\cos\theta+x^{n+1}")
        twice = ENGINE.normalize_latex(once)
        self.assertEqual(once, twice)

    def test_audit_ignores_tex_spacing(self):
        self.assertEqual(ENGINE.raw_structure_signature(r"x~+~y")["relations"], [])
        self.assertEqual(
            ENGINE.raw_structure_signature(r"A\;=\;B")["top_level_expression_count"],
            1,
        )
        _normalized, _tree, diagnostics = self.parse(r"A\;=\;B")
        self.assertEqual(diagnostics.tree_fidelity_status, "passed")

    def test_multiletter_script_atoms_are_idempotent(self):
        samples = (
            r"x_{c,ss}(t)",
            r"m=\sqrt{\frac{1}{N_\phi}S(Q)}",
            r"E_{\mathrm{Al-Al}}+E_{\mathrm{Si-Si}}",
            r"\Gamma_i+\jmath+\imath",
        )
        for raw in samples:
            with self.subTest(raw=raw):
                first = ENGINE.normalize_latex(raw)
                self.assertEqual(ENGINE.normalize_latex(first), first)
        normalized, tree, _diagnostics = self.parse(r"m=\sqrt{\frac{1}{N_\phi}S(Q)}")
        self.assertIn("N_phi", normalized)
        self.assertIn("N_phi", tree.preorder())
        normalized, _tree, _diagnostics = self.parse(r"E_{\mathrm{Al-Al}}+E_{\mathrm{Si-Si}}")
        self.assertIn("E_Al_Al", normalized)
        self.assertIn("E_Si_Si", normalized)

    def test_coefficients_before_groups_are_products_not_functions(self):
        expected = {
            r"V\frac{x}{y}": "(* V (/ x y))",
            r"A[(x+y)^2]": "(* A (^ (+ x y) 2))",
            r"C_G(V_{GS}-V_T)^2": "(* C_G (^ (- V_GS V_T) 2))",
            r"a*C_G(V_{GS}-V_T)^2": "(* (* a C_G) (^ (- V_GS V_T) 2))",
            r"k_F(r-r_0)": "(* k_F (- r r_0))",
            r"y=\cos(2k_F(r-r_0))": "(= y (cos (* (* 2 k_F) (- r r_0))))",
        }
        for raw, preorder in expected.items():
            with self.subTest(raw=raw):
                _normalized, tree, diagnostics = self.parse(raw)
                self.assertEqual(tree.preorder(), preorder)
                self.assertFalse(any(
                    reason.startswith("function_created:")
                    for reason in diagnostics.tree_fidelity_reasons
                ))

    def test_formatted_subscripts_stay_single_atoms(self):
        raw = r"E_{\mathrm{tip}(\mathrm{Al})-\mathrm{Al}}+E_{\mathrm{Al-A}}"
        normalized, tree, diagnostics = self.parse(raw)
        self.assertIn("E_tip_Al_Al", normalized)
        self.assertIn("E_Al_A", normalized)
        self.assertIn("E_tip_Al_Al", tree.preorder())
        self.assertEqual(ENGINE.normalize_latex(normalized), normalized)
        self.assertEqual(diagnostics.tree_fidelity_status, "passed")

    def test_spaced_ocr_function_name_is_repaired(self):
        normalized, tree, diagnostics = self.parse(r"y=e x p(-A t)")
        self.assertEqual(normalized, "y=exp(-A*t)")
        self.assertEqual(tree.preorder(), "(= y (exp (* (neg A) t)))")
        self.assertEqual(diagnostics.tree_fidelity_status, "passed")

    def test_known_and_symbolic_function_calls_remain_calls(self):
        _normalized, tree, diagnostics = self.parse(r"F_p(z)+x_{c,ss}(t)")
        self.assertIn("(F_p z)", tree.preorder())
        self.assertIn("(x_c_ss t)", tree.preorder())
        self.assertEqual(diagnostics.tree_fidelity_status, "passed")
        _normalized, tree, diagnostics = self.parse(r"\cos\theta(V)")
        self.assertEqual(tree.preorder(), "(cos (theta V))")
        self.assertEqual(diagnostics.tree_fidelity_status, "passed")

    def test_resume_manifest_rejects_changed_fingerprint(self):
        with tempfile.TemporaryDirectory() as directory:
            manifest = Path(directory) / "stage.json"
            SERVER.validate_or_write_stage_manifest(manifest, {"version": 1}, False)
            SERVER.validate_or_write_stage_manifest(manifest, {"version": 1}, True)
            with self.assertRaises(SystemExit):
                SERVER.validate_or_write_stage_manifest(manifest, {"version": 2}, True)

    def test_repeated_low_diversity_ocr_is_suspicious(self):
        latex = (
            r"\mathrm{\Omega}=1\mathrm{\Omega}\mathrm{\Omega}"
            r"\mathrm{\Omega}\mathrm{\Omega}\mathrm{\Omega}_{1}"
        )
        quality = SERVER.assess_ocr_quality(latex)
        self.assertEqual(quality["ocr_quality_status"], "suspicious")
        self.assertIn("repeated_low_diversity_math_symbol:Omega", quality["ocr_quality_reasons"])

    def test_formula_connectors_create_expression_bundle(self):
        normalized, tree, diagnostics = self.parse(
            r"K=\sqrt{2}\,o r D=2\delta^2K^{-2}"
        )
        self.assertEqual(tree.kind, "expression_bundle")
        self.assertEqual(len(tree.children), 2)
        self.assertNotIn("o*r", normalized)
        self.assertEqual(diagnostics.raw_expression_count, 2)
        self.assertEqual(diagnostics.parsed_expression_count, 2)

    def test_formatted_connector_is_not_a_variable_product(self):
        normalized, tree, diagnostics = self.parse(
            r"A=B\quad\mathrm{or}\quad C=D"
        )
        self.assertEqual(normalized, "A=B;C=D")
        self.assertEqual(tree.kind, "expression_bundle")
        self.assertEqual(diagnostics.tree_fidelity_status, "passed")

    def test_reported_subscript_forms_remain_atomic(self):
        normalized, tree, diagnostics = self.parse(
            r"q_{\mathrm{res}}+\sigma_{\theta}+I_{P h 0}"
        )
        self.assertEqual(normalized, "q_res+sigma_theta+I_P_h_0")
        self.assertEqual(tree.preorder(), "(+ (+ q_res sigma_theta) I_P_h_0)")
        self.assertEqual(diagnostics.tree_fidelity_status, "passed")

    def test_ambiguous_symbolic_call_is_retained_but_not_core(self):
        row = {
            "formula_id": "T_AMBIGUOUS",
            "source_id": "T",
            "formula_latex": r"y=L(H)+P(E)",
            "raw_text": r"y=L(H)+P(E)",
            "extraction_method": "server_formula_image_pix2tex",
            "image_screen_status": "formula_candidate",
            "ocr_quality_status": "passed",
        }
        results, _tags, _sources, failures = ENGINE.process_formulas([row])
        self.assertFalse(failures)
        self.assertEqual(results[0]["record_status"], "ambiguous_symbolic_call")
        self.assertEqual(results[0]["validity_status"], "excluded_from_core_stats")
        self.assertEqual(results[0]["exclude_reason"], "ambiguous_symbolic_call")
        self.assertEqual(results[0]["ambiguous_symbolic_calls"], ["L", "P"])

    def test_multiline_image_single_expression_is_suspicious(self):
        quality = SERVER.assess_ocr_quality(
            r"A=B",
            {"independent_formula_row_bands": 2},
        )
        self.assertEqual(quality["ocr_quality_status"], "suspicious")
        self.assertIn("multiline_image_single_expression_ocr", quality["ocr_quality_reasons"])

    def test_conditions_are_saved_but_not_classified(self):
        normalized, tree, diagnostics = self.parse(
            r"y=\sin(x+z)\quad\mathrm{where}\quad x>0"
        )
        self.assertEqual(normalized, "y=sin(x+z)")
        self.assertNotEqual(tree.kind, "expression_bundle")
        self.assertEqual(diagnostics.condition_connector, "where")
        self.assertEqual(diagnostics.condition_spans, [r"\quad x>0"])
        tags = ENGINE.classify(tree)[2]["formula_level_tags"]
        self.assertIn("M08_sin_nested", tags)

    def test_for_condition_does_not_pollute_main_tree(self):
        normalized, tree, diagnostics = self.parse(r"F(x)=x^2 for x>0")
        self.assertEqual(normalized, "F(x)=x^2")
        self.assertNotIn("x>0", tree.preorder())
        self.assertEqual(diagnostics.condition_connector, "for")

    def test_multiletter_identifiers_remain_atomic(self):
        for raw, atom in (
            (r"Vinitial=Vfinal", "Vinitial"),
            (r"\mathrm{FWHM}=\mathsf{FSPG}", "FWHM"),
            (r"\text{Attenuation}=x", "Attenuation"),
        ):
            normalized, tree, diagnostics = self.parse(raw)
            self.assertIn(atom, normalized)
            self.assertIn(atom, tree.preorder())
            self.assertEqual(diagnostics.tree_fidelity_status, "passed")

    def test_inverse_trig_notation_is_not_reciprocal_power(self):
        normalized, tree, diagnostics = self.parse(r"y=\sin^{-1}(x)")
        self.assertEqual(normalized, "y=asin(x)")
        self.assertEqual(tree.preorder(), "(= y (asin x))")
        self.assertNotIn("(^", tree.preorder())
        self.assertEqual(diagnostics.tree_fidelity_status, "passed")
        tags = ENGINE.classify(tree)[2]["formula_level_tags"]
        self.assertNotIn("M08_sin_nested", tags)
        self.assertNotIn("M10_universal_multiplicative", tags)

    def test_named_inverse_trig_functions_pass_fidelity_audit(self):
        for raw in (r"y=\arctan(x)", r"y=\mathrm{arcsin}(x)"):
            _normalized, tree, diagnostics = self.parse(raw)
            self.assertEqual(diagnostics.tree_fidelity_status, "passed")
            self.assertNotIn("M08_sin_nested", ENGINE.classify(tree)[2]["formula_level_tags"])


if __name__ == "__main__":
    unittest.main()
