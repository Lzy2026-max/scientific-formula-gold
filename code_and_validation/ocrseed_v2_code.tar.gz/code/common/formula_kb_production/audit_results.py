#!/usr/bin/env python3
from __future__ import annotations
import argparse, csv, hashlib, json
from collections import Counter
from pathlib import Path

def rows(path):
    with path.open(encoding='utf-8') as f:
        for line in f:
            if line.strip(): yield json.loads(line)

def main():
    p=argparse.ArgumentParser(); p.add_argument('--run-root',required=True); p.add_argument('--official-dir',required=True); a=p.parse_args()
    root=Path(a.run_root); out=Path(a.official_dir); inv=json.loads((out/'dataset_inventory.json').read_text(encoding='utf-8'))
    expected=inv['sample_count']; complete=len(list((root/'workers').rglob('SHARD_COMPLETE.json')))
    ids=set(); duplicate=0; coverage=Counter(); count=0
    for r in rows(out/'formula_records.jsonl'):
        count+=1; fid=r.get('formula_id','')
        if fid in ids: duplicate+=1
        ids.add(fid)
        for key in ('source_id','archive_name','archive_member','title','authors','equation_number','page'):
            if r.get(key) not in ('',None,[]): coverage[key]+=1
    summary={
      'audit_status':'PASS' if count==expected and duplicate==0 and complete==inv['shard_count'] else 'FAIL',
      'expected_formula_records':expected,'actual_formula_records':count,'duplicate_formula_ids':duplicate,
      'expected_shards':inv['shard_count'],'completed_shards':complete,
      'provenance_coverage':{k:{'present':v,'rate':round(v/count,6) if count else 0} for k,v in sorted(coverage.items())},
      'page_note':'Blank page fields mean unavailable in source archives; values were not fabricated.'
    }
    (out/'audit_summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding='utf-8')
    with (out/'provenance_coverage.csv').open('w',encoding='utf-8-sig',newline='') as f:
        w=csv.writer(f); w.writerow(['field','present','total','coverage_rate'])
        for k,v in sorted(coverage.items()): w.writerow([k,v,count,round(v/count,6) if count else 0])
    report=f"""# Formula Corpus Processing Report

## Audit status

{summary['audit_status']}

## Dataset and processing

- Formula image records: {count:,} / {expected:,}
- Completed immutable shards: {complete} / {inv['shard_count']}
- Duplicate stable formula IDs: {duplicate}
- OCR, formula trees, parse failures, clustering records, M01-M12 counts and source provenance are supplied as separate files.
- Page numbers remain blank when the source archive does not provide a reliable page mapping.

## Reproducibility

The release records the frozen package checksums, deterministic execution manifest, stable source/formula IDs, worker mapping, merge summary and final output checksums.
"""
    (out/'final_report.md').write_text(report,encoding='utf-8')
    with (out/'checksums.sha256').open('w',encoding='utf-8',newline='\n') as f:
        for path in sorted(out.iterdir()):
            if path.is_file() and path.name!='checksums.sha256':
                f.write(f"{hashlib.sha256(path.read_bytes()).hexdigest()}  {path.name}\n")
    print(json.dumps(summary,ensure_ascii=False,indent=2))
    if summary['audit_status']!='PASS': raise SystemExit(1)
if __name__=='__main__': main()
