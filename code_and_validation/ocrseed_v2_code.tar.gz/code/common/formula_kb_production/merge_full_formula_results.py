#!/usr/bin/env python3
"""Strictly merge validated, complete shard outputs by stable formula ID."""

from __future__ import annotations

import argparse
import json
import subprocess
import sys
from collections import Counter
from pathlib import Path

from runtime_fingerprint import sha256_file, static_fingerprint


def read_jsonl(path: Path):
    with path.open(encoding="utf-8-sig", errors="replace") as handle:
        for line in handle:
            if line.strip():
                yield json.loads(line)


def expected_shards(manifest_path: Path) -> tuple[dict, dict[str, dict]]:
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    shards = {Path(str(item["path"])).name: item for item in manifest.get("shards", [])}
    if len(shards) != int(manifest.get("shard_count", -1)):
        raise SystemExit("Index manifest shard_count does not match shard list")
    return manifest, shards


def validate_marker(marker_path: Path, expected: dict, current: dict) -> tuple[bool, str]:
    try:
        marker = json.loads(marker_path.read_text(encoding="utf-8"))
    except Exception as exc:
        return False, f"invalid_json:{exc!r}"
    if marker.get("status") != "complete" or marker.get("schema_version") != 2:
        return False, "not_complete_schema_v2"
    if marker.get("input_records") != int(expected.get("records", -1)):
        return False, "input_record_count_mismatch"
    if marker.get("accounted_records") != marker.get("input_records"):
        return False, "worker_count_conservation_failed"
    shard_path = Path(str(marker.get("shard_index", "")))
    if shard_path.name != Path(str(expected["path"])).name or not shard_path.exists():
        return False, "shard_index_path_mismatch_or_missing"
    fingerprint = marker.get("fingerprint", {})
    if fingerprint.get("shard_index_sha256") != sha256_file(shard_path):
        return False, "shard_index_sha256_mismatch"
    for key in (
        "package_version", "formula_engine_sha256", "server_pipeline_sha256",
        "latex_registry_sha256", "semantic_registry_sha256",
        "parser_rule_library_sha256", "quality_config_sha256",
    ):
        if fingerprint.get(key) != current.get(key):
            return False, f"fingerprint_mismatch:{key}"
    if not fingerprint.get("ocr_checkpoint_sha256") or fingerprint.get("ocr_checkpoint_sha256") == "missing":
        return False, "missing_ocr_checkpoint_fingerprint"
    return True, "ok"


def merge_files(paths: list[Path], output: Path, id_key: str) -> tuple[int, int, set[str]]:
    seen: set[str] = set()
    written = duplicates = 0
    with output.open("w", encoding="utf-8") as handle:
        for path in paths:
            if not path.exists():
                continue
            for row in read_jsonl(path):
                key = str(row.get(id_key, "") or "")
                if not key:
                    raise SystemExit(f"Missing {id_key} in {path}")
                if key in seen:
                    duplicates += 1
                    continue
                seen.add(key)
                handle.write(json.dumps(row, ensure_ascii=False) + "\n")
                written += 1
    return written, duplicates, seen


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--run-root", required=True)
    parser.add_argument("--output-dir", required=True)
    parser.add_argument("--package-dir", required=True)
    parser.add_argument("--index-manifest", required=True)
    parser.add_argument("--run-clustering", action="store_true")
    parser.add_argument("--allow-incomplete", action="store_true")
    parser.add_argument("--min-support", type=int, default=5)
    args = parser.parse_args()
    run_root = Path(args.run_root).expanduser().resolve()
    output_dir = Path(args.output_dir).expanduser().resolve()
    package_dir = Path(args.package_dir).expanduser().resolve()
    manifest_path = Path(args.index_manifest).expanduser().resolve()
    output_dir.mkdir(parents=True, exist_ok=True)

    manifest, expected = expected_shards(manifest_path)
    current = static_fingerprint(package_dir)
    valid_workers: list[Path] = []
    invalid_markers: list[dict[str, str]] = []
    completed_names: set[str] = set()
    checkpoint_hashes: set[str] = set()
    for marker_path in sorted(run_root.glob("workers/**/SHARD_COMPLETE.json")):
        try:
            marker = json.loads(marker_path.read_text(encoding="utf-8"))
        except Exception as exc:
            invalid_markers.append({"path": str(marker_path), "reason": f"invalid_json:{exc!r}"})
            continue
        shard_name = Path(str(marker.get("shard_index", ""))).name
        if shard_name not in expected:
            invalid_markers.append({"path": str(marker_path), "reason": "unexpected_shard"})
            continue
        valid, reason = validate_marker(marker_path, expected[shard_name], current)
        if not valid:
            invalid_markers.append({"path": str(marker_path), "reason": reason})
            continue
        if shard_name in completed_names:
            invalid_markers.append({"path": str(marker_path), "reason": "duplicate_completed_shard"})
            continue
        completed_names.add(shard_name)
        checkpoint_hashes.add(str(marker["fingerprint"]["ocr_checkpoint_sha256"]))
        valid_workers.append(marker_path.parent)

    missing_shards = sorted(set(expected) - completed_names)
    if len(checkpoint_hashes) > 1:
        raise SystemExit("Completed workers used different OCR checkpoint fingerprints")
    if (missing_shards or invalid_markers) and not args.allow_incomplete:
        raise SystemExit(
            f"Strict merge refused: completed={len(valid_workers)}/{len(expected)} "
            f"missing={missing_shards[:10]} invalid={invalid_markers[:5]}"
        )
    if not valid_workers:
        raise SystemExit("No validated completed shard outputs found")

    tree_paths = [worker / "formula_analysis" / "formula_trees.jsonl" for worker in valid_workers]
    parse_failure_paths = [worker / "formula_analysis" / "parse_failures.jsonl" for worker in valid_workers]
    ocr_paths = [worker / "ocr_results.jsonl" for worker in valid_workers]
    error_paths = [worker / "extraction_errors.jsonl" for worker in valid_workers]
    trees_out = output_dir / "formula_trees_merged.jsonl"
    failures_out = output_dir / "parse_failures_merged.jsonl"
    ocr_out = output_dir / "ocr_results_merged.jsonl"
    errors_out = output_dir / "extraction_errors_merged.jsonl"
    tree_count, tree_duplicates, tree_ids = merge_files(tree_paths, trees_out, "formula_id")
    failure_count, failure_duplicates, failure_ids = merge_files(parse_failure_paths, failures_out, "formula_id")
    ocr_count, ocr_duplicates, ocr_ids = merge_files(ocr_paths, ocr_out, "formula_id")
    error_count, error_duplicates, error_ids = merge_files(error_paths, errors_out, "formula_id")

    expected_ids: set[str] = set()
    for shard_name in completed_names:
        for row in read_jsonl(Path(str(expected[shard_name]["path"]))):
            formula_id = str(row.get("formula_id", "") or "")
            if not formula_id or formula_id in expected_ids:
                raise SystemExit(f"Invalid or duplicate formula_id in index: {formula_id!r}")
            expected_ids.add(formula_id)
    if ocr_ids & error_ids:
        raise SystemExit("A formula_id occurs in both merged OCR and extraction errors")
    accounted_ids = ocr_ids | error_ids
    if accounted_ids != expected_ids:
        raise SystemExit(
            f"Global count conservation failed missing={len(expected_ids-accounted_ids)} "
            f"extra={len(accounted_ids-expected_ids)}"
        )
    if not tree_ids.issubset(ocr_ids) or not failure_ids.issubset(ocr_ids):
        raise SystemExit("Analysis output contains formula IDs absent from OCR output")
    if any((tree_duplicates, failure_duplicates, ocr_duplicates, error_duplicates)):
        raise SystemExit("Duplicate formula IDs detected during strict merge")

    tags = Counter()
    primary = Counter()
    statuses = Counter()
    for row in read_jsonl(trees_out):
        tags.update(row.get("tags", []))
        primary.update([row.get("primary_tag", "") or "unassigned"])
        statuses.update([row.get("record_status", "unknown")])
    official = not args.allow_incomplete and len(completed_names) == len(expected)
    summary = {
        "official_output": official,
        "index_manifest": str(manifest_path),
        "index_manifest_sha256": sha256_file(manifest_path),
        "expected_shards": len(expected),
        "completed_shards": len(valid_workers),
        "missing_shards": missing_shards,
        "invalid_markers": invalid_markers,
        "expected_formula_records": len(expected_ids),
        "accounted_formula_records": len(accounted_ids),
        "tree_records": tree_count,
        "parse_failures": failure_count,
        "ocr_records": ocr_count,
        "extraction_errors": error_count,
        "ocr_checkpoint_sha256": next(iter(checkpoint_hashes)),
        "m01_m12_multilabel_counts": dict(sorted(tags.items())),
        "primary_class_counts": dict(sorted(primary.items())),
        "record_status_counts": dict(sorted(statuses.items())),
        "formula_trees": str(trees_out),
        "ocr_results": str(ocr_out),
    }
    path = output_dir / "merge_summary.json"
    path.write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(summary, ensure_ascii=False, indent=2))
    if args.run_clustering:
        if not official:
            raise SystemExit("Global clustering is blocked for incomplete, non-official merge output")
        subprocess.run([
            sys.executable, str(package_dir / "scripts" / "hierarchical_clustering.py"),
            "--root", str(output_dir), "--min-support", str(args.min_support),
            "--input", f"full_dataset={trees_out}",
        ], check=True)
        print("global_clustering_complete")


if __name__ == "__main__":
    main()
