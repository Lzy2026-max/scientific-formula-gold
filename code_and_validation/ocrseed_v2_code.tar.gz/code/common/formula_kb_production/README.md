# Formula KB Production Release v1

This package processes every Formula image in the configured archives with deterministic indexing, nine immutable workers, resumable OCR/analysis, strict merge, global clustering and M01-M12 statistics.

Official deliverables are written under `official_results/`. Source metadata and archive locators are retained. PDF page numbers are left blank when the supplied archives do not contain a reliable image-to-page mapping.

The release uses 3 GPUs, each with three workers. Completed shards are never recomputed. Finalization refuses missing, invalid or duplicate records.
