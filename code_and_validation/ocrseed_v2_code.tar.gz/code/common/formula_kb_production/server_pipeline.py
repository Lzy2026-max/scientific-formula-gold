#!/usr/bin/env python3
"""Server runner for the fixed formula extraction and clustering pipeline."""

from __future__ import annotations

import argparse
import csv
import difflib
import hashlib
import importlib.util
import json
import os
import re
import shutil
import subprocess
import sys
import tarfile
import time
import zipfile
from collections import Counter
from itertools import groupby
from pathlib import Path
from typing import Any, Dict, Iterable, Iterator, Optional

SCRIPTS_DIR = Path(__file__).resolve().parent / "scripts"
if str(SCRIPTS_DIR) not in sys.path:
    sys.path.insert(0, str(SCRIPTS_DIR))
from latex_command_registry import ALL_KNOWN_COMMANDS, REGISTRY_VERSION


IMAGE_EXTENSIONS = {".png", ".jpg", ".jpeg", ".bmp", ".tif", ".tiff", ".webp"}
ARCHIVE_EXTENSIONS = (".zip", ".tar", ".tar.gz", ".tgz", ".tar.bz2", ".tbz2", ".tar.xz", ".txz", ".rar", ".7z")
TITLE_KEYS = ("title", "article_title", "paper_title", "name", "题目", "标题")
AUTHOR_KEYS = ("authors", "author", "creator", "作者")
ID_KEYS = ("doi", "arxiv_id", "article_id", "paper_id", "id", "编号")
JOURNAL_KEYS = ("journal", "venue", "conference", "期刊", "会议")
YEAR_KEYS = ("year", "publication_year", "date", "published", "年份")
STRICT_OCR_SIMILARITY = 0.70


def independent_formula_row_bands(rows: list[int], width: int, height: int) -> list[tuple[int, int, int]]:
    """Find substantial formula rows separated by a real whitespace valley.

    Fraction numerators and denominators are normally joined by a fraction bar.
    We therefore merge nearby active bands and retain only bands carrying a
    meaningful share of the foreground.  This is a conservative loss detector,
    not an automatic line cropper.
    """
    if not rows or height < 70:
        return []
    active_threshold = max(2, int(width * 0.008))
    raw_bands = []
    start = None
    for index, active in enumerate([value >= active_threshold for value in rows] + [False]):
        if active and start is None:
            start = index
        elif not active and start is not None:
            if index - start >= 3:
                raw_bands.append([start, index - 1, sum(rows[start:index])])
            start = None
    if not raw_bands:
        return []
    minimum_gap = max(7, int(height * 0.035))
    merged = [raw_bands[0]]
    for band in raw_bands[1:]:
        gap = band[0] - merged[-1][1] - 1
        if gap < minimum_gap:
            merged[-1][1] = band[1]
            merged[-1][2] += band[2]
        else:
            merged.append(band)
    foreground = max(1, sum(rows))
    substantial = [
        tuple(band) for band in merged
        if band[2] >= foreground * 0.18 and band[1] - band[0] + 1 >= max(5, int(height * 0.12))
    ]
    return substantial


def filename_candidate_metadata(name: str) -> Dict[str, str]:
    """Preserve upstream Formula filename hints without treating them as calibrated truth."""
    stem = Path(name).stem
    lowered = stem.lower()
    score_match = re.search(r"(?:^|\s)(0(?:\.\d+)?|1(?:\.0+)?)(?=$|\s)", stem)
    return {
        "upstream_formula_label": "unknown" if "formula unknown" in lowered else "formula_candidate",
        "upstream_formula_score_raw": score_match.group(1) if score_match else "",
    }


def screen_formula_image(image_path: Path, upstream_label: str) -> Dict[str, str]:
    """Three-state formula-image gate with auditable visual measurements.

    The upstream folder/file label is a candidate label, not ground truth.  The
    metrics are retained so later manual labels can calibrate a real classifier.
    """
    try:
        from PIL import Image
        with Image.open(image_path) as source:
            rgb = source.convert("RGB")
            rgb.thumbnail((384, 384))
            width, height = rgb.size
            pixels = list(rgb.getdata())
    except Exception as exc:
        return {
            "image_screen_status": "formula_candidate_strict",
            "image_screen_reason": "image_read_error",
            "image_screen_metrics": json.dumps({"error": str(exc)}, ensure_ascii=False),
        }

    total = max(width * height, 1)
    dark = []
    colored = 0
    white = 0
    midtone = 0
    luminance_bins = [0] * 16
    for r, g, b in pixels:
        luminance = (r + g + b) / 3
        dark.append(1 if luminance < 180 else 0)
        white += luminance >= 242
        midtone += 55 <= luminance < 220
        luminance_bins[min(15, int(luminance // 16))] += 1
        if max(r, g, b) - min(r, g, b) > 35 and max(r, g, b) < 245:
            colored += 1
    dark_ratio = sum(dark) / total
    color_ratio = colored / total
    white_ratio = white / total
    midtone_ratio = midtone / total
    populated_luminance_bins = sum(value >= max(2, total * 0.002) for value in luminance_bins)
    rows = [sum(dark[y * width:(y + 1) * width]) for y in range(height)]
    cols = [sum(dark[x::width]) for x in range(width)]
    long_horizontal = sum(value >= width * 0.68 for value in rows)
    long_vertical = sum(value >= height * 0.68 for value in cols)
    foreground_points = [(x, y) for y in range(height) for x in range(width) if dark[y * width + x]]
    if foreground_points:
        xs = [point[0] for point in foreground_points]
        ys = [point[1] for point in foreground_points]
        bbox_area_ratio = ((max(xs) - min(xs) + 1) * (max(ys) - min(ys) + 1)) / total
        edge_margin = max(1, min(width, height) // 50)
        edge_touch_ratio = sum(
            x <= edge_margin or x >= width - 1 - edge_margin or
            y <= edge_margin or y >= height - 1 - edge_margin
            for x, y in foreground_points
        ) / max(1, len(foreground_points))
    else:
        bbox_area_ratio = 0.0
        edge_touch_ratio = 0.0
    row_bands = independent_formula_row_bands(rows, width, height)
    metrics = {
        "width": width,
        "height": height,
        "dark_ratio": round(dark_ratio, 4),
        "color_ratio": round(color_ratio, 4),
        "white_ratio": round(white_ratio, 4),
        "midtone_ratio": round(midtone_ratio, 4),
        "populated_luminance_bins": populated_luminance_bins,
        "long_horizontal_lines": long_horizontal,
        "long_vertical_lines": long_vertical,
        "foreground_pixels": len(foreground_points),
        "foreground_bbox_area_ratio": round(bbox_area_ratio, 4),
        "foreground_edge_touch_ratio": round(edge_touch_ratio, 4),
        "independent_formula_row_bands": len(row_bands),
        "formula_row_band_ranges": [[start, end] for start, end, _ in row_bands],
    }

    # These conditions intentionally target only clear charts/diagrams.  All
    # ambiguous black-and-white material proceeds to OCR with review metadata.
    aspect_ratio = width / max(height, 1)
    inverse_aspect_ratio = height / max(width, 1)
    elongation = max(aspect_ratio, inverse_aspect_ratio)
    metrics["aspect_ratio"] = round(aspect_ratio, 4)
    metrics["elongation"] = round(elongation, 4)
    # A small amount of colour is common in labels and antialiasing.  Reject it
    # only when the colour evidence is strong or occurs in a diagram-sized crop.
    if dark_ratio < 0.0015 or len(foreground_points) < 25 or bbox_area_ratio < 0.002:
        status, reason = "rejected_non_formula", "blank_watermark_or_tiny_fragment"
    elif width <= 64 and height <= 64 and bbox_area_ratio < 0.55:
        status, reason = "rejected_non_formula", "tiny_isolated_fragment"
    elif color_ratio >= 0.06 or (height >= 110 and color_ratio >= 0.025):
        status, reason = "rejected_non_formula", "visual_color_or_diagram_signal"
    elif white_ratio < 0.42 and midtone_ratio > 0.24 and populated_luminance_bins >= 9:
        status, reason = "rejected_non_formula", "visual_photo_or_dense_grayscale_signal"
    elif inverse_aspect_ratio >= 8 and width <= 48:
        status, reason = "rejected_non_formula", "vertical_text_or_margin_fragment"
    elif (
        dark_ratio >= 0.30
        and bbox_area_ratio >= 0.80
        and long_vertical >= 20
        and long_horizontal >= 3
    ):
        status, reason = "rejected_non_formula", "dense_logo_or_large_text_signal"
    # Fraction bars and brackets also form long horizontal/vertical strokes.
    # Coordinate-axis rejection therefore requires a sufficiently tall crop.
    elif (height >= 140 and aspect_ratio <= 4.5 and long_horizontal >= 1
          and long_vertical >= 1 and dark_ratio < 0.12):
        status, reason = "rejected_non_formula", "visual_coordinate_axes_signal"
    elif len(row_bands) >= 2:
        status, reason = "formula_candidate_strict", "multiple_formula_rows_require_coverage_check"
    elif upstream_label == "unknown":
        status, reason = "formula_candidate_strict", "upstream_formula_unknown"
    elif elongation >= 8 or edge_touch_ratio >= 0.12:
        status, reason = "formula_candidate_strict", "extreme_aspect_or_crop_edge_fragment_risk"
    elif (
        color_ratio >= 0.012
        or dark_ratio < 0.008
        or bbox_area_ratio < 0.04
        or white_ratio < 0.72
        or (aspect_ratio < 1.15 and bbox_area_ratio > 0.62)
    ):
        status, reason = "formula_candidate_strict", "visual_risk_requires_dual_ocr"
    else:
        status, reason = "formula_candidate", "no_strong_non_formula_signal"
    return {
        "image_screen_status": status,
        "image_screen_reason": reason,
        "image_screen_metrics": json.dumps(metrics, ensure_ascii=False),
    }


OCR_KNOWN_COMMANDS = {
    "frac", "cfrac", "dfrac", "tfrac", "sqrt", "sin", "cos", "tan", "log", "ln", "exp",
    "left", "right", "cdot", "times", "div", "pm", "sum", "prod", "int",
    "partial", "nabla", "infty", "mathrm", "mathbf", "mathcal", "mathbb", "mathfrak",
    "text", "operatorname", "hat", "bar", "tilde", "vec", "dot", "ddot",
    "alpha", "beta", "gamma", "delta", "epsilon", "varepsilon", "theta",
    "lambda", "mu", "nu", "pi", "rho", "sigma", "tau", "phi", "varphi", "omega",
    "xi", "chi", "eta", "zeta", "upsilon", "Gamma", "Delta", "Theta", "Lambda", "Pi", "Phi", "Omega", "hbar", "begin", "end",
    "approx", "equiv", "le", "leq", "ge", "geq", "ne", "neq", "to",
    "rightarrow", "longrightarrow", "propto", "sim", "quad", "qquad",
    "prime", "dots", "ldots", "cdots", "big", "Big", "bigg", "Bigg",
    "bigl", "bigr", "Bigl", "Bigr", "biggl", "biggr", "Biggl", "Biggr",
    "displaystyle", "textstyle", "scriptstyle", "scriptscriptstyle",
    "sf", "bf", "cal", "phantom", "strut",
} | ALL_KNOWN_COMMANDS


def assess_ocr_quality(latex: str, image_screen_metrics: Any = None) -> Dict[str, str]:
    text = (latex or "").strip()
    if not text:
        return {"ocr_generated_status": "empty", "ocr_quality_status": "rejected", "ocr_quality_reasons": "empty_ocr"}
    reasons = []
    severe = []
    deferred = []
    delimiter_gap = sum(abs(text.count(left) - text.count(right)) for left, right in (("{", "}"), ("(", ")"), ("[", "]")))
    commands = re.findall(r"\\([A-Za-z]+)", text)
    unknown = [name for name in commands if name not in OCR_KNOWN_COMMANDS]
    math_tokens = re.findall(r"[A-Za-z]+|\d+(?:\.\d+)?|[=<>+\-*/^]", text)
    word_tokens = re.findall(r"(?<!\\)\b[A-Za-z]{4,}\b", text)
    structural_tokens = re.findall(r"[=<>+\-*/^]|\\(?:frac|sqrt|sum|prod|int|sin|cos|tan|log|ln|exp)\b", text)
    empty_groups = len(re.findall(r"\{\s*\}|\(\s*\)", text))
    repeated = max((len(list(items)) for _, items in groupby(math_tokens)), default=0)
    formatting_names = {
        "mathrm", "mathbf", "mathit", "mathsf", "mathtt", "mathcal", "mathbb",
        "mathfrak", "text", "operatorname", "left", "right", "big", "Big",
        "bigg", "Bigg", "displaystyle", "textstyle", "scriptstyle",
    }
    cleaned_symbol_tokens = [
        token for token in re.findall(r"\\([A-Za-z]+)|(?<!\\)\b([A-Za-z]+)\b", text)
        for token in token if token and token not in formatting_names
    ]
    symbol_counts = Counter(cleaned_symbol_tokens)
    max_symbol_count = max(symbol_counts.values(), default=0)
    dominant_symbol = max(symbol_counts, key=symbol_counts.get) if symbol_counts else ""
    symbol_diversity = len(symbol_counts)
    if delimiter_gap > 2:
        severe.append("severe_delimiter_imbalance")
    elif delimiter_gap:
        reasons.append("delimiter_imbalance")
    if commands and len(unknown) / len(commands) > 0.5 and len(unknown) >= 3:
        severe.append("high_unknown_command_ratio")
    elif unknown:
        reasons.append("unknown_commands:" + ",".join(sorted(set(unknown))[:6]))
    if empty_groups >= 3:
        reasons.append("many_empty_groups")
    if repeated >= 10:
        reasons.append("abnormal_repeated_tokens")
    if max_symbol_count >= 5 and symbol_diversity <= max(3, len(cleaned_symbol_tokens) // 4):
        reasons.append("repeated_low_diversity_math_symbol:" + dominant_symbol)
    if len(text) >= 500 and len(math_tokens) < 8:
        severe.append("long_output_with_few_math_tokens")
    if len(word_tokens) >= 5 and len(structural_tokens) <= 1:
        severe.append("prose_like_ocr_output")
    elif len(word_tokens) >= 3 and len(word_tokens) > len(structural_tokens) + 2:
        reasons.append("possible_prose_or_figure_labels")
    # pix2tex occasionally reads a trailing percent sign as phi/varphi plus
    # a spurious subscript.  Retain the OCR text for review, but do not let a
    # likely percentage hallucination enter the core frequency statistics.
    compact_ocr = re.sub(r"\s+", "", text)
    if any(marker in compact_ocr for marker in (
        r"100\varphi", r"100\phi", "100varphi", "100phi",
    )):
        reasons.append("possible_percent_sign_misread_as_phi")
    if any(marker in text for marker in ("\\begin{array}", "\\begin{aligned}")):
        deferred.append("multiline_layout_requires_parser_validation")
    metrics = image_screen_metrics
    if isinstance(metrics, str):
        try:
            metrics = json.loads(metrics)
        except (TypeError, ValueError, json.JSONDecodeError):
            metrics = {}
    metrics = metrics if isinstance(metrics, dict) else {}
    row_bands = int(metrics.get("independent_formula_row_bands", 0) or 0)
    relation_count = len(re.findall(r"(?<![<>!~])=(?!=)|\\(?:equiv|approx|simeq|leq?|geq?)\b", text))
    explicit_rows = max(
        len(re.findall(r"(?<!\\)\\\\", text)) + 1,
        len(re.findall(r"\\begin\{(?:array|aligned|gathered|cases)\}", text)) + 1,
    )
    if row_bands >= 2 and max(relation_count, explicit_rows) < row_bands:
        reasons.append("multiline_image_single_expression_ocr")
    quality = "rejected" if severe else ("suspicious" if reasons else "passed")
    return {
        "ocr_generated_status": "generated",
        "ocr_quality_status": quality,
        "ocr_quality_reasons": ";".join(severe + reasons),
        "ocr_deferred_reasons": ";".join(deferred),
        "latex_command_registry_version": REGISTRY_VERSION,
    }


def ocr_signature(latex: str) -> str:
    text = re.sub(r"\\(?:left|right|big|Big|bigg|Bigg|,|;|:|quad|qquad)", "", latex or "")
    return " ".join(re.findall(r"\\[A-Za-z]+|[A-Za-z]+|\d+(?:\.\d+)?|<=|>=|!=|~=|->|[=+\-*/^()]", text))


def ocr_structure_signature(latex: str) -> tuple:
    """Coarse structure used only to gate risky dual-OCR candidates."""
    text = ocr_signature(latex)
    relations = tuple(re.findall(r"<=|>=|!=|~=|->|=", text))
    operators = tuple(re.findall(r"[+\-*/^]", text))
    structures = tuple(sorted(re.findall(
        r"\\(?:frac|sqrt|sum|prod|int|sin|cos|tan|log|ln|exp)\b",
        text,
    )))
    return relations, operators, structures


OCR_QUALITY_RANK = {"passed": 2, "suspicious": 1, "rejected": 0}


def choose_dual_ocr_result(
    primary_latex: str,
    primary_quality: Dict[str, str],
    variant_latex: str,
    variant_quality: Dict[str, str],
) -> tuple[str, Dict[str, str], float]:
    """Select the stronger text while requiring two reliable, consistent passes."""
    primary_rank = OCR_QUALITY_RANK.get(primary_quality.get("ocr_quality_status", "rejected"), 0)
    variant_rank = OCR_QUALITY_RANK.get(variant_quality.get("ocr_quality_status", "rejected"), 0)
    similarity = difflib.SequenceMatcher(
        None, ocr_signature(primary_latex), ocr_signature(variant_latex),
    ).ratio()

    selected_latex = primary_latex
    selected_quality = dict(primary_quality)
    if variant_rank > primary_rank:
        selected_latex = variant_latex
        selected_quality = dict(variant_quality)

    both_passed = primary_rank == 2 and variant_rank == 2
    structures_match = ocr_structure_signature(primary_latex) == ocr_structure_signature(variant_latex)
    if not both_passed:
        selected_quality["ocr_quality_status"] = "suspicious"
        reasons = selected_quality.get("ocr_quality_reasons", "")
        selected_quality["ocr_quality_reasons"] = (
            reasons + ";strict_dual_ocr_requires_two_passes"
        ).strip(";")
    if similarity < STRICT_OCR_SIMILARITY:
        selected_quality["ocr_quality_status"] = "suspicious"
        reasons = selected_quality.get("ocr_quality_reasons", "")
        selected_quality["ocr_quality_reasons"] = (
            reasons + ";ocr_variant_disagreement_below_0.70"
        ).strip(";")
    if not structures_match:
        selected_quality["ocr_quality_status"] = "suspicious"
        reasons = selected_quality.get("ocr_quality_reasons", "")
        selected_quality["ocr_quality_reasons"] = (
            reasons + ";ocr_variant_structure_disagreement"
        ).strip(";")
    return selected_latex, selected_quality, similarity


def json_dump_line(handle, row: Dict[str, Any]) -> None:
    handle.write(json.dumps(row, ensure_ascii=False) + "\n")
    handle.flush()


def iter_jsonl(path: Path) -> Iterator[Dict[str, Any]]:
    with path.open("r", encoding="utf-8") as handle:
        for line in handle:
            line = line.strip()
            if line:
                yield json.loads(line)


def archive_kind(path: Path) -> str:
    name = path.name.lower()
    for suffix in sorted(ARCHIVE_EXTENSIONS, key=len, reverse=True):
        if name.endswith(suffix):
            return suffix
    return ""


def human_size(size: int) -> str:
    value = float(size)
    for unit in ("B", "KB", "MB", "GB", "TB"):
        if value < 1024 or unit == "TB":
            return f"{value:.2f} {unit}"
        value /= 1024
    return f"{value:.2f} TB"


def format_duration(seconds: float) -> str:
    seconds = max(int(seconds), 0)
    hours, rem = divmod(seconds, 3600)
    minutes, secs = divmod(rem, 60)
    if hours:
        return f"{hours:02d}:{minutes:02d}:{secs:02d}"
    return f"{minutes:02d}:{secs:02d}"


def progress_text(stage: str, done: int, total: int, started: float, success: int | None = None, failed: int | None = None) -> str:
    elapsed = max(time.time() - started, 0.001)
    rate = done / elapsed
    percent = (done / total * 100.0) if total else 0.0
    remaining = max(total - done, 0)
    eta = remaining / rate if rate > 0 else 0
    pieces = [
        f"[{stage}]",
        f"processed={done}/{total}",
        f"progress={percent:.2f}%",
        f"rate={rate:.2f}/s",
        f"elapsed={format_duration(elapsed)}",
        f"eta={format_duration(eta)}",
    ]
    if success is not None:
        pieces.append(f"success={success}")
    if failed is not None:
        pieces.append(f"failed={failed}")
    return " ".join(pieces)


def command_inspect(args: argparse.Namespace) -> None:
    root = Path(args.data_root).expanduser().resolve()
    if not root.exists():
        raise SystemExit(f"data root does not exist: {root}")
    print(f"data_root={root}")
    print(f"free_space={human_size(shutil.disk_usage(root).free)}")
    files = [p for p in root.rglob("*") if p.is_file()]
    archives = [p for p in files if archive_kind(p)]
    images = [p for p in files if p.suffix.lower() in IMAGE_EXTENSIONS and p.name.lower().startswith("formula")]
    json_files = [p for p in files if p.suffix.lower() == ".json"]
    print(f"files={len(files)} archives={len(archives)} json={len(json_files)} formula_images={len(images)}")
    for path in sorted(archives):
        print(f"ARCHIVE\t{human_size(path.stat().st_size)}\t{path}")
        if args.list_members:
            for member in list_archive_members(path, args.member_limit):
                print(f"  {member}")


def list_archive_members(path: Path, limit: int) -> list[str]:
    kind = archive_kind(path)
    if kind == ".zip":
        with zipfile.ZipFile(path) as zf:
            return zf.namelist()[:limit]
    if kind in {".tar", ".tar.gz", ".tgz", ".tar.bz2", ".tbz2", ".tar.xz", ".txz"}:
        with tarfile.open(path) as tf:
            return [m.name for m in tf.getmembers()[:limit]]
    exe = shutil.which("7z") or shutil.which("7zz") or shutil.which("unrar")
    if not exe:
        return ["(install 7z/unrar to list this archive)"]
    completed = subprocess.run([exe, "l", str(path)], text=True, capture_output=True, check=False)
    return completed.stdout.splitlines()[:limit]


def _safe_target(dest: Path, name: str) -> Path:
    target = (dest / name).resolve()
    try:
        target.relative_to(dest.resolve())
    except ValueError as exc:
        raise RuntimeError(f"unsafe archive member: {name}") from exc
    return target


def command_extract(args: argparse.Namespace) -> None:
    archive = Path(args.archive).expanduser().resolve()
    dest = Path(args.dest).expanduser().resolve()
    if not archive.is_file():
        raise SystemExit(f"archive does not exist: {archive}")
    dest.mkdir(parents=True, exist_ok=True)
    kind = archive_kind(archive)
    print(f"extracting={archive}\ndestination={dest}")
    if kind == ".zip":
        with zipfile.ZipFile(archive) as zf:
            for info in zf.infolist():
                _safe_target(dest, info.filename)
            zf.extractall(dest)
    elif kind in {".tar", ".tar.gz", ".tgz", ".tar.bz2", ".tbz2", ".tar.xz", ".txz"}:
        with tarfile.open(archive) as tf:
            for member in tf.getmembers():
                _safe_target(dest, member.name)
            tf.extractall(dest)
    else:
        exe = shutil.which("7z") or shutil.which("7zz")
        if not exe:
            raise SystemExit("RAR/7z extraction requires 7z or 7zz")
        subprocess.run([exe, "x", str(archive), f"-o{dest}", "-y"], check=True)
    print("extract_status=complete")


def flatten_json(value: Any, prefix: str = "") -> Dict[str, Any]:
    flat: Dict[str, Any] = {}
    if isinstance(value, dict):
        for key, item in value.items():
            name = f"{prefix}.{key}" if prefix else str(key)
            if isinstance(item, (dict, list)):
                flat.update(flatten_json(item, name))
            else:
                flat[name.lower()] = item
    elif isinstance(value, list):
        for index, item in enumerate(value[:20]):
            flat.update(flatten_json(item, f"{prefix}.{index}"))
    return flat


def pick_value(flat: Dict[str, Any], aliases: Iterable[str]) -> str:
    for alias in aliases:
        alias = alias.lower()
        for key, value in flat.items():
            if key == alias or key.endswith("." + alias):
                if isinstance(value, (str, int, float)) and str(value).strip():
                    return str(value).strip()
    return ""


def load_metadata(path: Path | None) -> Dict[str, str]:
    if path is None:
        return {}
    try:
        raw = json.loads(path.read_text(encoding="utf-8-sig"))
        flat = flatten_json(raw)
        return {
            "title": pick_value(flat, TITLE_KEYS),
            "authors": pick_value(flat, AUTHOR_KEYS),
            "source_identifier": pick_value(flat, ID_KEYS),
            "journal_or_venue": pick_value(flat, JOURNAL_KEYS),
            "year": pick_value(flat, YEAR_KEYS),
        }
    except Exception as exc:
        return {"metadata_error": str(exc)}


def nearest_json(image: Path, root: Path, by_dir: Dict[Path, list[Path]]) -> Path | None:
    current = image.parent
    while True:
        candidates = by_dir.get(current, [])
        if candidates:
            stem = image.stem.lower()
            matching = [p for p in candidates if p.stem.lower() in stem or stem in p.stem.lower()]
            return sorted(matching or candidates)[0]
        if current == root or root not in current.parents:
            return None
        current = current.parent


def stable_source_id(rel_parent: str, metadata_id: str) -> str:
    seed = metadata_id or rel_parent
    return "SRC_" + hashlib.sha1(seed.encode("utf-8", errors="ignore")).hexdigest()[:16]


def command_index(args: argparse.Namespace) -> None:
    root = Path(args.extracted_root).expanduser().resolve()
    out = Path(args.out).expanduser().resolve()
    out.parent.mkdir(parents=True, exist_ok=True)
    json_files = sorted(p for p in root.rglob("*.json") if p.is_file())
    by_dir: Dict[Path, list[Path]] = {}
    for path in json_files:
        by_dir.setdefault(path.parent, []).append(path)
    images = sorted(
        p for p in root.rglob("*")
        if p.is_file() and p.suffix.lower() in IMAGE_EXTENSIONS and p.name.lower().startswith("formula")
    )
    if not images:
        raise SystemExit(f"no Formula* images found under {root}")
    metadata_cache: Dict[Path | None, Dict[str, str]] = {None: {}}
    source_counter: Counter[str] = Counter()
    with out.open("w", encoding="utf-8") as handle:
        for index, image in enumerate(images, 1):
            metadata_path = nearest_json(image, root, by_dir)
            if metadata_path not in metadata_cache:
                metadata_cache[metadata_path] = load_metadata(metadata_path)
            metadata = metadata_cache[metadata_path]
            rel = image.relative_to(root).as_posix()
            rel_parent = image.parent.relative_to(root).as_posix()
            source_id = stable_source_id(rel_parent, metadata.get("source_identifier", ""))
            source_counter[source_id] += 1
            upstream = filename_candidate_metadata(image.name)
            screen = screen_formula_image(image, upstream["upstream_formula_label"])
            row = {
                "image_index": index,
                "image_path": str(image),
                "image_relative_path": rel,
                "image_name": image.name,
                "source_id": source_id,
                "formula_index_in_source": source_counter[source_id],
                "metadata_json_path": str(metadata_path) if metadata_path else "",
                **upstream,
                **screen,
                **metadata,
            }
            json_dump_line(handle, row)
    print(f"formula_images={len(images)} sources={len(source_counter)} json_files={len(json_files)}")
    print(f"index={out}")


def configure_device(device: str) -> None:
    if device == "cpu":
        os.environ["CUDA_VISIBLE_DEVICES"] = ""
    elif device.startswith("cuda:") and "CUDA_VISIBLE_DEVICES" not in os.environ:
        os.environ["CUDA_VISIBLE_DEVICES"] = device.split(":", 1)[1]


def stable_ocr_seed(formula_id: str, pass_name: str) -> int:
    """Give each formula and image variant an order-independent PyTorch seed."""
    if not formula_id:
        raise ValueError("deterministic OCR requires a nonempty formula_id")
    payload = ("ocr-per-formula-v1\0" + formula_id + "\0" + pass_name).encode("utf-8")
    return int.from_bytes(hashlib.sha256(payload).digest()[:8], "big") & ((1 << 63) - 1)


def file_sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def stage_fingerprint(stage: str, input_path: Path, engine_path: Optional[Path] = None) -> Dict[str, Any]:
    version_path = Path(__file__).resolve().with_name("VERSION.txt")
    package_version = "unknown"
    if version_path.exists():
        for line in version_path.read_text(encoding="utf-8").splitlines():
            if line.startswith("version="):
                package_version = line.split("=", 1)[1].strip()
                break
    fingerprint = {
        "pipeline_version": package_version,
        "stage": stage,
        "input_path": str(input_path),
        "input_sha256": file_sha256(input_path),
        "server_pipeline_sha256": file_sha256(Path(__file__).resolve()),
        "latex_command_registry_version": REGISTRY_VERSION,
        "python_version": sys.version,
    }
    if engine_path is not None:
        fingerprint["formula_engine_sha256"] = file_sha256(engine_path)
    return fingerprint


def validate_or_write_stage_manifest(path: Path, fingerprint: Dict[str, Any], resume: bool) -> None:
    if resume:
        if not path.exists():
            raise SystemExit("resume refused: stage fingerprint manifest is missing; use a new output directory")
        previous = json.loads(path.read_text(encoding="utf-8"))
        if previous != fingerprint:
            raise SystemExit("resume refused: code/input fingerprint changed; use a new output directory")
    else:
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(fingerprint, ensure_ascii=False, indent=2), encoding="utf-8")


def command_ocr(args: argparse.Namespace) -> None:
    if args.ocr_seed_mode == "per_formula_v1":
        # cuBLAS reads this before CUDA is initialized. Keep the setting in the
        # stage manifest so a resumed job cannot mix inference modes.
        os.environ["CUBLAS_WORKSPACE_CONFIG"] = ":4096:8"
    from PIL import Image, ImageEnhance, ImageOps
    from pix2tex.cli import LatexOCR
    import random
    import numpy as np
    import torch

    if args.ocr_seed_mode == "per_formula_v1":
        torch.backends.cudnn.benchmark = False
        torch.backends.cudnn.deterministic = True
        torch.use_deterministic_algorithms(True)

    index_path = Path(args.index).expanduser().resolve()
    out = Path(args.out).expanduser().resolve()
    out.parent.mkdir(parents=True, exist_ok=True)
    manifest_path = out.with_name(out.name + ".stage_manifest.json")
    fingerprint = stage_fingerprint("ocr", index_path)
    fingerprint.update({
        "device": args.device,
        "ocr_model": "pix2tex.LatexOCR",
        "ocr_seed_mode": args.ocr_seed_mode,
        "cublas_workspace_config": os.environ.get("CUBLAS_WORKSPACE_CONFIG", ""),
    })
    validate_or_write_stage_manifest(manifest_path, fingerprint, args.resume)
    total_index_rows = sum(1 for _ in iter_jsonl(index_path))
    completed_paths = set()
    if args.resume and out.exists():
        completed_paths = {row.get("image_relative_path", "") for row in iter_jsonl(out)}
    target = max(total_index_rows - len(completed_paths), 0)
    if args.limit:
        target = min(target, args.limit)
    configure_device(args.device)
    print(f"loading_pix2tex device={args.device}")
    print(f"ocr_total={target} indexed={total_index_rows} resumed_skip={len(completed_paths)}", flush=True)
    model = LatexOCR()
    model.args.device = args.device
    model.model = model.model.to(args.device)
    model.image_resizer = model.image_resizer.to(args.device)
    print(
        f"pix2tex_actual_device={next(model.model.parameters()).device}",
        flush=True,
    )
    mode = "a" if args.resume and out.exists() else "w"
    success = failed = skipped = screened_skip = 0
    started = time.time()
    with out.open(mode, encoding="utf-8") as handle:
        for row in iter_jsonl(index_path):
            rel = row.get("image_relative_path", "")
            if rel in completed_paths:
                skipped += 1
                continue
            if args.limit and success + failed + screened_skip >= args.limit:
                break
            # Some callers, including the manual-review sampler, create the
            # index directly.  Enforce the same visual gate here so no input
            # path can bypass formula-image screening.
            if not row.get("image_screen_status"):
                image_path = Path(row["image_path"])
                upstream = filename_candidate_metadata(row.get("image_name", image_path.name))
                row.update(upstream)
                row.update(screen_formula_image(image_path, upstream["upstream_formula_label"]))
            if row.get("image_screen_status") in {"non_formula_image", "rejected_non_formula"} and not args.include_screened_non_formula:
                row.update({
                    "formula_latex": "", "ocr_status": "skipped_non_formula",
                    "ocr_generated_status": "skipped", "ocr_quality_status": "rejected",
                    "ocr_quality_reasons": "screened_non_formula",
                    "ocr_error": "screened before OCR: " + row.get("image_screen_reason", ""),
                    "ocr_seconds": 0,
                })
                json_dump_line(handle, row)
                screened_skip += 1
                done = success + failed + screened_skip
                if done % args.log_every == 0:
                    print(progress_text("ocr", done, target, started, success, failed), flush=True)
                continue
            t0 = time.time()
            try:
                with Image.open(row["image_path"]) as image:
                    rgb = image.convert("RGB")
                    if args.ocr_seed_mode == "per_formula_v1":
                        seed = stable_ocr_seed(str(row.get("formula_id", "")), "primary")
                        random.seed(seed)
                        np.random.seed(seed % (1 << 32))
                        torch.manual_seed(seed)
                    latex = str(model(rgb)).strip()
                    primary_quality = assess_ocr_quality(latex, row.get("image_screen_metrics"))
                    variant_latex = ""
                    similarity = 1.0
                    if row.get("image_screen_status") == "formula_candidate_strict":
                        gray = ImageOps.grayscale(rgb)
                        enhanced = ImageEnhance.Contrast(ImageOps.autocontrast(gray)).enhance(1.35)
                        enhanced = ImageOps.expand(enhanced, border=12, fill=255).convert("RGB")
                        if args.ocr_seed_mode == "per_formula_v1":
                            seed = stable_ocr_seed(str(row.get("formula_id", "")), "enhanced")
                            random.seed(seed)
                            np.random.seed(seed % (1 << 32))
                            torch.manual_seed(seed)
                        variant_latex = str(model(enhanced)).strip()
                        variant_quality = assess_ocr_quality(variant_latex, row.get("image_screen_metrics"))
                        latex, primary_quality, similarity = choose_dual_ocr_result(
                            latex, primary_quality, variant_latex, variant_quality,
                        )
                        row["ocr_variant_quality_status"] = variant_quality.get("ocr_quality_status", "")
                        row["ocr_variant_quality_reasons"] = variant_quality.get("ocr_quality_reasons", "")
                row.update({
                    "formula_latex": latex,
                    "ocr_status": "ok" if latex else "empty",
                    "ocr_error": "",
                    "ocr_variant_latex": variant_latex,
                    "ocr_variant_similarity": round(similarity, 4),
                    **primary_quality,
                })
                success += bool(latex)
                failed += not bool(latex)
            except Exception as exc:
                row.update({
                    "formula_latex": "", "ocr_status": "error", "ocr_error": str(exc),
                    "ocr_generated_status": "error", "ocr_quality_status": "rejected",
                    "ocr_quality_reasons": "ocr_exception",
                })
                failed += 1
            row["ocr_seconds"] = round(time.time() - t0, 3)
            json_dump_line(handle, row)
            done = success + failed + screened_skip
            if done % args.log_every == 0:
                print(progress_text("ocr", done, target, started, success, failed), flush=True)
        done = success + failed + screened_skip
        if done and done % args.log_every != 0:
            print(progress_text("ocr", done, target, started, success, failed), flush=True)
    print(f"ocr_complete success={success} failed={failed} screened_skip={screened_skip} resumed_skip={skipped} out={out}")


def import_engine(path: Path):
    spec = importlib.util.spec_from_file_location("formula_engine", path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"cannot import engine: {path}")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def formula_row(ocr: Dict[str, Any], ordinal: int) -> Dict[str, str]:
    locator = ocr.get("image_relative_path", "")
    stable_suffix = hashlib.sha1(locator.encode("utf-8")).hexdigest()[:12]
    return {
        "formula_id": ocr.get("formula_id", "") or f"{ocr.get('source_id', 'SRC')}_F_{stable_suffix}",
        "source_id": ocr.get("source_id", ""),
        "source_title": ocr.get("title", "") or Path(ocr.get("metadata_json_path", "unknown")).stem,
        "chapter": "", "section": "", "page": "", "equation_number": "",
        "locator": locator,
        "extraction_method": "server_formula_image_pix2tex",
        "formula_latex": ocr.get("formula_latex", ""),
        "raw_text": ocr.get("formula_latex", ""),
        "context_before": "", "context_after": "",
        "screenshot_path": ocr.get("image_path", ""),
        "bbox": "", "source_file": ocr.get("metadata_json_path", ""),
        # Do not invent a calibrated confidence from an upstream filename.
        "confidence": "", "needs_review": "1" if ocr.get("image_screen_status") != "formula_candidate" else "0",
        "image_screen_status": ocr.get("image_screen_status", "formula_candidate_strict"),
        "image_screen_reason": ocr.get("image_screen_reason", ""),
        "image_screen_metrics": ocr.get("image_screen_metrics", ""),
        "ocr_generated_status": ocr.get("ocr_generated_status", ""),
        "ocr_quality_status": ocr.get("ocr_quality_status", ""),
        "ocr_quality_reasons": ocr.get("ocr_quality_reasons", ""),
        "ocr_variant_latex": ocr.get("ocr_variant_latex", ""),
        "ocr_variant_similarity": ocr.get("ocr_variant_similarity", ""),
        "upstream_formula_label": ocr.get("upstream_formula_label", ""),
        "upstream_formula_score_raw": ocr.get("upstream_formula_score_raw", ""),
        "note": "metadata_json=" + ocr.get("metadata_json_path", "") + "; image_screen=" + ocr.get("image_screen_status", "formula_candidate_strict"),
    }


def revalidate_existing_ocr_row(ocr: Dict[str, Any]) -> Dict[str, Any]:
    """Apply the current gate and OCR-quality rules to reusable OCR text.

    OCR reuse skips model inference only.  It must not freeze quality labels
    produced by an older code version, otherwise parser comparisons mix old
    screening policy with new tree logic.
    """
    row = dict(ocr)
    image_path = Path(row.get("image_path", ""))
    if image_path.is_file():
        upstream = filename_candidate_metadata(row.get("image_name", image_path.name))
        row.update(upstream)
        row.update(screen_formula_image(image_path, upstream["upstream_formula_label"]))

    latex = str(row.get("formula_latex", "") or "").strip()
    quality = assess_ocr_quality(latex, row.get("image_screen_metrics"))
    variant_latex = str(row.get("ocr_variant_latex", "") or "").strip()
    similarity = 1.0
    if row.get("image_screen_status") == "formula_candidate_strict":
        variant_quality = assess_ocr_quality(variant_latex, row.get("image_screen_metrics"))
        latex, quality, similarity = choose_dual_ocr_result(
            latex, quality, variant_latex, variant_quality,
        )
        row["ocr_variant_quality_status"] = variant_quality.get("ocr_quality_status", "")
        row["ocr_variant_quality_reasons"] = variant_quality.get("ocr_quality_reasons", "")
    elif variant_latex:
        similarity = difflib.SequenceMatcher(
            None, ocr_signature(latex), ocr_signature(variant_latex),
        ).ratio()

    if row.get("image_screen_status") in {"non_formula_image", "rejected_non_formula"}:
        quality["ocr_quality_status"] = "rejected"
        reasons = quality.get("ocr_quality_reasons", "")
        quality["ocr_quality_reasons"] = ";".join(filter(None, (
            reasons, "screened_non_formula_revalidation",
        )))
    row.update({
        "formula_latex": latex,
        "ocr_variant_similarity": round(similarity, 4),
        **quality,
    })
    return row


def command_analyze(args: argparse.Namespace) -> None:
    ocr_path = Path(args.ocr).expanduser().resolve()
    engine_path = Path(args.engine).expanduser().resolve()
    out_dir = Path(args.out_dir).expanduser().resolve()
    out_dir.mkdir(parents=True, exist_ok=True)
    trees_path = out_dir / "formula_trees.jsonl"
    failures_path = out_dir / "parse_failures.jsonl"
    summary_path = out_dir / "analysis_summary.json"
    manifest_path = out_dir / "analyze_stage_manifest.json"
    validate_or_write_stage_manifest(
        manifest_path,
        stage_fingerprint("analyze", ocr_path, engine_path),
        args.resume,
    )
    engine = import_engine(engine_path)
    total_nonempty_ocr = sum(1 for row in iter_jsonl(ocr_path) if row.get("formula_latex", "").strip())
    processed_ids = set()
    existing_parsed = 0
    existing_failed = 0
    tag_counts: Counter[str] = Counter()
    record_status_counts: Counter[str] = Counter()
    fidelity_status_counts: Counter[str] = Counter()
    if args.resume and trees_path.exists():
        for existing in iter_jsonl(trees_path):
            formula_id = existing.get("formula_id", "")
            if formula_id:
                processed_ids.add(formula_id)
            existing_parsed += 1
            tag_counts.update(existing.get("tags", []))
            record_status_counts.update([existing.get("record_status", "legacy_unknown")])
            fidelity_status_counts.update([existing.get("tree_fidelity_status", "legacy_unknown")])
        if failures_path.exists():
            for existing_failure in iter_jsonl(failures_path):
                formula_id = existing_failure.get("formula_id", "")
                if formula_id:
                    processed_ids.add(formula_id)
                existing_failed += 1
    target = max(total_nonempty_ocr - len(processed_ids), 0)
    print(f"analyze_total={target} nonempty_ocr={total_nonempty_ocr} resumed_skip={len(processed_ids)}", flush=True)
    tree_mode = "a" if args.resume and trees_path.exists() else "w"
    failure_mode = "a" if args.resume and failures_path.exists() else "w"
    parsed = failed = skipped_ocr = resumed = 0
    last_logged = 0
    analyze_started = time.time()

    def analyze_group(rows: list[Dict[str, str]], tree_handle, failure_handle) -> None:
        nonlocal parsed, failed, resumed, last_logged
        pending = [row for row in rows if row["formula_id"] not in processed_ids]
        resumed += len(rows) - len(pending)
        if not pending:
            return
        results, _, _, failures = engine.process_formulas(pending)
        for result in results:
            json_dump_line(tree_handle, result)
            parsed += 1
            tag_counts.update(result.get("tags", []))
            record_status_counts.update([result.get("record_status", "unknown")])
            fidelity_status_counts.update([result.get("tree_fidelity_status", "unknown")])
        for failure in failures:
            json_dump_line(failure_handle, failure)
            failed += 1
        done = parsed + failed
        if done and (done - last_logged >= args.log_every or done >= target):
            print(progress_text("analyze", done, target, analyze_started, parsed, failed), flush=True)
            last_logged = done

    with trees_path.open(tree_mode, encoding="utf-8") as tree_handle, failures_path.open(failure_mode, encoding="utf-8") as failure_handle:
        current_source = None
        group: list[Dict[str, str]] = []
        ordinal = 0
        for ocr in iter_jsonl(ocr_path):
            if not ocr.get("formula_latex", "").strip():
                skipped_ocr += 1
                continue
            ocr = revalidate_existing_ocr_row(ocr)
            source_id = ocr.get("source_id", "")
            if current_source is not None and source_id != current_source:
                analyze_group(group, tree_handle, failure_handle)
                group = []
                ordinal = 0
            current_source = source_id
            ordinal += 1
            group.append(formula_row(ocr, ordinal))
        if group:
            analyze_group(group, tree_handle, failure_handle)
    summary = {
        "parsed": existing_parsed + parsed, "parse_failed": existing_failed + failed, "skipped_empty_ocr": skipped_ocr,
        "resumed_skip": resumed, "m01_m12_formula_counts": dict(sorted(tag_counts.items())),
        "record_status_counts": dict(sorted(record_status_counts.items())),
        "tree_fidelity_status_counts": dict(sorted(fidelity_status_counts.items())),
        "ocr_nonempty": total_nonempty_ocr,
        "formula_trees": str(trees_path), "parse_failures": str(failures_path),
    }
    summary_path.write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(summary, ensure_ascii=False, indent=2))


def command_cluster(args: argparse.Namespace) -> None:
    root = Path(args.workspace).expanduser().resolve()
    script = Path(args.cluster_script).expanduser().resolve()
    trees = Path(args.formula_trees).expanduser().resolve()
    command = [sys.executable, str(script), "--root", str(root), "--min-support", str(args.min_support), "--input", f"formal_dataset={trees}"]
    print("running=" + " ".join(command))
    subprocess.run(command, check=True)


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Fixed server-side formula knowledge-base pipeline")
    sub = parser.add_subparsers(dest="command", required=True)
    p = sub.add_parser("inspect", help="Inspect uploaded data without changing it")
    p.add_argument("--data-root", required=True); p.add_argument("--list-members", action="store_true"); p.add_argument("--member-limit", type=int, default=30); p.set_defaults(func=command_inspect)
    p = sub.add_parser("extract", help="Safely extract the uploaded archive")
    p.add_argument("--archive", required=True); p.add_argument("--dest", required=True); p.set_defaults(func=command_extract)
    p = sub.add_parser("index", help="Index JSON metadata and Formula* images")
    p.add_argument("--extracted-root", required=True); p.add_argument("--out", required=True); p.set_defaults(func=command_index)
    p = sub.add_parser("ocr", help="Run local pix2tex with a resumable JSONL checkpoint")
    p.add_argument("--index", required=True); p.add_argument("--out", required=True); p.add_argument("--device", default="auto"); p.add_argument("--resume", action="store_true"); p.add_argument("--limit", type=int, default=0); p.add_argument("--log-every", type=int, default=100); p.add_argument("--ocr-seed-mode", choices=["legacy", "per_formula_v1"], default="legacy"); p.add_argument("--include-screened-non-formula", action="store_true", help="diagnostic only; normally keep visual non-formulas out of OCR"); p.set_defaults(func=command_ocr)
    p = sub.add_parser("analyze", help="Build formula trees and quality-filtered M01-M12 records")
    p.add_argument("--ocr", required=True); p.add_argument("--engine", required=True); p.add_argument("--out-dir", required=True); p.add_argument("--resume", action="store_true"); p.add_argument("--log-every", type=int, default=200); p.set_defaults(func=command_analyze)
    p = sub.add_parser("cluster", help="Run the fixed coarse-to-fine clustering chain")
    p.add_argument("--formula-trees", required=True); p.add_argument("--cluster-script", required=True); p.add_argument("--workspace", required=True); p.add_argument("--min-support", type=int, default=5); p.set_defaults(func=command_cluster)
    return parser


def main() -> None:
    args = build_parser().parse_args()
    args.func(args)


if __name__ == "__main__":
    main()
