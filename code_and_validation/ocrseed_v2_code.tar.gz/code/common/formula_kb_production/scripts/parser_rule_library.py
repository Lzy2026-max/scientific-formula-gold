"""Ordered, versioned interpretation rules for OCR-generated formula text."""

import re

try:
    from math_semantic_registry import INVERSE_TRIG_POWER_ALIASES
except ImportError:
    from scripts.math_semantic_registry import INVERSE_TRIG_POWER_ALIASES


PARSER_RULE_LIBRARY_VERSION = "2026.07.23.v1"

CONDITION_CONNECTOR_WORDS = ("where", "for", "if", "when", "with", "subject to")
CONDITION_CONNECTOR_CJK = (
    "\u5176\u4e2d", "\u5f53", "\u82e5", "\u5982\u679c", "\u5bf9\u4e8e",
    "\u6ee1\u8db3", "\u6761\u4ef6\u4e3a",
)

PARSER_RULES = (
    {
        "id": "R001_top_level_condition_split",
        "priority": 10,
        "stage": "segmentation",
        "action": "store condition separately and classify only the main expression",
    },
    {
        "id": "R002_inverse_trig_power_notation",
        "priority": 20,
        "stage": "semantic_rewrite",
        "action": "interpret f^{-1}(x) as an inverse trig function for registered f",
    },
    {
        "id": "R003_formatted_multiletter_identifier",
        "priority": 30,
        "stage": "tokenization",
        "action": "preserve formatted multi-letter scientific identifiers as atoms",
    },
    {
        "id": "R004_relation_chain_preservation",
        "priority": 40,
        "stage": "tree_construction",
        "action": "preserve every top-level relation instead of collapsing chained equations",
    },
)


def inverse_trig_power_pattern():
    source_names = "|".join(sorted(map(re.escape, INVERSE_TRIG_POWER_ALIASES), key=len, reverse=True))
    return re.compile(
        r"\\(" + source_names + r")\s*\^\s*"
        r"(?:\{\s*-\s*1\s*\}|\(\s*-\s*1\s*\))\s*"
        r"(\{[^{}]+\}|\([^()]+\)|\\[A-Za-z]+|[A-Za-z][A-Za-z0-9_]*)"
    )


def ordered_parser_rules():
    return tuple(sorted(PARSER_RULES, key=lambda rule: rule["priority"]))

