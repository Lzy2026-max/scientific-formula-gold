"""Versioned mathematical symbol semantics used by the formula parser."""

SEMANTIC_REGISTRY_VERSION = "2026.07.23.v1"


def _function(canonical, family, arity=1, classification="generic"):
    return {
        "canonical": canonical,
        "family": family,
        "arity": arity,
        "classification": classification,
    }


FUNCTION_SEMANTICS = {
    "sin": _function("sin", "trigonometric", classification="m08_candidate"),
    "cos": _function("cos", "trigonometric"),
    "tan": _function("tan", "trigonometric"),
    "cot": _function("cot", "trigonometric"),
    "sec": _function("sec", "trigonometric"),
    "csc": _function("csc", "trigonometric"),
    "sinh": _function("sinh", "hyperbolic"),
    "cosh": _function("cosh", "hyperbolic"),
    "tanh": _function("tanh", "hyperbolic"),
    "asin": _function("asin", "inverse_trigonometric", classification="special_nested"),
    "acos": _function("acos", "inverse_trigonometric", classification="special_nested"),
    "atan": _function("atan", "inverse_trigonometric", classification="special_nested"),
    "acot": _function("acot", "inverse_trigonometric", classification="special_nested"),
    "asec": _function("asec", "inverse_trigonometric", classification="special_nested"),
    "acsc": _function("acsc", "inverse_trigonometric", classification="special_nested"),
    "arcsin": _function("asin", "inverse_trigonometric", classification="special_nested"),
    "arccos": _function("acos", "inverse_trigonometric", classification="special_nested"),
    "arctan": _function("atan", "inverse_trigonometric", classification="special_nested"),
    "arccot": _function("acot", "inverse_trigonometric", classification="special_nested"),
    "arcsec": _function("asec", "inverse_trigonometric", classification="special_nested"),
    "arccsc": _function("acsc", "inverse_trigonometric", classification="special_nested"),
    "log": _function("log", "logarithmic", classification="special_nested"),
    "ln": _function("ln", "logarithmic", classification="special_nested"),
    "exp": _function("exp", "exponential", classification="special_nested"),
    "sqrt": _function("sqrt", "radical"),
    "abs": _function("abs", "magnitude"),
    "min": _function("min", "aggregation", arity="variadic"),
    "max": _function("max", "aggregation", arity="variadic"),
    "det": _function("det", "linear_algebra"),
    "ker": _function("ker", "linear_algebra"),
}

INVERSE_TRIG_POWER_ALIASES = {
    "sin": "asin", "cos": "acos", "tan": "atan",
    "cot": "acot", "sec": "asec", "csc": "acsc",
}

CONSTANT_SYMBOLS = {"c", "C", "const", "constant", "pi", "e"}

# These are examples and validation fixtures, not a closed vocabulary. The
# parser also protects formatted multi-letter identifiers generically.
ATOMIC_MULTILETTER_IDENTIFIERS = {
    "Vinitial", "Vfinal", "FWHM", "FSPG", "InAs", "Clarke", "silica",
}

SPECIAL_NESTED_FUNCTIONS = {
    name for name, semantics in FUNCTION_SEMANTICS.items()
    if semantics["classification"] == "special_nested"
} | {"sin"}


def canonical_function_name(name):
    semantics = FUNCTION_SEMANTICS.get(name)
    return semantics["canonical"] if semantics else name

