"""Shared LaTeX command registry for OCR validation and formula parsing."""

try:
    from math_semantic_registry import FUNCTION_SEMANTICS
except ImportError:
    from scripts.math_semantic_registry import FUNCTION_SEMANTICS

REGISTRY_VERSION = "2026.07.23.v3.4"

SAFE_LAYOUT_COMMANDS = {
    "displaystyle", "textstyle", "scriptstyle", "scriptscriptstyle",
    "tiny", "scriptsize", "footnotesize", "small", "normalsize", "large",
    "Large", "LARGE", "huge", "Huge", "left", "right", "big", "Big",
    "bigg", "Bigg", "limits", "nolimits", "quad", "qquad",
}

SPACING_COMMANDS = {
    ",", ";", ":", "!", " ", "enspace", "hspace", "hspace*", "kern",
    "mkern", "thinspace", "medspace", "thickspace",
}

FUNCTION_COMMANDS = set(FUNCTION_SEMANTICS)

SEMANTIC_ATOM_COMMANDS = {
    "alpha", "beta", "gamma", "delta", "epsilon", "varepsilon", "zeta",
    "eta", "theta", "vartheta", "iota", "kappa", "lambda", "mu", "nu",
    "xi", "omicron", "pi", "varpi", "rho", "varrho", "sigma", "varsigma",
    "tau", "upsilon", "phi", "varphi", "chi", "psi", "omega", "Gamma",
    "Delta", "Theta", "Lambda", "Xi", "Pi", "Sigma", "Upsilon", "Phi",
    "Psi", "Omega", "partial", "nabla", "infty", "ell", "hbar", "jmath",
    "imath", "dagger", "ddagger", "prime", "top", "perp", "Re", "Im",
}

RELATION_COMMANDS = {
    "le": "<=", "leq": "<=", "ge": ">=", "geq": ">=", "ne": "!=",
    "neq": "!=", "approx": "~=", "simeq": "~=", "sim": "~",
    "equiv": "==", "to": "->", "rightarrow": "->", "longrightarrow": "->",
    "mapsto": "|->", "in": "in", "notin": "notin", "subset": "subset",
    "subseteq": "subseteq", "supset": "supset", "supseteq": "supseteq",
    "pm": "+-", "mp": "-+",
}

STRUCTURAL_COMMANDS = {
    "frac", "dfrac", "tfrac", "int", "iint", "iiint", "oint", "sum",
    "prod", "lim", "begin", "end", "array", "matrix", "pmatrix", "bmatrix",
    "vmatrix", "Vmatrix", "cases", "stackrel", "overset", "underset",
    "overline", "underline", "underbrace", "overbrace", "sqrt",
}

WRAPPER_COMMANDS = {
    "mathrm", "mathbf", "mathit", "mathsf", "mathtt", "mathcal", "mathbb",
    "mathfrak", "operatorname", "text", "textrm", "textit", "textbf",
    "boldsymbol", "bm", "vec", "hat", "widehat", "bar", "dot", "ddot",
    "tilde", "widetilde",
}

ALL_KNOWN_COMMANDS = (
    SAFE_LAYOUT_COMMANDS | SPACING_COMMANDS | FUNCTION_COMMANDS |
    SEMANTIC_ATOM_COMMANDS | set(RELATION_COMMANDS) | STRUCTURAL_COMMANDS |
    WRAPPER_COMMANDS
)


def command_boundary(name):
    """Return a command regex that also matches before '_' and '{'."""
    import re
    return r"\\" + re.escape(name) + r"(?![A-Za-z])"
