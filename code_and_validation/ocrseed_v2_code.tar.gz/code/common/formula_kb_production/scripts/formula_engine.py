#!/usr/bin/env python
"""Formula decomposition knowledge-base demo.

This script supports the practical local-PDF workflow:

1. put PDF books/papers in a local folder;
2. auto-generate a literature CSV;
3. auto-extract formula candidates and their source locations into CSV;
4. run this script again to normalize formulas, build syntax trees, and
   optionally produce simple pattern statistics.

The PDF inventory step uses PyMuPDF when available for metadata/page count and
falls back to filename-only metadata otherwise. Formula extraction never invents
formulas: TeX/arXiv sources are copied from source text; plain PDF formulas are
best-effort transcriptions of page text and are marked as needing review.
"""

import argparse
import base64
import csv
import difflib
import io
import json
import os
import re
import shutil
import subprocess
import sys
import tarfile
import urllib.request
import xml.etree.ElementTree as ET
from collections import Counter, defaultdict
from dataclasses import dataclass, field
from datetime import datetime

try:
    from latex_command_registry import (
        ALL_KNOWN_COMMANDS, FUNCTION_COMMANDS, REGISTRY_VERSION,
        RELATION_COMMANDS, SAFE_LAYOUT_COMMANDS, SEMANTIC_ATOM_COMMANDS,
        SPACING_COMMANDS, STRUCTURAL_COMMANDS, WRAPPER_COMMANDS,
        command_boundary,
    )
except ImportError:
    from scripts.latex_command_registry import (
        ALL_KNOWN_COMMANDS, FUNCTION_COMMANDS, REGISTRY_VERSION,
        RELATION_COMMANDS, SAFE_LAYOUT_COMMANDS, SEMANTIC_ATOM_COMMANDS,
        SPACING_COMMANDS, STRUCTURAL_COMMANDS, WRAPPER_COMMANDS,
        command_boundary,
    )

try:
    from math_semantic_registry import (
        CONSTANT_SYMBOLS, INVERSE_TRIG_POWER_ALIASES,
        SPECIAL_NESTED_FUNCTIONS,
    )
    from parser_rule_library import (
        CONDITION_CONNECTOR_CJK, CONDITION_CONNECTOR_WORDS,
        inverse_trig_power_pattern,
    )
except ImportError:
    from scripts.math_semantic_registry import (
        CONSTANT_SYMBOLS, INVERSE_TRIG_POWER_ALIASES,
        SPECIAL_NESTED_FUNCTIONS,
    )
    from scripts.parser_rule_library import (
        CONDITION_CONNECTOR_CJK, CONDITION_CONNECTOR_WORDS,
        inverse_trig_power_pattern,
    )


FUNCTION_NAMES = set(FUNCTION_COMMANDS) | {
    "f", "g", "h", "F", "G", "H", "D", "Theta",
    "matrix", "cases", "sum", "prod", "int", "lim",
}
GENERIC_FUNCTION_NAMES = {"f", "g", "h", "F", "G", "H"}
SYMBOLIC_FUNCTION_BASES = GENERIC_FUNCTION_NAMES | {
    "x", "y", "z", "phi", "theta", "psi", "Phi", "Theta", "Psi",
}


@dataclass
class ParseDiagnostics:
    parse_mode: str = "standard"
    semantic_coverage: float = 1.0
    dropped_semantic_commands: list = field(default_factory=list)
    repaired_delimiter_count: int = 0
    raw_math_token_count: int = 0
    normalized_math_token_count: int = 0
    original_error: str = ""
    normalization_semantic_coverage: float = 1.0
    raw_structure_signature: dict = field(default_factory=dict)
    tree_structure_signature: dict = field(default_factory=dict)
    tree_fidelity_status: str = "not_checked"
    tree_fidelity_reasons: list = field(default_factory=list)
    raw_expression_count: int = 1
    parsed_expression_count: int = 0
    discarded_expression_spans: list = field(default_factory=list)
    segmentation_status: str = "single_expression"
    ambiguous_symbolic_calls: list = field(default_factory=list)
    main_expression_latex: str = ""
    condition_spans: list = field(default_factory=list)
    condition_connector: str = ""


RELATION_OPS = {"=", "==", "<=", ">=", "!=", "~=", "~", "->", "|->"}
SCRIPT_END = "@"
FORMAT_ATOM_JOIN = "\x1d"
ATOM_SEPARATOR = "\x1e"
RELATION_APPROX_PLACEHOLDER = "\x1f"

UNICODE_LATEX_REPLACEMENTS = {
    "α": r"\alpha",
    "β": r"\beta",
    "γ": r"\gamma",
    "δ": r"\delta",
    "ε": r"\epsilon",
    "θ": r"\theta",
    "λ": r"\lambda",
    "μ": r"\mu",
    "ν": r"\nu",
    "π": r"\pi",
    "ρ": r"\rho",
    "σ": r"\sigma",
    "τ": r"\tau",
    "φ": r"\phi",
    "ω": r"\omega",
    "ξ": r"\xi",
    "Γ": r"\Gamma",
    "Δ": r"\Delta",
    "Θ": r"\Theta",
    "Λ": r"\Lambda",
    "Π": r"\Pi",
    "Σ": r"\Sigma",
    "Φ": r"\Phi",
    "Ω": r"\Omega",
    "∂": r"\partial",
    "∇": r"\nabla",
    "∑": r"\sum",
    "∫": r"\int",
    "∞": r"\infty",
    "√": r"\sqrt",
    "≤": r"\le",
    "≥": r"\ge",
    "≠": r"\ne",
    "≈": r"\approx",
    "→": r"\to",
    "←": r"\leftarrow",
    "×": "*",
    "⋅": "*",
    "·": "*",
    "−": "-",
    "–": "-",
    "—": "-",
}

SUPERSCRIPT_REPLACEMENTS = {
    "⁰": "^{0}",
    "¹": "^{1}",
    "²": "^{2}",
    "³": "^{3}",
    "⁴": "^{4}",
    "⁵": "^{5}",
    "⁶": "^{6}",
    "⁷": "^{7}",
    "⁸": "^{8}",
    "⁹": "^{9}",
    "⁺": "^{+}",
    "⁻": "^{-}",
    "ⁿ": "^{n}",
}

SUBSCRIPT_REPLACEMENTS = {
    "₀": "_{0}",
    "₁": "_{1}",
    "₂": "_{2}",
    "₃": "_{3}",
    "₄": "_{4}",
    "₅": "_{5}",
    "₆": "_{6}",
    "₇": "_{7}",
    "₈": "_{8}",
    "₉": "_{9}",
}

GREEK_REPLACEMENTS = {
    r"\alpha": "alpha",
    r"\beta": "beta",
    r"\gamma": "gamma",
    r"\delta": "delta",
    r"\epsilon": "epsilon",
    r"\varepsilon": "epsilon",
    r"\theta": "theta",
    r"\lambda": "lambda",
    r"\mu": "mu",
    r"\nu": "nu",
    r"\pi": "pi",
    r"\rho": "rho",
    r"\sigma": "sigma",
    r"\tau": "tau",
    r"\phi": "phi",
    r"\omega": "omega",
    r"\xi": "xi",
    r"\chi": "chi",
    r"\eta": "eta",
    r"\zeta": "zeta",
    r"\varphi": "varphi",
    r"\upsilon": "upsilon",
    r"\Delta": "Delta",
    r"\Theta": "Theta",
    r"\Lambda": "Lambda",
    r"\Pi": "Pi",
    r"\Gamma": "Gamma",
    r"\Sigma": "Sigma",
    r"\Phi": "Phi",
    r"\Omega": "Omega",
    r"\Psi": "Psi",
    r"\Xi": "Xi",
    r"\Upsilon": "Upsilon",
    r"\jmath": "jmath",
    r"\imath": "imath",
    r"\hbar": "hbar",
}

TEX_ATOM_COMMANDS = (
    r"alpha|beta|gamma|delta|epsilon|varepsilon|theta|lambda|mu|nu|pi|"
    r"rho|sigma|tau|phi|varphi|omega|xi|chi|eta|zeta|upsilon|"
    r"Gamma|Delta|Theta|Lambda|Xi|Pi|Sigma|Upsilon|Phi|Psi|Omega|"
    r"jmath|imath|hbar"
)
TEX_FUNCTION_COMMANDS = r"sin|cos|tan|log|ln|exp|sqrt"

PDF_TEXT_REPLACEMENTS = {
    "≤": r"\le",
    "≥": r"\ge",
    "≠": r"\ne",
    "≈": r"\approx",
    "∼": r"\approx",
    "→": r"\to",
    "←": r"\leftarrow",
    "∞": r"\infty",
    "∂": r"\partial",
    "∇": r"\nabla",
    "∑": r"\sum",
    "∏": r"\prod",
    "∫": r"\int",
    "√": r"\sqrt",
    "×": "*",
    "·": "*",
    "⋅": "*",
    "−": "-",
    "–": "-",
    "—": "-",
    "°": "",
    "⎛": "(",
    "⎝": "(",
    "⎞": ")",
    "⎠": ")",
    "α": r"\alpha",
    "β": r"\beta",
    "γ": r"\gamma",
    "δ": r"\delta",
    "ε": r"\epsilon",
    "θ": r"\theta",
    "λ": r"\lambda",
    "μ": r"\mu",
    "ν": r"\nu",
    "π": r"\pi",
    "ρ": r"\rho",
    "σ": r"\sigma",
    "τ": r"\tau",
    "φ": r"\phi",
    "ω": r"\omega",
    "ξ": r"\xi",
    "Δ": r"\Delta",
    "Θ": r"\Theta",
}

PDF_SUPERSCRIPT_REPLACEMENTS = {
    "⁰": "^{0}",
    "¹": "^{1}",
    "²": "^{2}",
    "³": "^{3}",
    "⁴": "^{4}",
    "⁵": "^{5}",
    "⁶": "^{6}",
    "⁷": "^{7}",
    "⁸": "^{8}",
    "⁹": "^{9}",
    "⁺": "^{+}",
    "⁻": "^{-}",
    "ⁿ": "^{n}",
}

PDF_SUBSCRIPT_REPLACEMENTS = {
    "₀": "_{0}",
    "₁": "_{1}",
    "₂": "_{2}",
    "₃": "_{3}",
    "₄": "_{4}",
    "₅": "_{5}",
    "₆": "_{6}",
    "₇": "_{7}",
    "₈": "_{8}",
    "₉": "_{9}",
}

GREEK_WORD_NAMES = tuple(sorted({
    "alpha", "beta", "gamma", "delta", "epsilon", "theta", "lambda",
    "mu", "nu", "pi", "rho", "sigma", "tau", "phi", "omega", "xi",
    "Gamma", "Delta", "Theta", "Lambda", "Xi", "Pi", "Sigma",
    "Upsilon", "Phi", "Psi", "Omega",
}, key=len, reverse=True))


def normalize_pdf_math_text(text):
    text = text or ""
    for src, dst in PDF_TEXT_REPLACEMENTS.items():
        text = text.replace(src, dst)
    for src, dst in PDF_SUPERSCRIPT_REPLACEMENTS.items():
        text = text.replace(src, dst)
    for src, dst in PDF_SUBSCRIPT_REPLACEMENTS.items():
        text = text.replace(src, dst)
    return text


def split_greek_letter_products(text):
    """Split compact PDF physics notation such as alphaLDeltaT."""
    for name in GREEK_WORD_NAMES:
        text = re.sub(r"\b(%s)(?=[A-Z])" % name, r"\1*", text)
        text = re.sub(r"(?<=[A-Z0-9])(%s)(?=[A-Z])" % name, r"*\1*", text)
    text = re.sub(r"\*+", "*", text)
    text = re.sub(r"\*(?=[=+\-*/^),])", "", text)
    text = re.sub(r"(?<=[(=+\-*/^,])\*", "", text)
    return text


SOURCE_FIELDS = [
    "source_id",
    "source_group",
    "domain",
    "type",
    "title",
    "authors_or_editor",
    "year",
    "journal",
    "conference",
    "publisher",
    "doi",
    "published_date",
    "arxiv_id",
    "primary_category",
    "categories",
    "local_path",
    "pdf_url",
    "source_url",
    "file_name",
    "file_size_bytes",
    "modified",
    "page_count",
    "notes",
]

FORMULA_FIELDS = [
    "formula_id",
    "source_id",
    "source_title",
    "chapter",
    "section",
    "page",
    "equation_number",
    "locator",
    "extraction_method",
    "formula_latex",
    "raw_text",
    "context_before",
    "context_after",
    "screenshot_path",
    "bbox",
    "source_file",
    "confidence",
    "needs_review",
    "note",
    "parse_status",
    "parse_error",
    "validity_status",
    "exclude_reason",
    "normalized_formula",
    "formula_tree_prefix",
    "analysis_target_prefix",
    "root_operator",
    "root_pattern",
    "layer_pattern",
    "function_nodes",
    "has_constant_or_coefficient",
    "variable_sets",
    "variable_overlap_status",
    "tree_depth",
    "top_signature",
    "subtree_pattern_tags",
    "operator_path_signatures",
    "nested_function_patterns",
    "pattern_tags",
    "formula_level_tags",
    "pattern_occurrence_counts",
    "matched_pattern_templates",
    "candidate_formula_level_tags",
    "candidate_pattern_occurrence_counts",
]

DOCUMENT_EXTENSIONS = (".pdf", ".tex", ".latex")
PDF_EXTENSIONS = (".pdf",)
TEX_EXTENSIONS = (".tex", ".latex")
IMAGE_EXTENSIONS = (".png", ".jpg", ".jpeg", ".tif", ".tiff", ".bmp")
PDF_TEXT_EXTRACTION_METHODS = {"pdf_text_line", "pdf_text_block"}
ARXIV_ATOM = "{http://www.w3.org/2005/Atom}"
ARXIV_NS = "{http://arxiv.org/schemas/atom}"
ARXIV_SOURCE_TIMEOUT_SECONDS = float(os.environ.get("FORMULA_KB_ARXIV_SOURCE_TIMEOUT", "25"))
ARXIV_SOURCE_MAX_BYTES = int(os.environ.get("FORMULA_KB_ARXIV_SOURCE_MAX_BYTES", str(12 * 1024 * 1024)))

SOURCE_PROCESSING_PLAN_FIELDS = [
    "source_id",
    "priority",
    "source_kind",
    "preferred_channel",
    "fallback_channels",
    "route_reason",
    "arxiv_id",
    "type",
    "title",
    "local_path",
    "pdf_url",
]

SOURCE_ROUTE_SUMMARY_FIELDS = [
    "priority",
    "source_kind",
    "preferred_channel",
    "source_count",
    "parsed_formula_count",
    "valid_core_formula_count",
    "excluded_parsed_formula_count",
    "parse_failure_count",
]

EXTRACTION_PREFILTER_REJECTION_FIELDS = [
    "source_id",
    "locator",
    "extraction_method",
    "prefilter_status",
    "prefilter_reason",
    "normalized_formula",
    "candidate_formula_level_tags",
    "formula_latex",
    "raw_text",
]


class ParseError(Exception):
    pass


class Node:
    def __init__(self, kind, value, children=None, attributes=None):
        self.kind = kind
        self.value = value
        self.children = children or []
        self.attributes = attributes or {}

    def to_dict(self):
        result = {
            "kind": self.kind,
            "value": self.value,
            "children": [child.to_dict() for child in self.children],
        }
        if self.attributes:
            result["attributes"] = self.attributes
        return result

    def preorder(self):
        if not self.children:
            return str(self.value)
        if self.kind == "relation_chain":
            operators = self.attributes.get("operators", [])
            parts = []
            for index, child in enumerate(self.children):
                if index:
                    parts.append(operators[index - 1] if index - 1 < len(operators) else "?")
                parts.append(child.preorder())
            return "(relation_chain " + " ".join(parts) + ")"
        return "(" + " ".join([str(self.value)] + [c.preorder() for c in self.children]) + ")"

    def depth(self):
        if not self.children:
            return 1
        return 1 + max(child.depth() for child in self.children)

    def leaf_values(self):
        if not self.children:
            return [self.value]
        values = []
        for child in self.children:
            values.extend(child.leaf_values())
        return values

    def contains_value(self, values):
        if self.value in values:
            return True
        return any(child.contains_value(values) for child in self.children)

    def contains_kind(self, kind):
        if self.kind == kind:
            return True
        return any(child.contains_kind(kind) for child in self.children)

    def has_child_value(self, values):
        return any(child.value in values for child in self.children)


def read_csv(path):
    with open(path, "r", newline="", encoding="utf-8") as f:
        return list(csv.DictReader(f))


def read_csv_if_exists(path):
    if not os.path.exists(path):
        return []
    return read_csv(path)


def manifest_key_from_path(path):
    if not path:
        return ""
    return os.path.basename(path).strip().lower()


def load_metadata_manifest(path):
    if not path:
        return {}
    rows = read_csv_if_exists(path)
    by_key = {}
    for row in rows:
        for value in (
            row.get("local_path", ""),
            row.get("file_path", ""),
            row.get("file_name", ""),
            row.get("downloaded_file", ""),
        ):
            key = manifest_key_from_path(value)
            if key:
                by_key[key] = row
    return by_key


def apply_manifest_metadata(source_row, manifest_row):
    if not manifest_row:
        return source_row
    mapping = {
        "source_group": "source_group",
        "domain": "domain",
        "type": "type",
        "title": "title",
        "authors_or_editor": "authors_or_editor",
        "year": "year",
        "journal": "journal",
        "conference": "conference",
        "publisher": "publisher",
        "doi": "doi",
        "published_date": "published_date",
        "arxiv_id": "arxiv_id",
        "primary_category": "primary_category",
        "categories": "categories",
        "source_url": "source_url",
        "pdf_url": "original_pdf_url",
    }
    for target, source in mapping.items():
        value = manifest_row.get(source, "")
        if value:
            source_row[target] = value
    if manifest_row.get("domain"):
        note = source_row.get("notes", "")
        source_row["notes"] = (note + "; domain=%s" % manifest_row["domain"]).strip("; ")
    if manifest_row.get("source_group"):
        note = source_row.get("notes", "")
        source_row["notes"] = (note + "; source_group=%s" % manifest_row["source_group"]).strip("; ")
    return source_row


def write_csv(path, fieldnames, rows):
    parent = os.path.dirname(path)
    if parent:
        ensure_dir(parent)
    with open(path, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        for row in rows:
            writer.writerow({name: clean_csv_cell(row.get(name, "")) for name in fieldnames})


def is_data_row(row, id_field, description_label):
    value = str(row.get(id_field, "") or "").strip()
    return bool(value) and value != description_label


def clean_csv_cell(value):
    if value is None:
        return ""
    text = str(value)
    text = text.replace("\x00", "")
    text = re.sub(r"[\x01-\x08\x0b\x0c\x0e-\x1f]", " ", text)
    return text


def normalize_path(path):
    return os.path.normcase(os.path.abspath(path))


def document_paths(doc_dir, recursive=False, extensions=DOCUMENT_EXTENSIONS):
    doc_dir = os.path.abspath(doc_dir)
    paths = []
    if recursive:
        for root, _, files in os.walk(doc_dir):
            for name in files:
                if name.lower().endswith(extensions):
                    paths.append(os.path.join(root, name))
    else:
        if os.path.isdir(doc_dir):
            for name in os.listdir(doc_dir):
                path = os.path.join(doc_dir, name)
                if os.path.isfile(path) and name.lower().endswith(extensions):
                    paths.append(path)
    return sorted(paths, key=lambda item: os.path.basename(item).lower())


def pdf_paths(pdf_dir, recursive=False):
    return document_paths(pdf_dir, recursive=recursive, extensions=PDF_EXTENSIONS)


def filename_to_title(path):
    name = os.path.splitext(os.path.basename(path))[0]
    name = re.sub(r"[_\-]+", " ", name)
    name = re.sub(r"\s+", " ", name).strip()
    return name or os.path.basename(path)


def year_from_text(text):
    match = re.search(r"(19|20)\d{2}", text or "")
    return match.group(0) if match else ""


def read_pdf_metadata(path):
    metadata = {
        "title": "",
        "author": "",
        "year": "",
        "page_count": "",
        "metadata_status": "filename_only",
    }
    try:
        import fitz  # PyMuPDF is present in the current Anaconda environment.
    except Exception as exc:
        metadata["metadata_status"] = "pymupdf_unavailable: %s" % exc
        return metadata

    try:
        doc = fitz.open(path)
        try:
            info = doc.metadata or {}
            metadata["title"] = (info.get("title") or "").strip()
            metadata["author"] = (info.get("author") or "").strip()
            metadata["page_count"] = str(doc.page_count)
            date_text = " ".join([
                info.get("creationDate") or "",
                info.get("modDate") or "",
                metadata["title"],
                os.path.basename(path),
            ])
            metadata["year"] = year_from_text(date_text)
            metadata["metadata_status"] = "ok"
        finally:
            doc.close()
    except Exception as exc:
        metadata["metadata_status"] = "pdf_metadata_error: %s" % exc
    return metadata


def next_local_source_id(existing_sources):
    used = {row.get("source_id", "") for row in existing_sources}
    next_number = 1
    for row in existing_sources:
        match = re.match(r"P(\d+)$", row.get("source_id", ""))
        if match:
            next_number = max(next_number, int(match.group(1)) + 1)
    while True:
        candidate = "P%03d" % next_number
        if candidate not in used:
            return candidate
        next_number += 1


def source_key(row):
    location = row.get("local_path") or row.get("pdf_url", "")
    if not location:
        return ""
    if re.match(r"https?://", location, re.IGNORECASE):
        return location.strip().lower()
    return normalize_path(location)


def read_tex_metadata(path):
    metadata = {
        "title": "",
        "author": "",
        "year": "",
        "page_count": "",
        "metadata_status": "tex_header_only",
    }
    try:
        with open(path, "r", encoding="utf-8", errors="ignore") as f:
            text = f.read(12000)
    except Exception as exc:
        metadata["metadata_status"] = "tex_metadata_error: %s" % exc
        return metadata

    title_match = re.search(r"\\title\s*\{([^{}]+)\}", text, re.DOTALL)
    author_match = re.search(r"\\author\s*\{([^{}]+)\}", text, re.DOTALL)
    if title_match:
        metadata["title"] = " ".join(title_match.group(1).split())
    if author_match:
        metadata["author"] = " ".join(author_match.group(1).split())
    metadata["year"] = year_from_text(text) or year_from_text(os.path.basename(path))
    return metadata


def empty_publication_metadata():
    return {
        "journal": "",
        "conference": "",
        "publisher": "",
        "doi": "",
        "published_date": "",
        "arxiv_id": "",
        "primary_category": "",
        "categories": "",
        "title": "",
        "authors": "",
        "year": "",
    }


def fetch_arxiv_metadata(arxiv_id):
    metadata = empty_publication_metadata()
    if not arxiv_id:
        return metadata
    url = "https://export.arxiv.org/api/query?id_list=%s" % arxiv_id
    try:
        request = urllib.request.Request(
            url,
            headers={"User-Agent": "formula-kb-demo/0.1 (local academic demo)"},
        )
        with urllib.request.urlopen(request, timeout=60) as response:
            root = ET.fromstring(response.read())
    except Exception:
        metadata["arxiv_id"] = arxiv_id
        return metadata

    entry = root.find(ARXIV_ATOM + "entry")
    if entry is None:
        metadata["arxiv_id"] = arxiv_id
        return metadata

    metadata["arxiv_id"] = arxiv_id
    metadata["title"] = " ".join(entry.findtext(ARXIV_ATOM + "title", default="").split())
    metadata["published_date"] = entry.findtext(ARXIV_ATOM + "published", default="")
    metadata["year"] = year_from_text(metadata["published_date"])
    authors = []
    for author in entry.findall(ARXIV_ATOM + "author"):
        name = author.findtext(ARXIV_ATOM + "name", default="")
        if name:
            authors.append(name)
    metadata["authors"] = "; ".join(authors)
    journal_ref = entry.findtext(ARXIV_NS + "journal_ref", default="")
    metadata["journal"] = " ".join(journal_ref.split())
    doi = entry.findtext(ARXIV_NS + "doi", default="")
    metadata["doi"] = doi.strip()
    primary = entry.find(ARXIV_NS + "primary_category")
    if primary is not None:
        metadata["primary_category"] = primary.attrib.get("term", "")
    categories = []
    for category in entry.findall(ARXIV_ATOM + "category"):
        term = category.attrib.get("term", "")
        if term:
            categories.append(term)
    metadata["categories"] = "; ".join(categories)
    metadata["publisher"] = "arXiv"
    return metadata


def build_source_row(source_id, path, metadata_hint=None):
    ext = os.path.splitext(path)[1].lower()
    if ext in TEX_EXTENSIONS:
        meta = read_tex_metadata(path)
        source_type = "local_tex"
    else:
        meta = read_pdf_metadata(path)
        source_type = "local_pdf"

    title = meta["title"] or filename_to_title(path)
    author = meta["author"]
    year = meta["year"] or year_from_text(os.path.basename(path))
    pub_meta = empty_publication_metadata()
    metadata_hint = metadata_hint or {}
    arxiv_id = metadata_hint.get("arxiv_id", "")
    if arxiv_id:
        pub_meta.update({
            "arxiv_id": arxiv_id,
            "title": metadata_hint.get("title", ""),
            "authors": metadata_hint.get("authors_or_editor", ""),
            "year": metadata_hint.get("year", ""),
            "journal": metadata_hint.get("journal", ""),
            "publisher": metadata_hint.get("publisher", ""),
            "doi": metadata_hint.get("doi", ""),
            "published_date": metadata_hint.get("published_date", ""),
            "primary_category": metadata_hint.get("primary_category", ""),
            "categories": metadata_hint.get("categories", ""),
        })
    else:
        arxiv_id = arxiv_id_from_text(os.path.basename(path))
        if not arxiv_id and ext in PDF_EXTENSIONS:
            arxiv_id = detect_arxiv_id_from_pdf(path)
        if arxiv_id:
            pub_meta = fetch_arxiv_metadata(arxiv_id)
        title = pub_meta.get("title") or title
        author = pub_meta.get("authors") or author
        year = pub_meta.get("year") or year
    size = os.path.getsize(path)
    modified = datetime.fromtimestamp(os.path.getmtime(path)).strftime("%Y-%m-%d %H:%M:%S")
    note_parts = [
        "%s=1" % source_type,
        "file_name=%s" % os.path.basename(path),
        "file_size_bytes=%s" % size,
        "modified=%s" % modified,
        "page_count=%s" % meta["page_count"],
        "metadata_status=%s" % meta["metadata_status"],
    ]
    return {
        "source_id": source_id,
        "type": source_type,
        "title": title,
        "authors_or_editor": author,
        "year": year,
        "journal": pub_meta.get("journal", ""),
        "conference": pub_meta.get("conference", ""),
        "publisher": pub_meta.get("publisher", ""),
        "doi": pub_meta.get("doi", ""),
        "published_date": pub_meta.get("published_date", ""),
        "arxiv_id": pub_meta.get("arxiv_id", arxiv_id),
        "primary_category": pub_meta.get("primary_category", ""),
        "categories": pub_meta.get("categories", ""),
        "local_path": normalize_path(path),
        "pdf_url": normalize_path(path),
        "source_url": "",
        "file_name": os.path.basename(path),
        "file_size_bytes": str(size),
        "modified": modified,
        "page_count": meta["page_count"],
        "notes": "; ".join(note_parts),
    }


def ensure_formula_template_rows(formula_rows, source_row, rows_per_pdf):
    source_id = source_row["source_id"]
    existing_ids = {row.get("formula_id", "") for row in formula_rows}
    added = 0
    for index in range(1, rows_per_pdf + 1):
        formula_id = "%s_F%03d" % (source_id, index)
        if formula_id in existing_ids:
            continue
        formula_rows.append({
            "formula_id": formula_id,
            "source_id": source_id,
            "source_title": source_row.get("title", ""),
            "chapter": "",
            "section": "",
            "page": "",
            "equation_number": "",
            "locator": "page ?; equation ?",
            "extraction_method": "manual_template",
            "formula_latex": "",
            "raw_text": "",
            "context_before": "",
            "context_after": "",
            "screenshot_path": "",
            "bbox": "",
            "source_file": source_row.get("local_path", source_row.get("pdf_url", "")),
            "confidence": "",
            "needs_review": "1",
            "note": "Fill formula_latex manually or with a large model; keep source/page here.",
        })
        existing_ids.add(formula_id)
        added += 1
    return added


def formula_row_key(row):
    return "|".join([
        row.get("source_id", ""),
        row.get("extraction_method", ""),
        str(row.get("page", "")),
        row.get("equation_number", ""),
        re.sub(r"\s+", " ", row.get("formula_latex") or row.get("raw_text", "")).strip(),
    ])


def next_formula_index(formula_rows, source_id):
    next_number = 1
    for row in formula_rows:
        formula_id = row.get("formula_id", "")
        match = re.match(r"%s_F(\d+)$" % re.escape(source_id), formula_id)
        if match:
            next_number = max(next_number, int(match.group(1)) + 1)
    return next_number


def looks_like_formula_text(text):
    text = normalize_pdf_math_text(text)
    compact = re.sub(r"\s+", "", text or "")
    if len(compact) < 3 or len(compact) > 220:
        return False, 0
    noisy_text = " ".join((text or "").split())
    if re.search(
        r"https?://|www\.|@|copyright|allrightsreserved|isbn|license|"
        r"creative\s*commons|sharealike|commercial|university|journal|doi|"
        r"chapter\s+[0-9]+:|table\s+of\s+contents|print\s+book|main\s+street",
        noisy_text,
        re.I,
    ):
        return False, 0
    allowed = re.findall(
        r"[A-Za-z0-9\s=≈≠≤≥<>+\-−*/×⋅·^_{}()[\],.;:'\"\\|∂∇∑∫√∞πθαβγδλμνσφωΓΔΣΩµ%]",
        text or "",
    )
    if text and len(allowed) / float(len(text)) < 0.82:
        return False, 0

    score = 0
    score += 3 if re.search(r"[=≈≠≤≥<>]", compact) else 0
    score += 2 if re.search(r"[+\-−*/×⋅·^]", compact) else 0
    score += 2 if re.search(r"[∂∇∑∫√∞πθαβγδλμνσφω]", compact) else 0
    score += 1 if re.search(r"\([0-9]+(?:\.[0-9]+)*\)$", compact) else 0
    score += 1 if re.search(r"[A-Za-z][_'′]?[A-Za-z0-9]*\(", compact) else 0
    score += 1 if re.search(r"\d", compact) else 0
    score += 1 if re.search(r"[A-Za-z]", compact) else 0

    word_count = len(re.findall(r"[A-Za-z]{4,}", text or ""))
    symbol_count = len(re.findall(r"[=≈≠≤≥<>+\-−*/×⋅·^_{}()[\]∂∇∑∫√∞]", text or ""))
    strong_symbol_count = len(re.findall(r"[=≈≠≤≥<>+*/×⋅·^_{}()[\]∂∇∑∫√∞πθαβγδλμνσφω]", text or ""))
    has_variable_minus = bool(re.search(r"\b[A-Za-z]\s*[-−]\s*[A-Za-z0-9]\b", text or ""))
    has_function_call = bool(re.search(r"[A-Za-z][_'′]?[A-Za-z0-9]*\(", compact))
    if strong_symbol_count == 0 and not has_variable_minus and not has_function_call:
        return False, score
    if word_count > 10 and symbol_count < 3:
        return False, score
    if word_count > 4 and strong_symbol_count < 2 and not has_function_call:
        return False, score
    return score >= 4, score


def text_to_latexish(text):
    """Transcribe extracted PDF text without inventing missing math structure."""
    text = normalize_pdf_math_text(text)
    text = " ".join((text or "").split())
    equation_number = ""
    eq_match = re.search(r"\s+\(([0-9]+(?:\.[0-9]+)*)\)\s*$", text)
    if eq_match:
        equation_number = eq_match.group(1)
        text = text[:eq_match.start()].strip()

    for src, dst in UNICODE_LATEX_REPLACEMENTS.items():
        text = text.replace(src, dst)
    for src, dst in SUPERSCRIPT_REPLACEMENTS.items():
        text = text.replace(src, dst)
    for src, dst in SUBSCRIPT_REPLACEMENTS.items():
        text = text.replace(src, dst)
    text = text.replace("′", "'")
    text = re.sub(r"\s*([=+\-*/^<>])\s*", r"\1", text)
    text = re.sub(r"\s+", " ", text).strip()
    return text, equation_number


def latex_equation_number(raw):
    tag_match = re.search(r"\\tag\s*\{([^{}]+)\}", raw or "")
    if tag_match:
        return tag_match.group(1).strip()
    label_match = re.search(r"\\label\s*\{([^{}]+)\}", raw or "")
    if label_match:
        return label_match.group(1).strip()
    return ""


def strip_tex_comments(text):
    lines = []
    for line in (text or "").splitlines():
        escaped = False
        cut = len(line)
        for i, char in enumerate(line):
            if char == "\\" and not escaped:
                escaped = True
                continue
            if char == "%" and not escaped:
                cut = i
                break
            escaped = False
        lines.append(line[:cut])
    return "\n".join(lines)


def split_tex_formula_block(raw):
    raw = strip_tex_comments(raw)
    raw = re.sub(r"\\begin\{(?:aligned|split|array|matrix|pmatrix|bmatrix|cases)\}", " ", raw)
    raw = re.sub(r"\\end\{(?:aligned|split|array|matrix|pmatrix|bmatrix|cases)\}", " ", raw)
    parts = re.split(r"\\\\(?:\[[^\]]*\])?|\\cr\b", raw)
    cleaned = []
    for part in parts:
        part = part.replace("&", "")
        part = re.sub(r"\\(?:nonumber|notag)\b", "", part)
        part = re.sub(r"\\label\{[^{}]*\}", "", part)
        part = " ".join(part.split())
        if not part:
            continue
        has_math, _ = looks_like_formula_text(part)
        if has_math or "\\" in part or "=" in part:
            cleaned.append(part)
    return cleaned


def tex_context_before(data, start):
    prefix = data[:start]
    section = ""
    chapter = ""
    for match in re.finditer(r"\\(chapter|section|subsection)\*?\s*\{([^{}]+)\}", prefix, re.DOTALL):
        value = " ".join(match.group(2).split())
        if match.group(1) == "chapter":
            chapter = value
        else:
            section = value
    return chapter, section


def extract_rows_from_tex_text(source_row, data, tex_name, max_formulas):
    rows = []
    for idx, match in enumerate(DISPLAY_ENV_RE.finditer(data), start=1):
        raw = next(group for group in match.groups()[1:] if group)
        chapter, section = tex_context_before(data, match.start())
        block_parts = split_tex_formula_block(raw)
        for part_index, part in enumerate(block_parts, start=1):
            formula = clean_extracted_equation(part)
            if not formula or len(formula) > 1000:
                continue
            rows.append({
                "source_id": source_row["source_id"],
                "source_title": source_row.get("title", ""),
                "chapter": chapter,
                "section": section,
                "page": "",
                "equation_number": latex_equation_number(part) or latex_equation_number(raw),
                "locator": "%s display-equation %d line %d" % (tex_name, idx, part_index),
                "extraction_method": "tex_source",
                "formula_latex": formula,
                "raw_text": part.strip(),
                "context_before": "",
                "context_after": "",
                "screenshot_path": "",
                "bbox": "",
                "source_file": source_row.get("local_path", source_row.get("pdf_url", "")),
                "confidence": "0.95",
                "needs_review": "0",
                "note": "Copied from TeX display math; not generated.",
            })
            if len(rows) >= max_formulas:
                break
        if len(rows) >= max_formulas:
            break
    return rows


def extract_formulas_from_local_tex(source_row, max_formulas):
    path = source_row.get("local_path") or source_row.get("pdf_url", "")
    try:
        with open(path, "r", encoding="utf-8", errors="ignore") as f:
            data = f.read()
    except Exception:
        return []
    return extract_rows_from_tex_text(source_row, data, os.path.basename(path), max_formulas)


def arxiv_id_from_text(text):
    if not text:
        return ""
    match = re.search(r"arXiv[:\s]*([0-9]{4}\.[0-9]{4,5})(?:v[0-9]+)?", text, re.I)
    if match:
        return match.group(1)
    match = re.search(r"(?<![0-9])([0-9]{4}\.[0-9]{4,5})(?:v[0-9]+)?(?![0-9])", text)
    if match:
        return match.group(1)
    return ""


def source_arxiv_id(source_row):
    fields = [
        "arxiv_id", "pdf_url", "source_url", "local_path", "file_name",
        "title", "notes",
    ]
    for field in fields:
        candidate = arxiv_id_from_text(source_row.get(field, ""))
        if candidate:
            return candidate
    return ""


def detect_arxiv_id_from_pdf(path):
    candidate = arxiv_id_from_text(os.path.basename(path))
    if candidate:
        return candidate
    try:
        import fitz
        doc = fitz.open(path)
        try:
            meta_text = " ".join(str(value or "") for value in (doc.metadata or {}).values())
            candidate = arxiv_id_from_text(meta_text)
            if candidate:
                return candidate
            max_pages = min(2, doc.page_count)
            first_text = "\n".join(doc.load_page(i).get_text("text") for i in range(max_pages))
            return arxiv_id_from_text(first_text)
        finally:
            doc.close()
    except Exception:
        return ""


def append_source_note(source_row, note):
    if not note:
        return
    current = source_row.get("notes", "")
    if note in current:
        return
    source_row["notes"] = (current + "; " + note).strip("; ")


def source_document_path(source_row):
    return source_row.get("local_path") or source_row.get("pdf_url", "")


def is_probably_scanned_pdf(path, max_pages=3):
    if not path or not os.path.exists(path):
        return False
    try:
        import fitz
        doc = fitz.open(path)
    except Exception:
        return False
    try:
        page_count = min(max_pages, doc.page_count)
        if page_count <= 0:
            return False
        text_chars = 0
        image_blocks = 0
        text_blocks = 0
        for page_index in range(page_count):
            page = doc.load_page(page_index)
            text_chars += len((page.get_text("text") or "").strip())
            for block in (page.get_text("dict") or {}).get("blocks", []):
                if block.get("type") == 0:
                    text_blocks += 1
                elif block.get("type") == 1:
                    image_blocks += 1
        avg_text_chars = text_chars / float(page_count)
        return avg_text_chars < 80 and image_blocks > max(0, text_blocks)
    except Exception:
        return False
    finally:
        doc.close()


def classify_source_processing(source_row):
    path = source_document_path(source_row)
    ext = os.path.splitext(path)[1].lower()
    source_type = (source_row.get("type") or "").lower()
    arxiv_id = source_arxiv_id(source_row)

    if ext in TEX_EXTENSIONS:
        return {
            "priority": "1",
            "source_kind": "tex_or_arxiv_source",
            "preferred_channel": "tex_display_math",
            "fallback_channels": "",
            "route_reason": "local TeX/LaTeX source is available",
            "arxiv_id": arxiv_id,
        }

    if arxiv_id or "arxiv" in source_type:
        return {
            "priority": "1",
            "source_kind": "tex_or_arxiv_source",
            "preferred_channel": "arxiv_tex_source",
            "fallback_channels": "grobid_formula_text; pdf_text_line; formula_ocr",
            "route_reason": "arXiv identifier or arXiv source type is available",
            "arxiv_id": arxiv_id,
        }

    if ext in IMAGE_EXTENSIONS:
        return {
            "priority": "3",
            "source_kind": "scanned_or_image_formula",
            "preferred_channel": "formula_ocr",
            "fallback_channels": "",
            "route_reason": "image file requires OCR before formula parsing",
            "arxiv_id": arxiv_id,
        }

    if ext in PDF_EXTENSIONS and is_probably_scanned_pdf(path):
        return {
            "priority": "3",
            "source_kind": "scanned_or_image_formula",
            "preferred_channel": "formula_ocr",
            "fallback_channels": "pdf_text_line",
            "route_reason": "PDF has little extractable text in sampled pages",
            "arxiv_id": arxiv_id,
        }

    if ext in PDF_EXTENSIONS:
        return {
            "priority": "2",
            "source_kind": "electronic_pdf",
            "preferred_channel": "grobid_formula_text",
            "fallback_channels": "pdf_text_line; formula_ocr",
            "route_reason": "ordinary electronic PDF",
            "arxiv_id": arxiv_id,
        }

    return {
        "priority": "unknown",
        "source_kind": "unsupported_source",
        "preferred_channel": "none",
        "fallback_channels": "",
        "route_reason": "unsupported or missing document extension",
        "arxiv_id": arxiv_id,
    }


def source_processing_plan_row(source_row):
    route = classify_source_processing(source_row)
    row = {
        "source_id": source_row.get("source_id", ""),
        "type": source_row.get("type", ""),
        "title": source_row.get("title", ""),
        "local_path": source_row.get("local_path", ""),
        "pdf_url": source_row.get("pdf_url", ""),
    }
    row.update(route)
    return row


def fetch_arxiv_source_records(arxiv_id, source_row, max_formulas=30):
    url = "https://arxiv.org/e-print/%s" % arxiv_id
    request = urllib.request.Request(
        url,
        headers={"User-Agent": "formula-kb-demo/0.1 (local academic demo)"},
    )
    with urllib.request.urlopen(request, timeout=ARXIV_SOURCE_TIMEOUT_SECONDS) as response:
        length_text = response.headers.get("Content-Length", "")
        if length_text:
            try:
                if int(length_text) > ARXIV_SOURCE_MAX_BYTES:
                    raise RuntimeError(
                        "arxiv_source_too_large=%s>%s" % (length_text, ARXIV_SOURCE_MAX_BYTES)
                    )
            except ValueError:
                pass
        payload = response.read(ARXIV_SOURCE_MAX_BYTES + 1)
    if len(payload) > ARXIV_SOURCE_MAX_BYTES:
        raise RuntimeError("arxiv_source_too_large>%s" % ARXIV_SOURCE_MAX_BYTES)

    rows = []
    try:
        archive = tarfile.open(fileobj=io.BytesIO(payload), mode="r:*")
        try:
            members = [m for m in archive.getmembers() if m.isfile() and m.name.endswith(".tex")]
            for member in members:
                data = archive.extractfile(member).read().decode("utf-8", errors="ignore")
                rows.extend(extract_rows_from_tex_text(source_row, data, member.name, max_formulas - len(rows)))
                if len(rows) >= max_formulas:
                    break
        finally:
            archive.close()
    except tarfile.TarError:
        data = payload.decode("utf-8", errors="ignore")
        rows.extend(extract_rows_from_tex_text(source_row, data, "source.tex", max_formulas))

    for row in rows:
        row["extraction_method"] = "arxiv_tex_source"
        row["source_file"] = "https://arxiv.org/e-print/%s" % arxiv_id
        row["note"] = "Copied from arXiv TeX source for the local PDF; not generated."
    return rows[:max_formulas]


def toc_for_page(toc, page_number):
    chapter = ""
    section = ""
    for level, title, page in toc:
        if page and page <= page_number:
            if level == 1:
                chapter = title
                section = ""
            elif level in (2, 3):
                section = title
        elif page and page > page_number:
            break
    return chapter, section


def screenshot_formula_region(page, bbox, screenshot_dir, source_id, page_number, index):
    if not screenshot_dir:
        return ""
    ensure_dir(screenshot_dir)
    try:
        import fitz
        rect = fitz.Rect(bbox)
        padding = 6
        rect = fitz.Rect(
            max(rect.x0 - padding, 0),
            max(rect.y0 - padding, 0),
            min(rect.x1 + padding, page.rect.x1),
            min(rect.y1 + padding, page.rect.y1),
        )
        pix = page.get_pixmap(clip=rect, dpi=160)
        path = os.path.join(screenshot_dir, "%s_p%03d_%03d.png" % (source_id, page_number, index))
        pix.save(path)
        return path
    except Exception:
        return ""


def pdf_text_lines(page):
    data = page.get_text("dict")
    lines = []
    page_width = float(page.rect.width or 1)
    for block in data.get("blocks", []):
        if block.get("type") != 0:
            continue
        for line in block.get("lines", []):
            spans = line.get("spans", [])
            text = "".join(span.get("text", "") for span in spans)
            text = " ".join(text.split())
            if not text:
                continue
            bbox = line.get("bbox")
            if not bbox:
                xs0 = [span.get("bbox", [0, 0, 0, 0])[0] for span in spans]
                ys0 = [span.get("bbox", [0, 0, 0, 0])[1] for span in spans]
                xs1 = [span.get("bbox", [0, 0, 0, 0])[2] for span in spans]
                ys1 = [span.get("bbox", [0, 0, 0, 0])[3] for span in spans]
                bbox = [min(xs0), min(ys0), max(xs1), max(ys1)] if spans else [0, 0, 0, 0]
            sizes = [float(span.get("size", 0) or 0) for span in spans]
            avg_size = sum(sizes) / len(sizes) if sizes else 0
            width = max(0.0, float(bbox[2]) - float(bbox[0]))
            center = (float(bbox[0]) + float(bbox[2])) / 2.0
            center_offset = abs(center - page_width / 2.0) / page_width
            lines.append({
                "text": text,
                "bbox": bbox,
                "font_size": avg_size,
                "width_ratio": width / page_width,
                "center_offset": center_offset,
            })
    return lines


def line_gap_score(lines, line_index):
    line = lines[line_index]
    bbox = line.get("bbox", [0, 0, 0, 0])
    height = max(1.0, float(bbox[3]) - float(bbox[1]))
    score = 0
    if line_index > 0:
        prev_bbox = lines[line_index - 1].get("bbox", [0, 0, 0, 0])
        if float(bbox[1]) - float(prev_bbox[3]) > height * 0.55:
            score += 1
    if line_index + 1 < len(lines):
        next_bbox = lines[line_index + 1].get("bbox", [0, 0, 0, 0])
        if float(next_bbox[1]) - float(bbox[3]) > height * 0.55:
            score += 1
    return score


def pdf_line_layout_score(lines, line_index):
    line = lines[line_index]
    score = 0
    width_ratio = float(line.get("width_ratio", 1) or 1)
    center_offset = float(line.get("center_offset", 1) or 1)
    if center_offset < 0.08 and width_ratio < 0.75:
        score += 3
    elif center_offset < 0.15 and width_ratio < 0.90:
        score += 2
    elif width_ratio < 0.55:
        score += 1
    score += line_gap_score(lines, line_index)
    return score


def add_candidate(candidates, seen, text):
    text = (text or "").strip(" ,.;:")
    if not text or len(text) < 3 or len(text) > 220:
        return
    key = re.sub(r"\s+", "", text)
    if key in seen:
        return
    seen.add(key)
    candidates.append(text)


def math_like_chunks(text):
    chunks = []
    for piece in re.split(r"[;銆俔]|(?:\.\s+)", text or ""):
        piece = piece.strip(" ,.;:")
        if not piece:
            continue
        if re.search(r"[=<>+\-*/^鈭?/脳鈰吢穅]", piece) and re.search(r"[A-Za-z0-9]", piece):
            chunks.append(piece)
    return chunks


def pdf_formula_candidates(text, latexish):
    candidates = []
    seen = set()
    inline_candidates = extract_inline_formula_candidates(text)
    for candidate in inline_candidates:
        add_candidate(candidates, seen, candidate)
    add_full_line = not inline_candidates
    try:
        add_full_line = add_full_line or candidate_word_noise_score(latexish) > -4
    except Exception:
        pass
    if add_full_line:
        for chunk in math_like_chunks(latexish):
            add_candidate(candidates, seen, chunk)
        add_candidate(candidates, seen, latexish)
    return candidates


def candidate_word_noise_score(text):
    tokens = symbol_tokens_from_text(text)
    if not tokens:
        return 0
    long_words = [token for token in tokens if len(token) >= 4]
    noise_words = [token for token in tokens if token in TEXT_NOISE_WORDS]
    score = 0
    score -= min(8, len(noise_words) * 2)
    if len(long_words) >= 5:
        score -= 3
    if len(long_words) >= 9:
        score -= 5
    return score


def score_pdf_formula_candidate(candidate, raw_text, line, layout_score, base_line_score):
    score = int(base_line_score) + int(layout_score)
    compact = re.sub(r"\s+", "", candidate or "")
    score += min(10, math_signal_score(candidate))
    if re.search(r"[=<>]", compact):
        score += 4
    if re.search(r"[+\-*/^]", compact):
        score += 2
    if re.search(r"\b(sin|cos|tan|log|ln|exp|sqrt)\b", candidate or "", re.I):
        score += 3
    if re.search(r"\([0-9]+(?:\.[0-9]+)*\)$", raw_text or ""):
        score += 2
    if len(compact) > 120:
        score -= 4
    if len(compact) > 180:
        score -= 5
    score += candidate_word_noise_score(candidate)
    row = {
        "extraction_method": "pdf_text_line",
        "formula_latex": candidate,
        "raw_text": raw_text,
        "confidence": "0.95",
    }
    try:
        keep, status, _reason = evaluate_formula_row_prefilter(row, "core")
        if keep:
            score += 12
        elif status == "parse_failed":
            score -= 4
    except Exception:
        pass
    return score


def union_bbox(items):
    xs0, ys0, xs1, ys1 = [], [], [], []
    for item in items:
        bbox = item.get("bbox", [0, 0, 0, 0])
        xs0.append(float(bbox[0]))
        ys0.append(float(bbox[1]))
        xs1.append(float(bbox[2]))
        ys1.append(float(bbox[3]))
    return [min(xs0), min(ys0), max(xs1), max(ys1)] if items else [0, 0, 0, 0]


def pdf_line_height(line):
    bbox = line.get("bbox", [0, 0, 0, 0])
    return max(1.0, float(bbox[3]) - float(bbox[1]))


def pdf_line_vertical_gap(prev_line, next_line):
    prev_bbox = prev_line.get("bbox", [0, 0, 0, 0])
    next_bbox = next_line.get("bbox", [0, 0, 0, 0])
    return float(next_bbox[1]) - float(prev_bbox[3])


def is_pdf_formula_continuation(line, previous_line):
    text = normalize_pdf_math_text(line.get("text", ""))
    compact = re.sub(r"\s+", "", text)
    if not compact:
        return False
    if re.match(r"^[=+\-*/^,;)\]}]|^(?:and|where)\b", compact, re.I):
        return True
    is_formula, score = looks_like_formula_text(text)
    if is_formula and score >= 3:
        return True
    if math_signal_score(text) >= 4 and candidate_word_noise_score(text) > -6:
        return True
    if (
        line.get("center_offset", 1) < 0.18
        and line.get("width_ratio", 1) < 0.85
        and math_signal_score(text) >= 2
        and candidate_word_noise_score(text) > -5
    ):
        return True
    previous_text = normalize_pdf_math_text(previous_line.get("text", ""))
    if previous_text.count("(") > previous_text.count(")") and math_signal_score(text) >= 1:
        return True
    return False


def pdf_formula_blocks(lines, max_extra_lines=3):
    blocks = []
    for line_index, line in enumerate(lines):
        is_formula, score = looks_like_formula_text(line.get("text", ""))
        if not is_formula:
            continue
        block_lines = [line]
        end_index = line_index
        while end_index + 1 < len(lines) and len(block_lines) <= max_extra_lines:
            current = block_lines[-1]
            nxt = lines[end_index + 1]
            gap = pdf_line_vertical_gap(current, nxt)
            if gap > pdf_line_height(current) * 1.8:
                break
            if not is_pdf_formula_continuation(nxt, current):
                break
            block_lines.append(nxt)
            end_index += 1
        if end_index == line_index:
            continue
        text = " ".join(item.get("text", "") for item in block_lines)
        blocks.append({
            "start": line_index,
            "end": end_index,
            "text": text,
            "bbox": union_bbox(block_lines),
            "line": {
                "text": text,
                "bbox": union_bbox(block_lines),
                "font_size": max(item.get("font_size", 0) for item in block_lines),
                "width_ratio": max(item.get("width_ratio", 0) for item in block_lines),
                "center_offset": min(item.get("center_offset", 1) for item in block_lines),
            },
            "score": score + 2,
        })
    return blocks


def extract_formula_rows_from_pdf_text(source_row, max_formulas, screenshot_dir):
    rows = []
    path = source_row.get("local_path") or source_row.get("pdf_url", "")
    try:
        import fitz
        doc = fitz.open(path)
    except Exception:
        return rows
    seen_pdf_formula_keys = set()

    try:
        toc = doc.get_toc(simple=True) or []
        for page_index in range(doc.page_count):
            page_number = page_index + 1
            page = doc.load_page(page_index)
            lines = pdf_text_lines(page)
            chapter, section = toc_for_page(toc, page_number)
            for line_index, line in enumerate(lines):
                text = line["text"]
                is_formula, score = looks_like_formula_text(text)
                if not is_formula:
                    continue
                latexish, eq_number = text_to_latexish(text)
                layout_score = pdf_line_layout_score(lines, line_index)
                formula_candidates = pdf_formula_candidates(text, latexish)
                context_before = lines[line_index - 1]["text"] if line_index > 0 else ""
                context_after = lines[line_index + 1]["text"] if line_index + 1 < len(lines) else ""
                screenshot = screenshot_formula_region(
                    page,
                    line["bbox"],
                    screenshot_dir,
                    source_row["source_id"],
                    page_number,
                    len(rows) + 1,
                )
                scored_candidates = []
                for formula_candidate in formula_candidates:
                    candidate_score = score_pdf_formula_candidate(
                        formula_candidate,
                        text,
                        line,
                        layout_score,
                        score,
                    )
                    if candidate_score < 10:
                        continue
                    scored_candidates.append((candidate_score, formula_candidate))
                scored_candidates.sort(key=lambda item: item[0], reverse=True)
                for candidate_index, (candidate_score, formula_candidate) in enumerate(scored_candidates, start=1):
                    formula_key = "%s|%s" % (
                        page_number,
                        re.sub(r"\s+", "", formula_candidate),
                    )
                    if formula_key in seen_pdf_formula_keys:
                        continue
                    seen_pdf_formula_keys.add(formula_key)
                    rows.append({
                        "source_id": source_row["source_id"],
                        "source_title": source_row.get("title", ""),
                        "chapter": chapter,
                        "section": section,
                        "page": str(page_number),
                        "equation_number": eq_number,
                        "locator": "page %d; text-line %d; candidate %d" % (
                            page_number,
                            line_index + 1,
                            candidate_index,
                        ),
                        "extraction_method": "pdf_text_line",
                        "formula_latex": formula_candidate,
                        "raw_text": text,
                        "context_before": context_before,
                        "context_after": context_after,
                        "screenshot_path": screenshot,
                        "bbox": json.dumps([round(float(v), 2) for v in line["bbox"]]),
                        "source_file": path,
                        "confidence": "%.2f" % min(0.97, 0.45 + candidate_score / 35.0),
                        "needs_review": "1",
                        "note": (
                            "Best-effort transcription from PDF text; "
                            "candidate split and scored before parser validation; "
                            "layout_score=%d; candidate_score=%d."
                        ) % (layout_score, candidate_score),
                    })
                    if len(rows) >= max_formulas:
                        return rows
            for block_index, block in enumerate(pdf_formula_blocks(lines), start=1):
                text = block["text"]
                latexish, eq_number = text_to_latexish(text)
                layout_score = pdf_line_layout_score(lines, block["start"]) + 1
                formula_candidates = pdf_formula_candidates(text, latexish)
                context_before = lines[block["start"] - 1]["text"] if block["start"] > 0 else ""
                context_after = lines[block["end"] + 1]["text"] if block["end"] + 1 < len(lines) else ""
                screenshot = screenshot_formula_region(
                    page,
                    block["bbox"],
                    screenshot_dir,
                    source_row["source_id"],
                    page_number,
                    len(rows) + 1,
                )
                scored_candidates = []
                for formula_candidate in formula_candidates:
                    candidate_score = score_pdf_formula_candidate(
                        formula_candidate,
                        text,
                        block["line"],
                        layout_score,
                        block["score"],
                    )
                    if candidate_score < 10:
                        continue
                    scored_candidates.append((candidate_score, formula_candidate))
                scored_candidates.sort(key=lambda item: item[0], reverse=True)
                for candidate_index, (candidate_score, formula_candidate) in enumerate(scored_candidates, start=1):
                    formula_key = "%s|%s" % (
                        page_number,
                        re.sub(r"\s+", "", formula_candidate),
                    )
                    if formula_key in seen_pdf_formula_keys:
                        continue
                    seen_pdf_formula_keys.add(formula_key)
                    rows.append({
                        "source_id": source_row["source_id"],
                        "source_title": source_row.get("title", ""),
                        "chapter": chapter,
                        "section": section,
                        "page": str(page_number),
                        "equation_number": eq_number,
                        "locator": "page %d; text-block %d-%d; candidate %d" % (
                            page_number,
                            block["start"] + 1,
                            block["end"] + 1,
                            candidate_index,
                        ),
                        "extraction_method": "pdf_text_block",
                        "formula_latex": formula_candidate,
                        "raw_text": text,
                        "context_before": context_before,
                        "context_after": context_after,
                        "screenshot_path": screenshot,
                        "bbox": json.dumps([round(float(v), 2) for v in block["bbox"]]),
                        "source_file": path,
                        "confidence": "%.2f" % min(0.97, 0.45 + candidate_score / 35.0),
                        "needs_review": "1",
                        "note": (
                            "Best-effort transcription from merged PDF text lines; "
                            "candidate split and scored before parser validation; "
                            "layout_score=%d; candidate_score=%d."
                        ) % (layout_score, candidate_score),
                    })
                    if len(rows) >= max_formulas:
                        return rows
    finally:
        doc.close()
    return rows


def configured_grobid_url():
    explicit = os.environ.get("GROBID_URL", "").rstrip("/")
    configured = os.environ.get("GROBID_URLS", "")
    candidates = []
    if explicit:
        candidates.append(explicit)
    if configured:
        candidates.extend(
            item.strip().rstrip("/")
            for item in re.split(r"[;,]", configured)
            if item.strip()
        )
    if not candidates:
        candidates = ["http://localhost:8070", "http://127.0.0.1:8070"]
    retries = int(os.environ.get("GROBID_RETRIES", "1") or "1")
    for candidate in candidates:
        if not candidate:
            continue
        for _attempt in range(max(1, retries)):
            try:
                with urllib.request.urlopen(candidate + "/api/isalive", timeout=2) as response:
                    if response.status < 500:
                        return candidate
            except Exception:
                if explicit and candidate == explicit:
                    return explicit
    return ""


def grobid_formula_coords(formula_node):
    coords = formula_node.attrib.get("coords", "")
    if coords:
        return coords
    for item in formula_node.iter():
        coords = item.attrib.get("coords", "")
        if coords:
            return coords
    return ""


def parse_grobid_coords(coords_text):
    coords = []
    if not coords_text:
        return coords
    for piece in re.split(r";\s*", coords_text):
        numbers = [part for part in re.split(r"[,\s]+", piece.strip()) if part]
        if len(numbers) < 5:
            continue
        try:
            page = int(float(numbers[0]))
            x = float(numbers[1])
            y = float(numbers[2])
            width = float(numbers[3])
            height = float(numbers[4])
        except ValueError:
            continue
        if page < 1 or width <= 0 or height <= 0:
            continue
        coords.append({
            "page": page,
            "bbox": [x, y, x + width, y + height],
        })
    return coords


def crop_pdf_region_from_grobid_coords(source_row, coords_text, screenshot_dir, index):
    if not screenshot_dir:
        return ""
    coords = parse_grobid_coords(coords_text)
    if not coords:
        return ""
    path = source_document_path(source_row)
    if not path or not os.path.exists(path):
        return ""
    try:
        import fitz
        doc = fitz.open(path)
    except Exception:
        return ""
    try:
        first = coords[0]
        page_number = first["page"]
        if page_number < 1 or page_number > doc.page_count:
            return ""
        page = doc.load_page(page_number - 1)
        return screenshot_formula_region(
            page,
            first["bbox"],
            screenshot_dir,
            source_row["source_id"] + "_grobid",
            page_number,
            index,
        )
    finally:
        doc.close()


def mathpix_ocr_image(image_path):
    app_id = os.environ.get("MATHPIX_APP_ID", "")
    app_key = os.environ.get("MATHPIX_APP_KEY", "")
    if not app_id or not app_key:
        return "", 0.0, "mathpix_not_configured"
    try:
        with open(image_path, "rb") as f:
            encoded = base64.b64encode(f.read()).decode("ascii")
        payload = json.dumps({
            "src": "data:image/png;base64,%s" % encoded,
            "formats": ["latex_simplified", "latex_styled", "text"],
            "ocr": ["math", "text"],
            "rm_spaces": True,
        }).encode("utf-8")
        request = urllib.request.Request(
            "https://api.mathpix.com/v3/text",
            data=payload,
            headers={
                "Content-Type": "application/json",
                "app_id": app_id,
                "app_key": app_key,
            },
            method="POST",
        )
        with urllib.request.urlopen(request, timeout=90) as response:
            data = json.loads(response.read().decode("utf-8", errors="ignore"))
    except Exception as exc:
        return "", 0.0, "mathpix_error:%s" % str(exc).replace(";", ",")

    formula = (
        data.get("latex_simplified")
        or data.get("latex_styled")
        or data.get("text")
        or ""
    )
    confidence = data.get("confidence") or data.get("confidence_rate") or 0
    try:
        confidence = float(confidence)
    except (TypeError, ValueError):
        confidence = 0.0
    return formula.strip(), confidence, "mathpix"


def pix2tex_python_candidates():
    candidates = []
    configured = os.environ.get("PIX2TEX_PYTHON", "")
    if configured:
        candidates.append(configured)
    default_py311 = r"C:\anaconda3\envs\py311\python.exe"
    candidates.append(default_py311)
    candidates.append(sys.executable)
    seen = set()
    unique = []
    for candidate in candidates:
        if candidate and candidate not in seen:
            seen.add(candidate)
            unique.append(candidate)
    return unique


def pix2tex_helper_script():
    return os.path.join(os.path.dirname(__file__), "pix2tex_single_week5.py")


def pix2tex_ocr_image(image_path):
    helper = pix2tex_helper_script()
    if os.path.exists(helper):
        for python_exe in pix2tex_python_candidates():
            if not os.path.exists(python_exe):
                continue
            try:
                completed = subprocess.run(
                    [python_exe, helper, image_path],
                    stdout=subprocess.PIPE,
                    stderr=subprocess.PIPE,
                    text=True,
                    encoding="utf-8",
                    errors="replace",
                    timeout=int(os.environ.get("PIX2TEX_TIMEOUT", "180") or "180"),
                    check=False,
                )
            except Exception as exc:
                continue
            if completed.returncode == 0 and completed.stdout.strip():
                return completed.stdout.strip(), 0.80, "pix2tex_api"
            if completed.returncode not in (0, 2):
                last_error = completed.stderr.strip().replace(";", ",")
                if last_error:
                    return "", 0.0, "pix2tex_api_error:%s" % last_error

    command_text = os.environ.get("PIX2TEX_COMMAND", "")
    command = command_text or shutil.which("pix2tex") or shutil.which("latexocr")
    if not command:
        return "", 0.0, "pix2tex_not_configured"
    command_parts = command_text.split() if command_text else [command]
    try:
        completed = subprocess.run(
            command_parts + [image_path],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            encoding="utf-8",
            errors="replace",
            timeout=int(os.environ.get("PIX2TEX_TIMEOUT", "180") or "180"),
            check=False,
        )
    except Exception as exc:
        return "", 0.0, "pix2tex_error:%s" % str(exc).replace(";", ",")
    if completed.returncode != 0:
        return "", 0.0, "pix2tex_error:%s" % completed.stderr.strip().replace(";", ",")
    return completed.stdout.strip(), 0.75, "pix2tex"


def local_formula_ocr_available():
    helper = pix2tex_helper_script()
    helper_ready = os.path.exists(helper) and any(os.path.exists(p) for p in pix2tex_python_candidates())
    return bool(helper_ready or os.environ.get("PIX2TEX_COMMAND") or shutil.which("pix2tex") or shutil.which("latexocr"))


def formula_ocr_image(image_path):
    ocr_funcs = [pix2tex_ocr_image]
    if os.environ.get("ALLOW_REMOTE_FORMULA_OCR") == "1":
        ocr_funcs.append(mathpix_ocr_image)
    for ocr_func in ocr_funcs:
        formula, confidence, status = ocr_func(image_path)
        if formula:
            return formula, confidence, status
    return "", 0.0, "formula_ocr_not_configured"


def render_pdf_page_for_ocr(path, page_index, screenshot_dir, source_id):
    if not screenshot_dir:
        screenshot_dir = os.path.join(os.path.dirname(path) or ".", "formula_ocr_pages")
    ensure_dir(screenshot_dir)
    try:
        import fitz
        doc = fitz.open(path)
    except Exception:
        return ""
    try:
        if page_index < 0 or page_index >= doc.page_count:
            return ""
        page = doc.load_page(page_index)
        dpi = int(os.environ.get("FORMULA_KB_OCR_DPI", "180") or "180")
        pix = page.get_pixmap(dpi=dpi)
        image_path = os.path.join(
            screenshot_dir,
            "%s_ocr_page_%03d.png" % (source_id, page_index + 1),
        )
        pix.save(image_path)
        return image_path
    except Exception:
        return ""
    finally:
        doc.close()


def extract_formula_rows_from_pdf_ocr(source_row, max_formulas, screenshot_dir):
    path = source_document_path(source_row)
    if not path or not os.path.exists(path):
        append_source_note(source_row, "pdf_ocr_status=missing_local_pdf")
        return []
    if not local_formula_ocr_available():
        append_source_note(source_row, "pdf_ocr_status=local_ocr_not_configured")
        return []
    try:
        import fitz
        doc = fitz.open(path)
        page_count = doc.page_count
        doc.close()
    except Exception as exc:
        append_source_note(source_row, "pdf_ocr_status=pdf_open_error:%s" % str(exc).replace(";", ","))
        return []

    max_pages = min(
        page_count,
        int(os.environ.get("FORMULA_KB_OCR_MAX_PDF_PAGES", "3") or "3"),
    )
    rows = []
    for page_index in range(max_pages):
        image_path = render_pdf_page_for_ocr(
            path,
            page_index,
            screenshot_dir,
            source_row.get("source_id", "source"),
        )
        if not image_path:
            continue
        formula, confidence, status = formula_ocr_image(image_path)
        append_source_note(source_row, "pdf_ocr_page_%d_status=%s" % (page_index + 1, status))
        if not formula:
            continue
        for candidate_index, candidate in enumerate(pdf_formula_candidates(formula, normalize_pdf_math_text(formula)), start=1):
            keep, prefilter_status, prefilter_reason = evaluate_formula_row_prefilter(
                {
                    "extraction_method": "%s_pdf_page" % status,
                    "formula_latex": candidate,
                    "raw_text": formula,
                    "confidence": "%.2f" % (confidence or 0.70),
                },
                "parseable",
            )
            if not keep:
                append_source_note(
                    source_row,
                    "pdf_ocr_page_%d_candidate_%d_rejected=%s" % (
                        page_index + 1,
                        candidate_index,
                        prefilter_reason or prefilter_status,
                    ),
                )
                continue
            rows.append({
                "source_id": source_row["source_id"],
                "source_title": source_row.get("title", ""),
                "chapter": "",
                "section": "",
                "page": str(page_index + 1),
                "equation_number": "",
                "locator": "page %d; full-page local formula OCR; candidate %d" % (
                    page_index + 1,
                    candidate_index,
                ),
                "extraction_method": "%s_pdf_page" % status,
                "formula_latex": candidate,
                "raw_text": formula,
                "context_before": "",
                "context_after": "",
                "screenshot_path": image_path,
                "bbox": "",
                "source_file": path,
                "confidence": "%.2f" % (confidence or 0.70),
                "needs_review": "1",
                "note": "Extracted by local formula OCR from rendered PDF page; OCR page limit=%d." % max_pages,
            })
            if len(rows) >= max_formulas:
                append_source_note(source_row, "pdf_ocr_status=ran_local_ocr")
                return rows
    append_source_note(source_row, "pdf_ocr_status=ran_local_ocr")
    return rows


def extract_formula_rows_from_grobid(source_row, max_formulas, screenshot_dir):
    """Optional GROBID channel.

    If GROBID_URL points to a running GROBID service, this tries to read TEI
    formula nodes. Without that service, it records the fallback reason and lets
    the tiered router continue to PDF text or OCR channels.
    """
    grobid_url = configured_grobid_url()
    path = source_document_path(source_row)
    if not grobid_url:
        append_source_note(source_row, "grobid_status=not_configured")
        return []
    append_source_note(source_row, "grobid_status=alive:%s" % grobid_url)
    if not path or not os.path.exists(path):
        append_source_note(source_row, "grobid_status=missing_local_pdf")
        return []

    endpoint = "%s/api/processFulltextDocument" % grobid_url
    boundary = "----formula-kb-boundary-%s" % datetime.utcnow().strftime("%Y%m%d%H%M%S%f")
    try:
        with open(path, "rb") as f:
            payload = f.read()
        body = []
        body.append(("--%s\r\n" % boundary).encode("utf-8"))
        body.append(
            (
                'Content-Disposition: form-data; name="input"; filename="%s"\r\n'
                "Content-Type: application/pdf\r\n\r\n"
            ) % os.path.basename(path)
        )
        body.append(payload)
        body.append(("\r\n--%s\r\n" % boundary).encode("utf-8"))
        body.append(b'Content-Disposition: form-data; name="teiCoordinates"\r\n\r\nformula')
        body.append(("\r\n--%s--\r\n" % boundary).encode("utf-8"))
        request = urllib.request.Request(
            endpoint,
            data=b"".join(part if isinstance(part, bytes) else part.encode("utf-8") for part in body),
            headers={"Content-Type": "multipart/form-data; boundary=%s" % boundary},
            method="POST",
        )
        with urllib.request.urlopen(request, timeout=120) as response:
            tei_xml = response.read()
    except Exception as exc:
        append_source_note(source_row, "grobid_status=error:%s" % str(exc).replace(";", ","))
        return []

    rows = []
    try:
        root = ET.fromstring(tei_xml)
    except Exception as exc:
        append_source_note(source_row, "grobid_status=tei_parse_error:%s" % str(exc).replace(";", ","))
        return []

    ns = {"tei": "http://www.tei-c.org/ns/1.0"}
    formulas = root.findall(".//tei:formula", ns)
    if not formulas:
        append_source_note(source_row, "grobid_status=no_formula_nodes")
        return []

    append_source_note(source_row, "grobid_formula_nodes=%d" % len(formulas))
    for index, formula_node in enumerate(formulas, start=1):
        text = " ".join(" ".join(formula_node.itertext()).split())
        coords = grobid_formula_coords(formula_node)
        screenshot = crop_pdf_region_from_grobid_coords(source_row, coords, screenshot_dir, index)
        ocr_status = ""
        ocr_confidence = 0.0
        if screenshot and (not text or not formula_text_prefilter_passes(text, "parseable")):
            ocr_formula, ocr_confidence, ocr_status = formula_ocr_image(screenshot)
            if ocr_formula:
                text = ocr_formula
        if not text:
            append_source_note(source_row, "grobid_formula_%d=no_text_or_ocr" % index)
            continue
        latexish, eq_number = text_to_latexish(text)
        rows.append({
            "source_id": source_row["source_id"],
            "source_title": source_row.get("title", ""),
            "chapter": "",
            "section": "",
            "page": "",
            "equation_number": eq_number,
            "locator": "grobid formula %d" % index,
            "extraction_method": "grobid_formula_text",
            "formula_latex": latexish,
            "raw_text": text,
            "context_before": "",
            "context_after": "",
            "screenshot_path": screenshot,
            "bbox": json.dumps(parse_grobid_coords(coords), ensure_ascii=False),
            "source_file": path,
            "confidence": "%.2f" % (ocr_confidence or 0.80),
            "needs_review": "1",
            "note": "Extracted from GROBID TEI formula node; ocr_status=%s; validated by parser before core statistics." % ocr_status,
        })
        if len(rows) >= max_formulas:
            break
    return rows


def extract_formula_rows_from_formula_ocr(source_row, max_formulas, screenshot_dir):
    """Optional local-first OCR channel for images or scanned PDF pages.

    The default path uses local pix2tex/latexocr when configured. Remote Mathpix
    is only tried when ALLOW_REMOTE_FORMULA_OCR=1 is set explicitly.
    """
    mathpix_ready = (
        os.environ.get("ALLOW_REMOTE_FORMULA_OCR") == "1"
        and bool(os.environ.get("MATHPIX_APP_ID") and os.environ.get("MATHPIX_APP_KEY"))
    )
    pix2tex_ready = bool(os.environ.get("PIX2TEX_COMMAND"))
    nougat_ready = bool(os.environ.get("NOUGAT_COMMAND"))
    ready = []
    if mathpix_ready:
        ready.append("mathpix")
    if pix2tex_ready:
        ready.append("pix2tex")
    if nougat_ready:
        ready.append("nougat")
    path = source_document_path(source_row)
    ext = os.path.splitext(path)[1].lower()
    if ext in PDF_EXTENSIONS and path and os.path.exists(path):
        if not local_formula_ocr_available():
            append_source_note(source_row, "formula_ocr_status=local_ocr_not_configured")
            return []
        rows = extract_formula_rows_from_pdf_ocr(source_row, max_formulas, screenshot_dir)
        append_source_note(source_row, "formula_ocr_status=pdf_page_ocr_rows:%d" % len(rows))
        return rows

    if ext in IMAGE_EXTENSIONS and path and os.path.exists(path):
        formula, confidence, status = formula_ocr_image(path)
        append_source_note(source_row, "formula_ocr_status=%s" % status)
        if formula:
            return [{
                "source_id": source_row["source_id"],
                "source_title": source_row.get("title", ""),
                "chapter": "",
                "section": "",
                "page": "",
                "equation_number": "",
                "locator": "image formula OCR",
                "extraction_method": "%s_ocr" % status,
                "formula_latex": formula,
                "raw_text": formula,
                "context_before": "",
                "context_after": "",
                "screenshot_path": path,
                "bbox": "",
                "source_file": path,
                "confidence": "%.2f" % confidence,
                "needs_review": "1",
                "note": "Extracted by formula OCR from image source.",
            }]
        return []

    if not ready:
        append_source_note(source_row, "formula_ocr_status=not_configured")
        return []
    append_source_note(source_row, "formula_ocr_status=configured_but_not_run_by_demo:%s" % ",".join(ready))
    return []


def annotate_rows_with_route(rows, route):
    if not rows:
        return rows
    route_note = "source_route_priority=%s; preferred_channel=%s" % (
        route.get("priority", ""),
        route.get("preferred_channel", ""),
    )
    for row in rows:
        row["note"] = (row.get("note", "") + "; " + route_note).strip("; ")
    return rows


def extract_formula_rows_for_source(source_row, max_formulas, screenshot_dir,
                                    use_arxiv_source=False, tiered_source_routing=False):
    path = source_row.get("local_path") or source_row.get("pdf_url", "")
    ext = os.path.splitext(path)[1].lower()

    if tiered_source_routing:
        route = classify_source_processing(source_row)
        rows = []
        if ext in TEX_EXTENSIONS:
            rows = extract_formulas_from_local_tex(source_row, max_formulas)
        elif route["preferred_channel"] == "arxiv_tex_source" and use_arxiv_source:
            arxiv_id = route.get("arxiv_id") or detect_arxiv_id_from_pdf(path)
            if arxiv_id:
                try:
                    rows = fetch_arxiv_source_records(arxiv_id, source_row, max_formulas)
                except Exception as exc:
                    append_source_note(source_row, "arxiv_source_error=%s" % str(exc).replace(";", ","))
            if not rows and ext in PDF_EXTENSIONS:
                rows = extract_formula_rows_from_grobid(source_row, max_formulas, screenshot_dir)
            if not rows and ext in PDF_EXTENSIONS:
                rows = extract_formula_rows_from_pdf_text(source_row, max_formulas, screenshot_dir)
            if not rows:
                rows = extract_formula_rows_from_formula_ocr(source_row, max_formulas, screenshot_dir)
        elif route["preferred_channel"] == "grobid_formula_text":
            rows = extract_formula_rows_from_grobid(source_row, max_formulas, screenshot_dir)
            if not rows and ext in PDF_EXTENSIONS:
                rows = extract_formula_rows_from_pdf_text(source_row, max_formulas, screenshot_dir)
            if not rows:
                rows = extract_formula_rows_from_formula_ocr(source_row, max_formulas, screenshot_dir)
        elif route["preferred_channel"] == "formula_ocr":
            rows = extract_formula_rows_from_formula_ocr(source_row, max_formulas, screenshot_dir)
            if not rows and ext in PDF_EXTENSIONS:
                rows = extract_formula_rows_from_pdf_text(source_row, max_formulas, screenshot_dir)
        return annotate_rows_with_route(rows, route)

    if ext in TEX_EXTENSIONS:
        return extract_formulas_from_local_tex(source_row, max_formulas)

    rows = []
    if ext in PDF_EXTENSIONS and use_arxiv_source:
        arxiv_id = detect_arxiv_id_from_pdf(path)
        if arxiv_id:
            try:
                rows = fetch_arxiv_source_records(arxiv_id, source_row, max_formulas)
            except Exception as exc:
                source_row["notes"] = (source_row.get("notes", "") + "; arxiv_source_error=%s" % exc).strip("; ")
    if rows:
        return rows

    if ext in PDF_EXTENSIONS:
        return extract_formula_rows_from_pdf_text(source_row, max_formulas, screenshot_dir)
    return []


def merge_formula_rows(existing_rows, new_rows):
    existing_keys = {formula_row_key(row) for row in existing_rows if formula_row_key(row)}
    added = 0
    for row in new_rows:
        key = formula_row_key(row)
        if key in existing_keys:
            continue
        existing_rows.append(row)
        existing_keys.add(key)
        added += 1
    return added


def write_fill_guide(path, sources_path, formulas_path, sources, rows_per_pdf):
    parent = os.path.dirname(path)
    if parent:
        ensure_dir(parent)
    with open(path, "w", encoding="utf-8") as f:
        f.write("# Formula Fill Template Guide\n\n")
        f.write("## Workflow\n\n")
        f.write("1. Put PDF papers/books in the local PDF folder.\n")
        f.write("2. Run `python scripts/formula_kb_demo.py --init-from-pdf-dir <pdf_folder>`.\n")
        f.write("3. The script auto-fills `%s` with formulas copied from TeX/arXiv source or transcribed from PDF text.\n" % formulas_path)
        f.write("4. Review rows where `needs_review=1`; do not invent formulas that are not in the source.\n")
        f.write("5. Run `python scripts/formula_kb_demo.py --sources %s --formulas %s --out outputs`.\n\n" % (
            sources_path,
            formulas_path,
        ))
        f.write("## Columns\n\n")
        f.write("- `%s`: generated from local PDF metadata.\n" % sources_path)
        f.write("- `%s`: extracted formula rows. Empty optional-template formulas are skipped during parsing.\n\n" % formulas_path)
        f.write("## Current Sources\n\n")
        f.write("| source_id | title | file |\n|---|---|---|\n")
        for row in sources:
            if row.get("type") in ("local_pdf", "local_tex"):
                f.write("| %s | %s | %s |\n" % (
                    row.get("source_id", ""),
                    row.get("title", "").replace("|", "/"),
                    os.path.basename(row.get("local_path") or row.get("pdf_url", "")),
                ))
        f.write("\nOptional blank template rows per source: %d\n" % rows_per_pdf)


def init_from_pdf_dir(pdf_dir, sources_path, formulas_path, rows_per_pdf=0,
                      recursive=False, overwrite=False, guide_path=None,
                      extract_formulas=True, max_formulas_per_source=40,
                      screenshot_dir=None, use_arxiv_source=False,
                      metadata_manifest_path="", tiered_source_routing=False,
                      extraction_prefilter_mode="off"):
    paths = document_paths(pdf_dir, recursive=recursive)
    if not paths:
        raise RuntimeError("no PDF/TeX files found in %s" % os.path.abspath(pdf_dir))

    sources = [] if overwrite else read_csv_if_exists(sources_path)
    formulas = [] if overwrite else read_csv_if_exists(formulas_path)
    by_key = {source_key(row): row for row in sources if source_key(row)}
    metadata_manifest = load_metadata_manifest(metadata_manifest_path)

    added_sources = 0
    updated_sources = 0
    added_formula_rows = 0
    extracted_formula_rows = 0
    prefilter_rejections = []

    for path_number, path in enumerate(paths, start=1):
        key = normalize_path(path)
        manifest_row = metadata_manifest.get(manifest_key_from_path(path))
        if key in by_key:
            row = by_key[key]
            row.update(build_source_row(row["source_id"], path, manifest_row))
            updated_sources += 1
        else:
            row = build_source_row(next_local_source_id(sources), path, manifest_row)
            sources.append(row)
            by_key[key] = row
            added_sources += 1
        if manifest_row:
            row.update(apply_manifest_metadata(row, manifest_row))

        if extract_formulas:
            next_index = next_formula_index(formulas, row["source_id"])
            extraction_limit = max_formulas_per_source
            if extraction_prefilter_mode not in ("", "off"):
                extraction_limit = max_formulas_per_source * 3
            extracted_rows = extract_formula_rows_for_source(
                row,
                extraction_limit,
                screenshot_dir,
                use_arxiv_source=use_arxiv_source,
                tiered_source_routing=tiered_source_routing,
            )
            extracted_rows, rejected_rows = prefilter_extracted_formula_rows(
                extracted_rows,
                extraction_prefilter_mode,
            )
            prefilter_rejections.extend(rejected_rows)
            extracted_rows = extracted_rows[:max_formulas_per_source]
            for offset, formula_row in enumerate(extracted_rows):
                formula_row["formula_id"] = "%s_F%03d" % (row["source_id"], next_index + offset)
            extracted_formula_rows += merge_formula_rows(formulas, extracted_rows)
            print(
                "init_progress=%d/%d source=%s extracted=%d rejected=%d total_formulas=%d" % (
                    path_number,
                    len(paths),
                    row.get("source_id", ""),
                    len(extracted_rows),
                    len(rejected_rows),
                    len(formulas),
                ),
                flush=True,
            )

        if rows_per_pdf > 0:
            added_formula_rows += ensure_formula_template_rows(
                formulas,
                row,
                rows_per_pdf,
            )

    write_csv(sources_path, SOURCE_FIELDS, sources)
    write_csv(formulas_path, FORMULA_FIELDS, formulas)

    formulas_stem = os.path.splitext(os.path.basename(formulas_path))[0]
    route_suffix = formulas_stem.replace("formula_samples", "", 1).strip("_")
    route_file_name = "source_processing_plan%s.csv" % (("_" + route_suffix) if route_suffix else "")
    route_summary_path = os.path.join(os.path.dirname(formulas_path) or ".", route_file_name)
    write_csv(
        route_summary_path,
        SOURCE_PROCESSING_PLAN_FIELDS,
        [source_processing_plan_row(row) for row in sources],
    )
    prefilter_rejections_path = ""
    if extraction_prefilter_mode not in ("", "off"):
        formulas_stem = os.path.splitext(os.path.basename(formulas_path))[0]
        reject_suffix = formulas_stem.replace("formula_samples", "", 1).strip("_")
        reject_file_name = "extraction_prefilter_rejections%s.csv" % (
            ("_" + reject_suffix) if reject_suffix else ""
        )
        prefilter_rejections_path = os.path.join(os.path.dirname(formulas_path) or ".", reject_file_name)
        write_csv(
            prefilter_rejections_path,
            EXTRACTION_PREFILTER_REJECTION_FIELDS,
            prefilter_rejections,
        )

    if guide_path is None:
        guide_path = os.path.join(os.path.dirname(formulas_path) or ".", "formula_fill_template.md")
    write_fill_guide(guide_path, sources_path, formulas_path, sources, rows_per_pdf)

    return {
        "pdf_count": len([path for path in paths if path.lower().endswith(".pdf")]),
        "document_count": len(paths),
        "source_count": len(sources),
        "formula_template_rows": len(formulas),
        "added_sources": added_sources,
        "updated_sources": updated_sources,
        "added_formula_rows": added_formula_rows,
        "extracted_formula_rows": extracted_formula_rows,
        "sources_path": sources_path,
        "formulas_path": formulas_path,
        "guide_path": guide_path,
        "source_processing_plan_path": route_summary_path,
        "prefilter_rejections_path": prefilter_rejections_path,
        "prefilter_rejection_count": len(prefilter_rejections),
    }


def strip_outer_math(text):
    text = text.strip()
    for left, right in (("$$", "$$"), (r"\[", r"\]"), ("$", "$")):
        if text.startswith(left) and text.endswith(right):
            text = text[len(left):-len(right)].strip()
    return text


def extract_group(text, start):
    if start >= len(text) or text[start] != "{":
        raise ParseError("expected LaTeX group")
    depth = 0
    for i in range(start, len(text)):
        if text[i] == "{":
            depth += 1
        elif text[i] == "}":
            depth -= 1
            if depth == 0:
                return text[start + 1:i], i + 1
    raise ParseError("unclosed LaTeX group")


def split_latex_rows(text):
    return [row.strip() for row in re.split(r"\\\\+", text or "") if row.strip()]


def split_latex_columns(row):
    return [part.strip() for part in row.split("&") if part.strip()]


def replace_latex_environment_blocks(text):
    """Collapse common display environments into parser-friendly functions."""
    env_pattern = re.compile(
        r"\\begin\{(cases|matrix|pmatrix|bmatrix|Bmatrix|vmatrix|Vmatrix|array|split|aligned|align|align\*|gather|gather\*|multline|multline\*)\}"
        r"(.*?)"
        r"\\end\{\1\}",
        re.DOTALL,
    )

    def repl(match):
        env = match.group(1).replace("*", "")
        body = match.group(2)
        entries = []
        for row in split_latex_rows(body):
            columns = split_latex_columns(row)
            if not columns:
                continue
            if env == "cases":
                entries.append(columns[0])
            elif env in ("split", "aligned", "align", "gather", "multline"):
                entries.append("".join(columns))
            else:
                entries.extend(columns)
        if not entries:
            return ""
        if env in ("split", "aligned", "align", "gather", "multline"):
            return "; ".join(entries)
        cleaned = []
        for entry in entries[:12]:
            try:
                cleaned.append(normalize_latex(entry))
            except Exception:
                cleaned.append(re.sub(r"[^A-Za-z0-9+\-*/^=().,_]", "", entry))
        function_name = "cases" if env == "cases" else "matrix"
        return "%s(%s)" % (function_name, ",".join(item for item in cleaned if item))

    previous = None
    while previous != text:
        previous = text
        text = env_pattern.sub(repl, text)
    return text


def replace_latex_command_with_group(text, command, replacement_name):
    marker = "\\" + command
    i = 0
    out = []
    while i < len(text):
        if text.startswith(marker, i):
            j = i + len(marker)
            while j < len(text) and text[j].isspace():
                j += 1
            if j < len(text) and text[j] == "{":
                inner, end = extract_group(text, j)
                out.append("%s(%s)" % (replacement_name, normalize_latex(inner)))
                i = end
            else:
                out.append(replacement_name)
                i = j
        else:
            out.append(text[i])
            i += 1
    return "".join(out)


def replace_command_group(text, command, handler):
    marker = "\\" + command
    i = 0
    out = []
    while i < len(text):
        if text.startswith(marker, i):
            j = i + len(marker)
            while j < len(text) and text[j].isspace():
                j += 1
            if j < len(text) and text[j] == "{":
                inner, end = extract_group(text, j)
                out.append(handler(inner))
                i = end
            else:
                out.append(command)
                i = j
        else:
            out.append(text[i])
            i += 1
    return "".join(out)


def clean_symbol_part(text):
    plain = (text or "").strip()
    if re.fullmatch(r"[A-Za-z0-9]+(?:_[A-Za-z0-9]+)*", plain):
        return plain
    # Formatting commands inside a subscript denote one semantic symbol.
    # Flatten them locally instead of recursively normalizing the whole
    # formula, which used to split E_{\mathrm{Al-A}} and similar atoms.
    formatting = re.compile(
        r"\\(?:mathrm|mathbf|mathit|mathsf|mathtt|mathcal|mathbb|mathfrak)\s*"
        r"\{([^{}]*)\}"
    )
    previous = None
    while previous != plain:
        previous = plain
        plain = formatting.sub(
            lambda match: re.sub(r"[^A-Za-z0-9]+", "_", match.group(1)).strip("_") or "x",
            plain,
        )
    if not re.search(r"\\", plain):
        atom = re.sub(r"[^A-Za-z0-9]+", "_", plain)
        atom = re.sub(r"_+", "_", atom).strip("_")
        if atom:
            return atom
    text = normalize_latex(text)
    text = re.sub(r"[^A-Za-z0-9]+", "_", text)
    text = re.sub(r"_+", "_", text).strip("_")
    return text or "x"


def clean_superscript_part(text):
    """Keep exponent arithmetic instead of flattening it into an identifier."""
    value = (text or "").strip()
    value = replace_frac(value)
    for latex_name, ascii_name in GREEK_REPLACEMENTS.items():
        value = re.sub(command_boundary(latex_name.lstrip("\\")), ascii_name, value)
    value = value.replace("{", "(").replace("}", ")")
    value = re.sub(r"\\(?:mathrm|mathbf|mathit|mathsf|mathtt)(?![A-Za-z])", "", value)
    value = re.sub(r"[^A-Za-z0-9_+\-*/().]", "", value)
    return value or "1"


def unwrap_latex_formatting(text):
    for command in ("mathbf", "mathbb", "mathcal", "mathrm", "mathsf", "mathtt", "mathfrak", "boldsymbol"):
        text = replace_command_group(
            text,
            command,
            lambda inner: " " + clean_symbol_part(inner).replace("_", FORMAT_ATOM_JOIN) + " ",
        )
    for command in ("text", "operatorname"):
        text = replace_command_group(text, command, lambda inner: " " + (re.sub(r"[^A-Za-z0-9]+", "", inner) or "text") + " ")
    for command, prefix in (("hat", "hat"), ("bar", "bar"), ("tilde", "tilde"), ("dot", "dot"), ("ddot", "ddot"), ("vec", "vec")):
        text = replace_command_group(text, command, lambda inner, prefix=prefix: prefix + clean_symbol_part(inner))
    return text


def replace_frac(text):
    i = 0
    out = []
    while i < len(text):
        if text.startswith(r"\frac", i):
            j = i + len(r"\frac")
            while j < len(text) and text[j].isspace():
                j += 1
            numerator, j = extract_group(text, j)
            while j < len(text) and text[j].isspace():
                j += 1
            denominator, j = extract_group(text, j)
            # Only recurse into nested fractions here.  The complete formula
            # is normalized once after replacement; recursively calling
            # normalize_latex would split atomic symbols such as Z_{Ref} on
            # the second pass.
            out.append("((%s)/(%s))" % (replace_frac(numerator), replace_frac(denominator)))
            i = j
        else:
            out.append(text[i])
            i += 1
    return "".join(out)


def replace_script_groups(text):
    def repl(match):
        marker = match.group(1)
        inner = match.group(2) or match.group(3)
        cleaned = clean_symbol_part(inner) if marker == "_" else clean_superscript_part(inner)
        if marker == "_":
            return "_" + cleaned + SCRIPT_END
        return "^(" + cleaned + ")"

    # Handle the one-character TeX form first.  Applying this after a braced
    # script has been flattened would re-match the leading character inside
    # `_{ME}` or `_{11}` and split a valid symbol.
    text = re.sub(
        r"_([A-Za-z0-9])",
        lambda m: "_" + m.group(1) + SCRIPT_END,
        text,
    )
    text = re.sub(r"\^([A-Za-z0-9])", r"^(\1)", text)
    text = re.sub(
        r"_\\([A-Za-z]+)",
        lambda m: "_" + clean_symbol_part(m.group(1)) + SCRIPT_END,
        text,
    )
    text = re.sub(r"\^\\([A-Za-z]+)", lambda m: "^(" + clean_symbol_part(m.group(1)) + ")", text)
    text = re.sub(r"([_^])\{([^{}]*)\}", repl, text)
    return text


def should_process_tex_scripts(text):
    """Do not reinterpret stable normalized identifiers on a second pass."""
    return bool("\\" in (text or "") or re.search(r"[_^]\{", text or ""))


def is_conservative_function_name(name, lhs_function_names=None):
    lhs_function_names = lhs_function_names or set()
    base = (name or "").split("_", 1)[0]
    return (
        name in FUNCTION_NAMES
        or base in SYMBOLIC_FUNCTION_BASES
        or name in lhs_function_names
    )


def conservative_function_calls(text):
    """Keep only high-confidence symbolic calls; other adjacency is product."""
    relation = re.search(r"==|<=|>=|!=|~=|\|->|->|(?<![<>=!~])=(?!=)", text or "")
    lhs_function_names = set()
    if relation:
        lhs = text[:relation.start()]
        lhs_function_names.update(re.findall(r"\b([A-Za-z_][A-Za-z0-9_]*)\s*\(", lhs))

    pattern = re.compile(r"(?<![A-Za-z_])([A-Za-z_][A-Za-z0-9_]*)\s*\(")
    # A substitution pass that sees an outer call does not revisit a nested
    # adjacency such as cos(2*k_F(r-r_0)).  Iterate to a fixed point so every
    # nested candidate receives the same conservative decision.
    value = text
    for _ in range(8):
        updated = pattern.sub(
            lambda match: (
                match.group(1) + "("
                if is_conservative_function_name(match.group(1), lhs_function_names)
                else match.group(1) + "*("
            ),
            value,
        )
        if updated == value:
            break
        value = updated
    return value


def repair_spaced_function_names(text):
    """Recover only unmistakable OCR splits such as ``e x p(...)``."""
    value = text or ""
    patterns = {
        "exp": r"(?<![A-Za-z])e\s+x\s+p\s*(?=(?:\\left\s*)?[({[])",
        "sin": r"(?<![A-Za-z])s\s+i\s+n\s*(?=(?:\\left\s*)?[({[])",
        "cos": r"(?<![A-Za-z])c\s+o\s+s\s*(?=(?:\\left\s*)?[({[])",
        "log": r"(?<![A-Za-z])l\s+o\s+g\s*(?=(?:\\left\s*)?[({[])",
    }
    for name, pattern in patterns.items():
        value = re.sub(pattern, r"\\" + name, value)
    return value


def replace_expression_connectors(text):
    """Convert top-level prose connectors between formulae into bundle separators."""
    value = text or ""
    value = re.sub(
        r"\\(?:mathrm|text|operatorname)\s*\{\s*(?:o\s*r|a\s*n\s*d|or|and|或|且)\s*\}",
        ";",
        value,
        flags=re.I,
    )
    spacing = r"(?:\\,|\\;|\\:|\\!|\\quad(?![A-Za-z])|\\qquad(?![A-Za-z])|\s)"
    value = re.sub(
        spacing + r"+(?:o\s+r|a\s+n\s+d|or|and)" + spacing + r"+",
        ";",
        value,
        flags=re.I,
    )
    value = re.sub(r"\s*[或且]\s*", ";", value)
    return value


def split_formula_conditions(text):
    """Split top-level prose conditions from the expression to classify."""
    value = text or ""
    wrapped = re.compile(
        r"\\(?:mathrm|text|operatorname)\s*\{\s*"
        r"(where|for|if|when|with|subject\s+to)\s*\}",
        flags=re.I,
    )
    plain = re.compile(r"(?<![A-Za-z])(where|for|if|when|with|subject\s+to)(?![A-Za-z])", re.I)
    depth = 0
    i = 0
    while i < len(value):
        if depth == 0:
            match = wrapped.match(value, i) or plain.match(value, i)
            if match:
                main = value[:i].strip(" ,;:")
                condition = value[match.end():].strip(" ,;:")
                if main and condition:
                    return main, [condition], re.sub(r"\s+", " ", match.group(1).lower())
            for connector in CONDITION_CONNECTOR_CJK:
                if value.startswith(connector, i):
                    main = value[:i].strip(" ,;:")
                    condition = value[i + len(connector):].strip(" ,;:")
                    if main and condition:
                        return main, [condition], connector
        char = value[i]
        if char in "({[":
            depth += 1
        elif char in ")} ]".replace(" ", ""):
            depth = max(0, depth - 1)
        i += 1
    return value, [], ""


def rewrite_inverse_trig_notation(text):
    """Map conventional sin^{-1}(x) notation to an explicit inverse function."""
    pattern = inverse_trig_power_pattern()

    def repl(match):
        argument = match.group(2)
        if argument.startswith("{") and argument.endswith("}"):
            argument = "(" + argument[1:-1] + ")"
        elif not argument.startswith("("):
            argument = "(" + argument + ")"
        return INVERSE_TRIG_POWER_ALIASES[match.group(1)] + argument

    return pattern.sub(repl, text)


def rewrite_function_powers(text):
    """Rewrite cos^2(theta) as (cos(theta))^2 before generic script parsing."""
    pattern = re.compile(
        r"\\(sin|cos|tan|log|ln|exp)\s*\^(?:\{([^{}]+)\}|([A-Za-z0-9]))\s*"
        r"(\\[A-Za-z]+|\{[^{}]+\}|\([^()]+\)|[A-Za-z][A-Za-z0-9_]*)"
    )

    def repl(match):
        exponent = match.group(2) or match.group(3)
        argument = match.group(4)
        return r"(\%s%s)^{%s}" % (match.group(1), argument, exponent)

    return pattern.sub(repl, text)


def rewrite_nested_symbolic_function_arguments(text):
    """Keep forms such as ``\cos\theta(V)`` inside the outer function."""
    known = "sin|cos|tan|cot|sec|csc|sinh|cosh|tanh|log|ln|exp"
    symbolic = r"(?:\\[A-Za-z]+|[A-Za-z][A-Za-z0-9_]*(?:_\{[^{}]+\}|_[A-Za-z0-9]+)?)"
    pattern = re.compile(
        r"\\(" + known + r")\s*(" + symbolic + r")\s*"
        r"(?:\\left\s*)?\(([^()]*)\)(?:\s*\\right)?"
    )
    return pattern.sub(lambda match: r"\%s{%s(%s)}" % (
        match.group(1), match.group(2), match.group(3),
    ), text)


def strip_latex_noise(text):
    # A bare tilde is normally a non-breaking TeX space.  True mathematical
    # similarity commands are converted later by RELATION_COMMANDS.
    text = text.replace("~=", RELATION_APPROX_PLACEHOLDER)
    text = text.replace("~", ATOM_SEPARATOR)
    text = re.sub(
        r"\\(?:big|Big|bigg|Bigg|bigl|bigr|Bigl|Bigr|"
        r"biggl|biggr|Biggl|Biggr|left|right|"
        r"displaystyle|textstyle|scriptstyle|scriptscriptstyle|"
        r"sf|bf|cal|phantom|strut)\b",
        "",
        text,
    )
    text = re.sub(r"\\begin\{[^{}]+\}", " ", text)
    text = re.sub(r"\\end\{[^{}]+\}", " ", text)
    replacements = {
        r"\propto": "~",
        r"\cdots": "ellipsis",
        r"\ldots": "ellipsis",
        r"\dots": "ellipsis",
        r"\prime": "prime",
        r"\intercal": "T",
        r"\top": "T",
        r"\dagger": "dagger",
        r"\ast": "*",
        r"\star": "*",
        r"\partial": "partial",
        r"\nabla": "nabla",
        r"\sum": "sum",
        r"\prod": "prod",
        r"\int": "int",
        r"\infty": "infty",
    }
    for src, dst in replacements.items():
        text = re.sub(command_boundary(src.lstrip("\\")), dst + " ", text)
    for name, replacement in sorted(RELATION_COMMANDS.items(), key=lambda item: -len(item[0])):
        text = re.sub(command_boundary(name), " " + replacement + " ", text)
    text = text.replace(RELATION_APPROX_PLACEHOLDER, "~=")
    text = re.sub(
        r"\\(?:forall|cap|cup)(?![A-Za-z])",
        lambda match: " unsupported_" + match.group(0)[1:] + " ",
        text,
    )
    text = re.sub(r"\\(?:,|;|:|!)", ATOM_SEPARATOR, text)
    text = re.sub(
        r"\\(?:quad|qquad|enspace|thinspace|medspace|thickspace)(?![A-Za-z])",
        ATOM_SEPARATOR,
        text,
    )
    text = text.replace(r"\{", "(").replace(r"\}", ")")
    text = text.replace(r"\|", "")
    text = text.replace(r"\lVert", "").replace(r"\rVert", "")
    text = text.replace(r"\langle", "(").replace(r"\rangle", ")")
    return text


def insert_space_multiplication(text):
    text = text.replace(ATOM_SEPARATOR, " ")
    text = re.sub(r"(?<=[A-Za-z0-9_\)\]])\s+(?=[A-Za-z0-9_\\\(])", "*", text)
    text = re.sub(r"\s+", "", text)
    return text


def wrap_bare_function_args(text):
    names = "sin|cos|tan|log|ln|exp|sqrt|abs"
    text = re.sub(r"\b(%s)\s+\(" % names, r"\1(", text)
    text = re.sub(r"\b(%s)\s+([A-Za-z_][A-Za-z0-9_]*|\d+(?:\.\d+)?)\b" % names, r"\1(\2)", text)
    return text


def split_top_level_word(text, word):
    pieces = []
    depth = 0
    start = 0
    lowered = text.lower()
    needle = " " + word.lower() + " "
    i = 0
    while i < len(text):
        char = text[i]
        if char in "([{":
            depth += 1
            i += 1
            continue
        if char in ")]}":
            depth = max(0, depth - 1)
            i += 1
            continue
        if depth == 0 and lowered.startswith(needle, i):
            pieces.append(text[start:i].strip())
            i += len(needle)
            start = i
            continue
        i += 1
    pieces.append(text[start:].strip())
    return [piece for piece in pieces if piece]


def trim_formula_side(text, side):
    text = (text or "").strip(" ,.;:")
    if side == "left":
        markers = [
            " we write ", " as in ", " where ", " since ", " then ",
            " enough ", " is ", " are ", " gives ", " yields ",
            " or ", " which is ", " given ", " let ", " hence ",
            " result ", " result, ", " definition ",
        ]
        lowered = text.lower()
        cut = -1
        for marker in markers:
            index = lowered.rfind(marker)
            if index >= 0:
                cut = max(cut, index + len(marker))
        if cut >= 0:
            text = text[cut:].strip()
        tokens = text.split()
        if len(tokens) > 1 and not any(re.search(r"[+\-*/^()_\\]", token) for token in tokens[:-1]):
            text = tokens[-1]
    else:
        text = re.split(
            r"\s+(?:where|when|since|then|for|with|and sure|but|identifies|"
            r"represents|denotes|merges?|definition|table|figure)\b",
            text,
            1,
            flags=re.I,
        )[0]
        text = text.strip(" ,.;:")
    return text


def extract_inline_formula_candidates(text):
    text = normalize_pdf_math_text(text)
    text = " ".join((text or "").split())
    if not text:
        return []
    for src, dst in UNICODE_LATEX_REPLACEMENTS.items():
        text = text.replace(src, dst)
    pieces = []
    for chunk in re.split(r"[;。]|(?:\.\s+)", text):
        pieces.extend(split_top_level_word(chunk, "and"))
    candidates = []
    seen = set()
    relation_pattern = re.compile(r"(.{0,90}?)(=|<=|>=|<|>)(.{1,120})")
    for piece in pieces:
        if not re.search(r"[=<>]", piece):
            continue
        match = relation_pattern.search(piece)
        if not match:
            continue
        left = trim_formula_side(match.group(1), "left")
        right = trim_formula_side(match.group(3), "right")
        if not left or not right:
            continue
        candidate = ("%s%s%s" % (left, match.group(2), right)).strip(" ,.;:")
        if len(candidate) < 3 or len(candidate) > 180:
            continue
        if candidate not in seen:
            seen.add(candidate)
            candidates.append(candidate)
    return candidates


def normalize_latex(text):
    text = normalize_pdf_math_text(text)
    text = strip_outer_math(text)
    text = text.strip().rstrip(".,")
    text = re.sub(r"\\label\{[^{}]*\}", "", text)
    text = re.sub(r"\\tag\{[^{}]*\}", "", text)
    text = replace_latex_environment_blocks(text)
    text = repair_spaced_function_names(text)
    text = replace_expression_connectors(text)
    text = rewrite_nested_symbolic_function_arguments(text)
    text = strip_latex_noise(text)
    text = unwrap_latex_formatting(text)
    text = text.replace(r"\left", "").replace(r"\right", "")
    text = text.replace(r"\cdot", "*").replace(r"\times", "*")
    text = text.replace(r"\div", "/")
    text = re.sub(r"\\(?:d|t|c)frac\b", r"\\frac", text)
    text = rewrite_inverse_trig_notation(text)
    text = rewrite_function_powers(text)
    text = replace_frac(text)
    text = replace_latex_command_with_group(text, "sqrt", "sqrt")
    if should_process_tex_scripts(text):
        text = replace_script_groups(text)
    text = re.sub(re.escape(SCRIPT_END) + r"(?=\()", "", text)
    text = re.sub(re.escape(SCRIPT_END) + r"(?=[A-Za-z0-9_\\])", "*", text)
    text = text.replace(SCRIPT_END, "")
    text = re.sub(
        rf"(?<=[A-Za-z0-9_)])(?=\\(?:{TEX_ATOM_COMMANDS}|{TEX_FUNCTION_COMMANDS})\b)",
        "*",
        text,
    )
    for latex_name, ascii_name in GREEK_REPLACEMENTS.items():
        text = re.sub(
            command_boundary(latex_name.lstrip("\\")),
            " " + ascii_name + " ",
            text,
        )
    for name in sorted(FUNCTION_COMMANDS, key=len, reverse=True):
        text = re.sub(command_boundary(name), " " + name + " ", text)
    text = re.sub(r"\s+_", "_", text)
    text = re.sub(
        r"\b(alpha|beta|gamma|delta|theta|lambda|mu|nu|pi|rho|sigma|tau|phi|chi|psi|omega)"
        r"(sin|cos|tan|log|ln|exp)\b",
        r"\1*\2",
        text,
    )
    text = text.replace("'", "prime")
    text = text.replace("{", "(").replace("}", ")")
    text = text.replace("[", "(").replace("]", ")")
    # Unknown commands stay visible.  The standard parser must fail rather
    # than silently converting a semantic command into a plain identifier.
    text = wrap_bare_function_args(text)
    text = split_greek_letter_products(text)
    text = conservative_function_calls(text)
    text = insert_space_multiplication(text)
    function_names = "|".join(sorted(FUNCTION_COMMANDS, key=len, reverse=True))
    text = re.sub(
        r"\b(%s)\*([A-Za-z_][A-Za-z0-9_]*)" % function_names,
        r"\1(\2)",
        text,
    )
    text = conservative_function_calls(text)
    text = re.sub(r"\)+$", lambda m: m.group(0), text)
    text = text.replace(FORMAT_ATOM_JOIN, "_")
    text = text.strip().rstrip(".,")
    return text


TOKEN_RE = re.compile(
    r"\|->|==|<=|>=|!=|~=|->|\+\-|-\+|"
    r"[A-Za-z_][A-Za-z0-9_]*|\d+(?:\.\d+)?|[=~+\-*/^(),]"
)


def token_starts_atom(token):
    if token is None:
        return False
    return token == "(" or bool(re.match(r"[A-Za-z_]|\d", token))


def tokenize(expr):
    tokens = TOKEN_RE.findall(expr)
    compact = "".join(tokens)
    if compact != expr:
        # Keep the parser conservative: unsupported characters should be visible.
        raise ParseError("unsupported tokens in normalized expression: %r" % expr)
    return tokens


def split_top_level(text, separators=",;"):
    parts = []
    depth = 0
    start = 0
    for index, char in enumerate(text):
        if char == "(":
            depth += 1
        elif char == ")":
            depth = max(0, depth - 1)
        elif char in separators and depth == 0:
            parts.append(text[start:index])
            start = index + 1
    parts.append(text[start:])
    return [part for part in parts if part]


class Parser:
    def __init__(self, tokens):
        self.tokens = tokens
        self.pos = 0

    def current(self):
        if self.pos >= len(self.tokens):
            return None
        return self.tokens[self.pos]

    def accept(self, token):
        if self.current() == token:
            self.pos += 1
            return True
        return False

    def expect(self, token):
        if not self.accept(token):
            raise ParseError("expected %s at token %s" % (token, self.current()))

    def parse(self):
        node = self.parse_relation()
        if self.current() is not None:
            raise ParseError("trailing token %s" % self.current())
        return node

    def parse_relation(self):
        operands = [self.parse_sum()]
        operators = []
        while self.current() in RELATION_OPS:
            operators.append(self.current())
            self.pos += 1
            operands.append(self.parse_sum())
        if not operators:
            return operands[0]
        if len(operators) == 1:
            return Node("relation", operators[0], operands)
        derived = ""
        if all(operator in ("=", "==") for operator in operators):
            derived = "="
        elif all(operator in ("=", "==", "~=") for operator in operators) and "~=" in operators:
            derived = "~="
        elif all(operator == "<=" for operator in operators):
            derived = "<="
        elif all(operator == ">=" for operator in operators):
            derived = ">="
        return Node(
            "relation_chain",
            "relation_chain",
            operands,
            {"operators": operators, "derived_terminal_relation": derived},
        )

    def parse_equality(self):
        return self.parse_relation()

    def parse_sum(self):
        node = self.parse_product()
        while self.current() in ("+", "-", "+-", "-+"):
            op = self.current()
            self.pos += 1
            right = self.parse_product()
            node = Node("op", op, [node, right])
        return node

    def parse_product(self):
        node = self.parse_power()
        while self.current() in ("*", "/") or token_starts_atom(self.current()):
            if self.current() in ("*", "/"):
                op = self.current()
                self.pos += 1
            else:
                op = "*"
            right = self.parse_power()
            node = Node("op", op, [node, right])
        return node

    def parse_power(self):
        node = self.parse_unary()
        if self.accept("^"):
            right = self.parse_power()
            return Node("op", "^", [node, right])
        return node

    def parse_unary(self):
        if self.accept("-"):
            return Node("op", "neg", [self.parse_unary()])
        return self.parse_atom()

    def parse_atom(self):
        token = self.current()
        if token is None:
            raise ParseError("unexpected end")
        if token == "(":
            self.pos += 1
            node = self.parse_equality()
            if self.accept(","):
                items = [node]
                while True:
                    if self.current() == ")":
                        break
                    items.append(self.parse_equality())
                    if not self.accept(","):
                        break
                self.expect(")")
                return Node("tuple", "tuple", items)
            self.expect(")")
            return node
        if re.match(r"\d", token):
            self.pos += 1
            return Node("number", token)
        if re.match(r"[A-Za-z_]", token):
            self.pos += 1
            if self.accept("("):
                args = []
                if not self.accept(")"):
                    while True:
                        args.append(self.parse_equality())
                        if self.accept(")"):
                            break
                        self.expect(",")
                return Node("func", token, args)
            if token in FUNCTION_NAMES and token_starts_atom(self.current()):
                return Node("func", token, [self.parse_power()])
            return Node("symbol", token)
        raise ParseError("unexpected token %s" % token)


def parse_formula(latex):
    normalized = normalize_latex(latex)
    # Parse the complete normalized content first.  Only use extraction
    # candidates as a recovery path; structure fidelity auditing records any
    # discarded spans so a partial recovery cannot enter core statistics.
    normalized_parts = split_top_level(normalized, separators=";")
    if len(normalized_parts) > 1:
        parsed_parts = []
        for part in normalized_parts:
            parsed_parts.append(Parser(tokenize(part)).parse())
        return normalized, Node(
            "expression_bundle",
            "expression_bundle",
            parsed_parts,
            {"expression_count": len(parsed_parts)},
        )
    try:
        return normalized, Parser(tokenize(normalized)).parse()
    except Exception as whole_error:
        last_error = whole_error

    candidates = []
    for raw_candidate in extract_inline_formula_candidates(latex):
        try:
            candidates.append(normalize_latex(raw_candidate))
        except Exception:
            pass
    if "," in normalized or ";" in normalized:
        normalized_parts = split_top_level(normalized)
        candidates.extend(part for part in normalized_parts if "=" in part)
        candidates.extend(normalized_parts)
    candidates.append(normalized)

    seen = set()
    for candidate in candidates:
        candidate = candidate.strip().strip(",;")
        candidate = candidate.lstrip("+=,;")
        candidate = candidate.replace(":=", "=")
        if not candidate or candidate in seen:
            continue
        seen.add(candidate)
        try:
            tokens = tokenize(candidate)
            return candidate, Parser(tokens).parse()
        except Exception as exc:
            last_error = exc
    if last_error:
        raise last_error
    raise ParseError("empty normalized expression")


def unwrap_simple_latex_groups(text):
    wrappers = [
        "mathrm", "mathit", "mathbf", "mathsf", "mathcal", "mathbb", "textbf", "text", "cal",
        "operatorname", "operatorname*", "underline", "overline", "widehat", "hat", "tilde", "bar",
        "scriptstyle", "displaystyle", "boldsymbol", "pmb",
    ]
    changed = True
    while changed:
        changed = False
        for name in wrappers:
            pattern = re.compile(r"\\%s\s*\{([^{}]*)\}" % re.escape(name))
            new_text = pattern.sub(r"\1", text)
            if new_text != text:
                text = new_text
                changed = True
    return text


def extract_array_cells_for_ocr(text):
    if "\\begin{array}" not in text:
        return [text]
    body = re.sub(r"\\begin\{array\}\{[^{}]*\}", "", text)
    body = re.sub(r"\\end\{array\}", "", body)
    body = body.replace("\\\\", " & ")
    parts = re.split(r"&|\\\\", body)
    cells = []
    for part in parts:
        part = part.strip()
        part = re.sub(r"^\{+|\}+$", "", part).strip()
        if part:
            cells.append(part)
    scored = []
    for cell in cells:
        score = 0
        score += 5 if re.search(r"=|\\frac|\\cfrac|\\sum|\\int|\\sqrt|\\rightarrow|\\longrightarrow", cell) else 0
        score += min(4, len(re.findall(r"\\(alpha|beta|gamma|delta|theta|omega|sigma|varepsilon|mu|lambda|Gamma|Delta|Phi|Omega)", cell)))
        score -= 3 if len(re.findall(r"[A-Za-z]{8,}", cell)) >= 2 else 0
        scored.append((score, cell))
    scored.sort(key=lambda item: (item[0], -len(item[1])), reverse=True)
    return [cell for _score, cell in scored[:4]] or [text]


def balance_group_chars(text):
    pairs = [("{", "}"), ("(", ")"), ("[", "]")]
    for left, right in pairs:
        diff = text.count(left) - text.count(right)
        if diff > 0:
            text += right * min(diff, 8)
        elif diff < 0:
            remove = min(-diff, 8)
            while remove and text.startswith(right):
                text = text[1:]
                remove -= 1
    return text


def ocr_latex_cleanup_candidates(latex):
    text = latex or ""
    text = text.replace("\\left.", "").replace("\\right.", "")
    text = re.sub(r"\\(?:big|Big|bigg|Bigg)[lrm]?", "", text)
    text = text.replace("\\enspace", " ").replace("\\,", " ").replace("\\;", " ").replace("\\:", " ")
    text = text.replace("\\equiv", "==").replace("\\approx", "~=")
    text = text.replace("\\rightarrow", "->").replace("\\longrightarrow", "->").replace("\\to", "->")
    text = text.replace("\\downarrow", " ")
    text = text.replace("\\slash", "/")
    text = text.replace("\\lg", "\\log")
    text = re.sub(r"\\not\s*\{([^{}]*)\}", r"\1", text)
    text = re.sub(r"\\sqrt\[\[[^\]]+\]\]", r"\\sqrt", text)
    text = re.sub(r"\\sqrt\[[^\]]*\]", r"\\sqrt", text)
    text = re.sub(r"\([^()]*?=\s*1\s*,[^()]*?\\cdots[^()]*?\)\s*$", "", text)
    text = re.sub(r"\(?\s*\d+(?:\.\d+)?\s*\)\s*$", "", text)
    text = unwrap_simple_latex_groups(text)
    text = re.sub(r"\\[a-zA-Z]+\s*", "", text)
    text = re.sub(r"\|([^|]{1,120})\|", r"abs{\1}", text)
    text = re.sub(r"([A-Za-z0-9_\}\)])\s*\|", r"\1", text)
    text = text.replace("|", "")
    cells = extract_array_cells_for_ocr(text)
    candidates = []
    for cell in cells + [text]:
        cell = balance_group_chars(cell.strip())
        if not cell:
            continue
        candidates.append(cell)
        if "=" in cell:
            pieces = [p for p in cell.split("=") if p.strip()]
            for i in range(len(pieces) - 1):
                candidates.append(pieces[i].strip() + "=" + pieces[i + 1].strip())
    unique = []
    seen = set()
    for cand in candidates:
        key = re.sub(r"\s+", "", cand)
        if key and key not in seen:
            seen.add(key)
            unique.append(cand)
    return unique


def symbol_from_fragment(text, default="x"):
    text = unwrap_simple_latex_groups(text or "")
    for latex_name, ascii_name in GREEK_REPLACEMENTS.items():
        text = text.replace(latex_name, ascii_name)
    text = re.sub(r"\\([A-Za-z]+)", r"\1", text)
    tokens = re.findall(r"[A-Za-z][A-Za-z0-9_]*|\d+(?:\.\d+)?", text)
    tokens = [t for t in tokens if t.lower() not in TEXT_NOISE_WORDS and len(t) <= 24]
    if not tokens:
        return Node("symbol", default)
    if len(tokens) == 1:
        return Node("number" if re.match(r"\d", tokens[0]) else "symbol", tokens[0])
    children = [Node("number" if re.match(r"\d", t) else "symbol", t) for t in tokens[:5]]
    return Node("op", "*", children)


def heuristic_tree_from_ocr_latex(latex):
    text = latex or ""
    clean_candidates = ocr_latex_cleanup_candidates(text)
    for cand in clean_candidates:
        try:
            normalized = normalize_latex(cand)
            tokens = tokenize(normalized)
            return normalized, Parser(tokens).parse()
        except Exception:
            pass
    clean = clean_candidates[0] if clean_candidates else text
    if "=" in clean:
        left, right = clean.split("=", 1)
        return "ocr_relaxed=" + re.sub(r"\s+", "", clean[:120]), Node("op", "=", [symbol_from_fragment(left, "lhs"), symbol_from_fragment(right, "rhs")])
    frac = re.search(r"\\(?:c?frac)\s*\{([^{}]{1,80})\}\s*\{([^{}]{1,80})\}", clean)
    if frac:
        return "ocr_relaxed_frac", Node("op", "/", [symbol_from_fragment(frac.group(1), "num"), symbol_from_fragment(frac.group(2), "den")])
    if re.search(r"rightarrow|longrightarrow|=", text):
        parts = re.split(r"\\(?:long)?rightarrow|=", text)
        args = [symbol_from_fragment(part, "state") for part in parts if part.strip()][:4]
        if len(args) >= 2:
            return "ocr_relaxed_transition", Node("func", "transition", args)
    return "ocr_relaxed_symbolic", symbol_from_fragment(clean, "ocr_formula")


KNOWN_LATEX_COMMANDS = {
    "left", "right", "big", "Big", "bigg", "Bigg", "bigl", "bigr", "Bigl", "Bigr",
    "biggl", "biggr", "Biggl", "Biggr", "displaystyle", "textstyle",
    "scriptstyle", "scriptscriptstyle", "sf", "bf", "phantom", "strut",
    "frac", "cfrac", "dfrac", "tfrac", "sqrt", "cdot", "times", "div", "pm", "ast", "star",
    "sin", "cos", "tan", "log", "ln", "exp", "lg",
    "equiv", "approx", "simeq", "le", "leq", "ge", "geq", "ne", "neq",
    "propto", "sim", "to", "rightarrow", "longrightarrow", "mapsto",
    "partial", "nabla", "sum", "prod", "int", "infty",
    "mathbf", "mathbb", "mathcal", "mathrm", "mathsf", "mathtt", "mathfrak", "boldsymbol",
    "text", "operatorname", "hat", "bar", "tilde", "dot", "ddot", "vec",
    "begin", "end", "label", "tag", "quad", "qquad", "enspace",
    "intercal", "top", "dagger", "cdots", "ldots", "dots", "lVert", "rVert",
    "langle", "rangle", "cal", "not", "slash", "downarrow", "prime",
} | {name.lstrip("\\") for name in GREEK_REPLACEMENTS} | ALL_KNOWN_COMMANDS


def parse_diagnostics(latex, normalized, parse_mode, repaired=0, original_error=""):
    raw = latex or ""
    commands = re.findall(r"\\([A-Za-z]+)", raw)
    unknown = sorted({name for name in commands if name not in KNOWN_LATEX_COMMANDS})
    raw_tokens = re.findall(r"[A-Za-z]+|\d+(?:\.\d+)?|[=<>+\-*/^]", raw)
    normalized_tokens = TOKEN_RE.findall(normalized or "")
    # Standard parsing fully consumes the normalized expression.  Comparing
    # raw LaTeX token counts with normalized tokens would incorrectly punish
    # valid subscripts such as x_1+x_2.
    if parse_mode == "standard":
        coverage = 1.0
    elif parse_mode == "safe_relaxed" and repaired == 0 and not unknown:
        coverage = 1.0
    else:
        coverage = min(1.0, len(normalized_tokens) / max(1, len(raw_tokens)))
    if unknown:
        parse_mode = "lossy_heuristic"
    return ParseDiagnostics(
        parse_mode=parse_mode,
        semantic_coverage=round(coverage, 4),
        dropped_semantic_commands=unknown,
        repaired_delimiter_count=repaired,
        raw_math_token_count=len(raw_tokens),
        normalized_math_token_count=len(normalized_tokens),
        original_error=original_error,
    )


def walk_nodes(node):
    yield node
    for child in node.children:
        for descendant in walk_nodes(child):
            yield descendant


def prepare_audit_latex(text):
    """Remove TeX layout spacing before comparing mathematical structure."""
    text = repair_spaced_function_names(text or "")
    text = replace_expression_connectors(text)
    text = re.sub(r"\\(?:,|;|:|!)(?![A-Za-z])", " ", text)
    text = re.sub(
        r"\\(?:quad|qquad|enspace|thinspace|medspace|thickspace|hspace\*?|kern|mkern)"
        r"(?![A-Za-z])(?:\{[^{}]*\})?",
        " ",
        text,
    )
    return text.replace("~", " ")


def canonical_raw_symbol(name):
    return re.sub(
        r"_\{([^{}]+)\}",
        lambda match: "_" + re.sub(r"[^A-Za-z0-9]+", "_", match.group(1)).strip("_"),
        name,
    )


def raw_symbolic_functions(text):
    candidates = re.findall(
        r"(?<!\\)\b([A-Za-z][A-Za-z0-9_]*(?:_\{[^{}]+\}|_[A-Za-z0-9]+)?)\s*"
        r"(?:\\left\s*)?\(",
        text,
    )
    relation = re.search(
        r"\\(?:equiv|approx|simeq|sim|leq?|geq?|ne|neq|to|rightarrow|longrightarrow)\b|=",
        text,
    )
    lhs_names = set()
    if relation:
        lhs_names.update(canonical_raw_symbol(name) for name in re.findall(
            r"\b([A-Za-z][A-Za-z0-9_]*(?:_\{[^{}]+\}|_[A-Za-z0-9]+)?)\s*"
            r"(?:\\left\s*)?\(",
            text[:relation.start()],
        ))
    output = []
    for raw_name in candidates:
        name = canonical_raw_symbol(raw_name)
        if is_conservative_function_name(name, lhs_names):
            output.append(name)
    for name in re.findall(
        r"\\(phi|theta|psi|Phi|Theta|Psi)\s*(?:\\left\s*)?\(",
        text,
    ):
        output.append(name)
    return output


def ambiguous_symbolic_calls(text):
    """Return A(x)-style calls whose function/product meaning is unresolved."""
    value = prepare_audit_latex(text or "")
    names = re.findall(
        r"(?<!\\)\b([A-Za-z][A-Za-z0-9_]*(?:_\{[^{}]+\}|_[A-Za-z0-9]+)?)\s*"
        r"(?:\\left\s*)?\(",
        value,
    )
    ambiguous = []
    for raw_name in names:
        name = canonical_raw_symbol(raw_name)
        base = name.split("_", 1)[0]
        if name in FUNCTION_NAMES or base in SYMBOLIC_FUNCTION_BASES:
            continue
        if name not in ambiguous:
            ambiguous.append(name)
    return ambiguous


def raw_structure_signature(latex):
    text = rewrite_inverse_trig_notation(prepare_audit_latex(latex))
    relation_text = text
    for name, replacement in sorted(RELATION_COMMANDS.items(), key=lambda item: -len(item[0])):
        relation_text = re.sub(command_boundary(name), " " + replacement + " ", relation_text)
    relations = re.findall(r"(?<![<>!~])==|<=|>=|!=|~=|\|->|->|(?<![<>=!~])=(?!=)|~", relation_text)
    # Keep the historical structural audit stable. The registry is broader
    # than the legacy audit (for example min/max and hyperbolic functions), so
    # only the inverse-trigonometric spellings are added here in v3.4.
    audited_function_names = {
        "sin", "cos", "tan", "log", "ln", "exp", "sqrt",
        "asin", "acos", "atan", "acot", "asec", "acsc",
        "arcsin", "arccos", "arctan", "arccot", "arcsec", "arccsc",
    }
    registered_functions = "|".join(
        sorted(audited_function_names, key=len, reverse=True)
    )
    functions = re.findall(
        r"\\(?:mathrm|operatorname\*?)?\s*\{?(" + registered_functions + r")(?![A-Za-z])\}?",
        text,
    )
    functions.extend(raw_symbolic_functions(text))
    major = []
    for name in ("frac", "dfrac", "tfrac", "int", "iint", "iiint", "oint", "sum", "prod", "lim", "sqrt"):
        major.extend([name] * len(re.findall(command_boundary(name), text)))
    environments = re.findall(r"\\begin\{([^{}]+)\}", text)
    rows = split_latex_rows(text)
    semicolon_parts = [part for part in re.split(r"(?<!\\);", text) if part.strip()]
    expression_count = max(1, len(rows), len(semicolon_parts))
    return {
        "relations": relations,
        "functions": sorted(functions),
        "major_structures": sorted(major),
        "environments": environments,
        "top_level_expression_count": expression_count,
        "semantic_commands": sorted(set(re.findall(r"\\([A-Za-z]+)", text)) - SAFE_LAYOUT_COMMANDS - SPACING_COMMANDS),
    }


def tree_structure_signature(tree):
    nodes = list(walk_nodes(tree))
    relations = []
    for node in nodes:
        if node.kind == "relation_chain":
            relations.extend(node.attributes.get("operators", []))
        elif node.kind == "relation" or node.value in RELATION_OPS:
            relations.append(node.value)
    functions = sorted(node.value for node in nodes if node.kind == "func")
    major = []
    major.extend("frac" for node in nodes if node.kind == "op" and node.value == "/")
    for name in ("int", "sum", "prod", "lim", "sqrt", "matrix", "cases"):
        major.extend(name for node in nodes if node.value == name)
    expression_count = len(tree.children) if tree.kind == "expression_bundle" else 1
    return {
        "relations": relations,
        "functions": functions,
        "major_structures": sorted(major),
        "top_level_expression_count": expression_count,
    }


def audit_tree_fidelity(latex, normalized, tree, diagnostics):
    raw_signature = raw_structure_signature(latex)
    parsed_signature = tree_structure_signature(tree)
    reasons = []
    raw_relations = raw_signature["relations"]
    tree_relations = parsed_signature["relations"]
    if raw_relations != tree_relations:
        reasons.append("relation_operator_sequence_mismatch")
    raw_functions = Counter(raw_signature["functions"])
    tree_functions = Counter(parsed_signature["functions"])
    for name, count in raw_functions.items():
        if tree_functions[name] < count:
            reasons.append("function_missing:%s" % name)
    for name, count in tree_functions.items():
        if name not in {"matrix", "cases", "sum", "prod", "int", "lim"} and raw_functions[name] < count:
            reasons.append("function_created:%s" % name)
    for raw_name in raw_signature["major_structures"]:
        expected = "frac" if raw_name in ("frac", "dfrac", "tfrac") else raw_name
        if expected not in parsed_signature["major_structures"]:
            reasons.append("major_structure_missing:%s" % raw_name)
    raw_count = raw_signature["top_level_expression_count"]
    parsed_count = parsed_signature["top_level_expression_count"]
    if raw_count != parsed_count:
        reasons.append("expression_count_mismatch:%d!=%d" % (raw_count, parsed_count))
    if diagnostics.parse_mode == "lossy_heuristic":
        reasons.append("lossy_heuristic_parse")
    if diagnostics.dropped_semantic_commands:
        reasons.append("semantic_command_dropped")
    if diagnostics.parse_mode == "standard" and normalize_latex(normalized) != normalized:
        reasons.append("normalization_non_idempotent")
    unsupported = sorted(
        set(raw_signature["semantic_commands"]) &
        ({"int", "iint", "iiint", "oint", "sum", "prod", "lim", "matrix", "cases", "mapsto", "in", "notin"})
    )
    if unsupported:
        reasons.append("parser_support_pending:" + ",".join(unsupported))
    diagnostics.raw_structure_signature = raw_signature
    diagnostics.tree_structure_signature = parsed_signature
    diagnostics.raw_expression_count = raw_count
    diagnostics.parsed_expression_count = parsed_count
    diagnostics.segmentation_status = "complete" if raw_count == parsed_count else "expression_loss"
    diagnostics.ambiguous_symbolic_calls = ambiguous_symbolic_calls(latex)
    diagnostics.tree_fidelity_reasons = sorted(set(reasons))
    diagnostics.normalization_semantic_coverage = 0.0 if reasons else 1.0
    if not reasons:
        diagnostics.tree_fidelity_status = "passed"
    elif unsupported and all(reason.startswith("parser_support_pending:") for reason in reasons):
        diagnostics.tree_fidelity_status = "unsupported"
    else:
        diagnostics.tree_fidelity_status = "failed"
    return diagnostics


def safe_relaxed_latex(latex):
    text = latex or ""
    text = text.replace("\\left.", "").replace("\\right.", "")
    text = re.sub(r"\\(?:big|Big|bigg|Bigg)[lrm]?", "", text)
    text = text.replace("\\enspace", " ").replace("\\,", " ").replace("\\;", " ").replace("\\:", " ")
    before = sum(abs(text.count(a) - text.count(b)) for a, b in (("{", "}"), ("(", ")"), ("[", "]")))
    text = balance_group_chars(text)
    after = sum(abs(text.count(a) - text.count(b)) for a, b in (("{", "}"), ("(", ")"), ("[", "]")))
    return text, max(0, before - after)


def parse_formula_with_ocr_fallback(latex):
    main_latex, condition_spans, condition_connector = split_formula_conditions(latex)
    try:
        normalized, tree = parse_formula(main_latex)
        diagnostics = parse_diagnostics(main_latex, normalized, "standard")
        diagnostics = audit_tree_fidelity(main_latex, normalized, tree, diagnostics)
    except Exception as original_exc:
        safe_text, repaired = safe_relaxed_latex(main_latex)
        try:
            normalized, tree = parse_formula(safe_text)
            diagnostics = parse_diagnostics(
                main_latex, normalized, "safe_relaxed", repaired,
                str(original_exc).replace(";", ",")[:160],
            )
            diagnostics = audit_tree_fidelity(main_latex, normalized, tree, diagnostics)
        except Exception:
            try:
                normalized, tree = heuristic_tree_from_ocr_latex(main_latex)
                diagnostics = parse_diagnostics(
                    main_latex, normalized, "lossy_heuristic", repaired,
                    str(original_exc).replace(";", ",")[:160],
                )
                diagnostics.parse_mode = "lossy_heuristic"
                diagnostics = audit_tree_fidelity(main_latex, normalized, tree, diagnostics)
            except Exception:
                raise original_exc
    diagnostics.main_expression_latex = main_latex
    diagnostics.condition_spans = condition_spans
    diagnostics.condition_connector = condition_connector
    if condition_spans and diagnostics.segmentation_status == "complete":
        diagnostics.segmentation_status = "main_expression_with_conditions"
    return normalized, tree, diagnostics


def complexity(node):
    return node.depth() + len(node.leaf_values())


def analysis_target(node):
    if node.kind == "relation_chain":
        return max(node.children, key=complexity)
    if node.kind == "expression_bundle":
        return max((analysis_target(child) for child in node.children), key=complexity)
    if node.value not in RELATION_OPS or len(node.children) != 2:
        return node
    left, right = node.children
    # Equations of the form expression=0 should be analyzed by their expression.
    if right.kind == "number" and right.value == "0":
        return left
    if left.kind == "number" and left.value == "0":
        return right
    return right if complexity(right) >= complexity(left) else left


def child_has_op(node, ops):
    return any(child.value in ops or child.contains_value(ops) for child in node.children)


def has_numeric_leaf(node):
    return any(re.match(r"^\d", str(value)) for value in node.leaf_values())


def direct_product_like(node):
    return node.value in ("*", "/") or (
        node.value == "neg" and node.children and node.children[0].value in ("*", "/")
    )


GREEK_SYMBOL_NAMES = {
    "alpha", "beta", "gamma", "delta", "epsilon", "theta", "lambda",
    "mu", "nu", "pi", "rho", "sigma", "tau", "phi", "omega", "xi",
    "Theta",
}

TEXT_NOISE_SYMBOLS = {
    "an", "and", "are", "as", "at", "be", "by", "can", "case",
    "constant", "data", "days", "domain", "figure", "for", "from", "has",
    "if", "in", "indexed", "is", "it", "no", "not", "of", "on", "or", "set",
    "since", "specified", "that", "the", "then", "this", "to", "using",
    "we", "where", "write",
}

TEXT_NOISE_WORDS = TEXT_NOISE_SYMBOLS | {
    "about", "all", "also", "analogous", "another", "because", "been", "being",
    "between", "but", "connection", "described", "different", "does", "during",
    "each", "earlier", "equation", "example", "function", "graph", "growth",
    "have", "having", "input", "known", "like", "method", "model", "number",
    "output", "perturbed", "plot", "point", "proportional", "random", "real",
    "relation", "represented", "right", "rule", "same", "section", "should",
    "shown", "simulates", "sometimes", "squared", "standard", "state", "such",
    "summary", "system", "these", "trajectory", "two", "via", "with", "works",
}


def is_variable_like_symbol(node):
    if node.kind != "symbol":
        return False
    value = str(node.value)
    lowered = value.lower()
    constants = globals().get("CONSTANT_SYMBOLS", {"pi", "e"})
    if value in constants or lowered in {str(item).lower() for item in constants}:
        return False
    if lowered in TEXT_NOISE_SYMBOLS:
        return False
    if value in FUNCTION_NAMES:
        return False
    return bool(re.fullmatch(r"[A-Za-z][A-Za-z0-9_]*", value))


def contains_variable_like_symbol(node):
    if is_variable_like_symbol(node):
        return True
    return any(contains_variable_like_symbol(child) for child in node.children)


def flatten_associative(node, op):
    if node.value != op:
        return [node]
    items = []
    for child in node.children:
        items.extend(flatten_associative(child, op))
    return items


def alpha_shape(node, variable_map=None):
    """Canonical subtree shape with consistent alpha-renaming of variables."""
    if variable_map is None:
        variable_map = {}
    if is_variable_like_symbol(node):
        value = str(node.value)
        if value not in variable_map:
            variable_map[value] = "v%d" % len(variable_map)
        return variable_map[value]
    if node.kind == "number":
        return "#"
    if not node.children:
        return "%s:%s" % (node.kind, node.value)
    child_shapes = [alpha_shape(child, variable_map) for child in node.children]
    if node.value in ("+", "*"):
        child_shapes = sorted(child_shapes)
    return "%s(%s)" % (node.value, ",".join(child_shapes))


def symmetry_shape(node):
    return alpha_shape(node)


def iter_nodes_with_path(node, path=()):
    yield node, path
    for index, child in enumerate(node.children):
        yield from iter_nodes_with_path(child, path + (index,))


def has_two_independent_occurrences(paths):
    for i, left in enumerate(paths):
        for right in paths[i + 1:]:
            if left != right and left[:len(right)] != right and right[:len(left)] != left:
                return True
    return False


def has_simple_symmetry(node):
    if node.value in ("+", "*"):
        shape_counts = Counter()
        for item in flatten_associative(node, node.value):
            if contains_variable_like_symbol(item):
                shape_counts[alpha_shape(item)] += 1
        if any(count >= 2 for count in shape_counts.values()):
            return True
    return any(has_simple_symmetry(child) for child in node.children)


PATTERN_TEMPLATES = [
    {
        "code": "M01",
        "tag": "M01_basic_additive_separable_no_overlap",
        "name": "基础加法可分离（无重合变量）",
        "rule": "+/- 节点两侧变量集合非空且不重合",
    },
    {
        "code": "M02",
        "tag": "M02_basic_multiplicative_separable_no_overlap",
        "name": "基础乘法可分离（无重合变量）",
        "rule": "*/ / 节点两侧变量集合非空且不重合",
    },
    {
        "code": "M03",
        "tag": "M03_overlapping_additive",
        "name": "带重合变量的加法可分离",
        "rule": "+/- 节点两侧变量集合存在交集",
    },
    {
        "code": "M04",
        "tag": "M04_overlapping_multiplicative",
        "name": "带重合变量的乘法可分离",
        "rule": "*/ / 节点两侧变量集合存在交集",
    },
    {
        "code": "M05",
        "tag": "M05_product_with_constant",
        "name": "带常数项的乘法可分离",
        "rule": "+/- 节点包含乘法子结构和独立常数项",
    },
    {
        "code": "M06",
        "tag": "M06_compositionality",
        "name": "Compositionality / 复合结构总计",
        "rule": "函数节点参数为非原子表达式，或命中 M07-M10",
    },
    {
        "code": "M07",
        "tag": "M07_log_exp_nested",
        "name": "log / exp 嵌套特殊分离",
        "rule": "log/ln/exp 的参数为复合或可分离结构",
    },
    {
        "code": "M08",
        "tag": "M08_sin_nested",
        "name": "sin 嵌套特殊分离",
        "rule": "sin 的参数为加法、乘法或其他复合表达式",
    },
    {
        "code": "M09",
        "tag": "M09_universal_additive_generalized_additivity",
        "name": "通用加法分离 U(g+h) / Generalized additivity",
        "rule": "外层函数或复合结构 U 的内部根节点为 +/-",
    },
    {
        "code": "M10",
        "tag": "M10_universal_multiplicative",
        "name": "通用乘法分离 U(g*h)",
        "rule": "外层函数或复合结构 U 的内部根节点为 */ /",
    },
    {
        "code": "M11",
        "tag": "M11_generalized_symmetry",
        "name": "Generalized symmetry",
        "rule": "广义对称结构；M12 Simple symmetry 命中时同步计入",
    },
    {
        "code": "M12",
        "tag": "M12_simple_symmetry",
        "name": "Simple symmetry",
        "rule": "+/* 同层中存在变量置换后等价的可交换子结构",
    },
]

PATTERN_BY_CODE = {item["code"]: item for item in PATTERN_TEMPLATES}
ADD_OPS = {"+", "-"}
MUL_OPS = {"*", "/"}
SEPARABILITY_OPS = ADD_OPS | MUL_OPS
def iter_nodes(node):
    yield node
    for child in node.children:
        yield from iter_nodes(child)


def is_atomic_node(node):
    return node.kind in ("number", "symbol") or not node.children


def variable_symbols(node):
    if node.kind == "symbol" and is_variable_like_symbol(node):
        return {str(node.value)}
    values = set()
    for child in node.children:
        values.update(variable_symbols(child))
    return values


def is_constant_like(node):
    if node.kind == "number":
        return True
    if node.kind == "symbol" and str(node.value) in CONSTANT_SYMBOLS:
        return True
    if node.value == "neg" and len(node.children) == 1:
        return is_constant_like(node.children[0])
    return False


def contains_product_like(node):
    return any(item.value in MUL_OPS for item in iter_nodes(node))


def contains_separability_op(node):
    return any(item.value in SEPARABILITY_OPS for item in iter_nodes(node))


def is_product_with_constant_pattern(node):
    if node.value not in ADD_OPS or len(node.children) != 2:
        return False
    left, right = node.children
    if contains_product_like(left) and is_constant_like(right):
        return True
    if contains_product_like(right) and is_constant_like(left):
        return True
    return False


def count_simple_symmetry_nodes(node):
    count = 0
    if node.value in ("+", "*"):
        shape_counts = Counter()
        for item in flatten_associative(node, node.value):
            if contains_variable_like_symbol(item):
                shape_counts[alpha_shape(item)] += 1
        if any(value >= 2 for value in shape_counts.values()):
            count += 1
    for child in node.children:
        count += count_simple_symmetry_nodes(child)
    return count


def count_generalized_symmetry_nodes(node):
    groups = defaultdict(list)
    for item, path in iter_nodes_with_path(node):
        if item.children and contains_variable_like_symbol(item):
            groups[alpha_shape(item)].append(path)
    return sum(1 for paths in groups.values() if has_two_independent_occurrences(paths))


def match_pattern_templates(target):
    occurrence_counts = Counter()

    for node in iter_nodes(target):
        if node.value in ADD_OPS and len(node.children) == 2:
            left_vars = variable_symbols(node.children[0])
            right_vars = variable_symbols(node.children[1])
            if left_vars or right_vars:
                if left_vars & right_vars:
                    occurrence_counts["M03"] += 1
                else:
                    occurrence_counts["M01"] += 1
            if is_product_with_constant_pattern(node):
                occurrence_counts["M05"] += 1

        if node.value in MUL_OPS and len(node.children) == 2:
            left_vars = variable_symbols(node.children[0])
            right_vars = variable_symbols(node.children[1])
            if left_vars and right_vars:
                if left_vars & right_vars:
                    occurrence_counts["M04"] += 1
                else:
                    occurrence_counts["M02"] += 1

        if node.kind == "func":
            m06_counted_for_node = False
            non_atomic_args = [child for child in node.children if not is_atomic_node(child)]
            if non_atomic_args:
                occurrence_counts["M06"] += 1
                m06_counted_for_node = True
            if node.children:
                first_arg = node.children[0]
                if node.value in {"log", "ln", "exp"} and contains_separability_op(first_arg):
                    occurrence_counts["M07"] += 1
                    if not m06_counted_for_node:
                        occurrence_counts["M06"] += 1
                        m06_counted_for_node = True
                if node.value == "sin" and contains_separability_op(first_arg):
                    occurrence_counts["M08"] += 1
                    if not m06_counted_for_node:
                        occurrence_counts["M06"] += 1
                        m06_counted_for_node = True
                if node.value not in SPECIAL_NESTED_FUNCTIONS and first_arg.value in ADD_OPS:
                    occurrence_counts["M09"] += 1
                    if not m06_counted_for_node:
                        occurrence_counts["M06"] += 1
                        m06_counted_for_node = True
                if node.value not in SPECIAL_NESTED_FUNCTIONS and first_arg.value in MUL_OPS:
                    occurrence_counts["M10"] += 1
                    if not m06_counted_for_node:
                        occurrence_counts["M06"] += 1
                        m06_counted_for_node = True

    simple_count = count_simple_symmetry_nodes(target)
    if simple_count:
        occurrence_counts["M12"] += simple_count
        occurrence_counts["M11"] += simple_count

    generalized_count = count_generalized_symmetry_nodes(target)
    if generalized_count:
        occurrence_counts["M11"] = max(occurrence_counts["M11"], generalized_count)

    formula_level_tags = [
        PATTERN_BY_CODE[code]["tag"]
        for code in sorted(occurrence_counts)
        if occurrence_counts[code] > 0
    ]
    matched_templates = [
        "%s. %s" % (code, PATTERN_BY_CODE[code]["name"])
        for code in sorted(occurrence_counts)
        if occurrence_counts[code] > 0
    ]
    return {
        "formula_level_tags": formula_level_tags,
        "pattern_occurrence_counts": dict(sorted(occurrence_counts.items())),
        "matched_templates": matched_templates,
    }


def root_pattern(node):
    if node.value in ADD_OPS:
        return "root_additive"
    if node.value in MUL_OPS:
        return "root_multiplicative"
    if node.kind == "func":
        return "root_function"
    if node.value == "^":
        return "root_power"
    return "root_atomic"


def layer_pattern(node):
    if node.value in ADD_OPS and child_has_op(node, MUL_OPS):
        return "add_then_mul"
    if node.value in MUL_OPS and child_has_op(node, ADD_OPS):
        return "mul_then_add"
    if node.kind == "func" and node.children:
        first_arg = node.children[0]
        if first_arg.value in ADD_OPS:
            return "func_then_add"
        if first_arg.value in MUL_OPS:
            return "func_then_mul"
    return "flat_or_unknown"


def function_names(node):
    return sorted({item.value for item in iter_nodes(node) if item.kind == "func"})


def operator_path_signatures(node):
    signatures = set()

    def walk(parent):
        for child in parent.children:
            if parent.children and (parent.kind == "func" or parent.value in SEPARABILITY_OPS or parent.value == "^"):
                if child.kind == "func" or child.value in SEPARABILITY_OPS or child.value == "^":
                    signatures.add("%s -> %s" % (parent.value, child.value))
            walk(child)

    walk(node)
    return sorted(signatures)


def nested_function_patterns(node):
    patterns = set()
    for item in iter_nodes(node):
        if item.kind == "func" and item.children:
            patterns.add("%s(%s)" % (item.value, item.children[0].value))
    return sorted(patterns)


def variable_overlap_status(node):
    statuses = set()
    for item in iter_nodes(node):
        if item.value in ADD_OPS and len(item.children) == 2:
            left_vars = variable_symbols(item.children[0])
            right_vars = variable_symbols(item.children[1])
            if left_vars and right_vars:
                statuses.add("additive_overlap" if left_vars & right_vars else "additive_no_overlap")
        if item.value in MUL_OPS and len(item.children) == 2:
            left_vars = variable_symbols(item.children[0])
            right_vars = variable_symbols(item.children[1])
            if left_vars and right_vars:
                statuses.add("multiplicative_overlap" if left_vars & right_vars else "multiplicative_no_overlap")
    if not statuses:
        return "no_binary_variable_split"
    return "; ".join(sorted(statuses))


def structure_features(target, pattern_result):
    variables = sorted(variable_symbols(target))
    funcs = function_names(target)
    op_paths = operator_path_signatures(target)
    nested_funcs = nested_function_patterns(target)
    return {
        "root_operator": target.value,
        "root_pattern": root_pattern(target),
        "layer_pattern": layer_pattern(target),
        "function_nodes": "; ".join(funcs),
        "has_constant_or_coefficient": "1" if has_numeric_leaf(target) or any(
            str(value) in CONSTANT_SYMBOLS for value in target.leaf_values()
        ) else "0",
        "variable_sets": json.dumps(variables, ensure_ascii=False),
        "variable_overlap_status": variable_overlap_status(target),
        "subtree_pattern_tags": "; ".join(pattern_result["formula_level_tags"]),
        "operator_path_signatures": "; ".join(op_paths),
        "nested_function_patterns": "; ".join(nested_funcs),
    }


def symbol_tokens_from_text(text):
    return [token.lower() for token in re.findall(r"[A-Za-z]{2,}", text or "")]


def math_signal_score(text):
    text = text or ""
    score = 0
    score += len(re.findall(r"[=+\-*/^]", text)) * 2
    score += len(re.findall(r"\\[A-Za-z]+", text)) * 2
    score += len(re.findall(r"\b(sin|cos|tan|log|ln|exp|sqrt|sum|int|frac)\b", text)) * 2
    score += len(re.findall(r"\d", text))
    return score


def normalized_formula_key(text):
    return re.sub(r"\s+", "", text or "")


def uses_inline_formula_candidate(formula_text, normalized):
    target_key = normalized_formula_key(normalized)
    if not target_key:
        return False
    for raw_candidate in extract_inline_formula_candidates(formula_text):
        try:
            if normalized_formula_key(normalize_latex(raw_candidate)) == target_key:
                return True
        except Exception:
            continue
    return False


def count_math_ops(text):
    return len(re.findall(r"[=+\-*/^<>]", text or ""))


def leaf_nodes(node):
    leaves = []
    if not node.children:
        return [node]
    for child in node.children:
        leaves.extend(leaf_nodes(child))
    return leaves


def is_simple_symbol_node(node):
    return node.kind == "symbol" and re.match(r"^[A-Za-z][A-Za-z0-9_]*$", str(node.value))


def is_atomic_or_unary_constant(node):
    if node.kind in ("number", "symbol"):
        return True
    if node.value == "neg" and len(node.children) == 1:
        return is_atomic_or_unary_constant(node.children[0])
    return False


def is_non_atomic_symmetry_component(node):
    """Do not call a*b or x+y a symmetry only because both leaves are symbols."""
    if node.kind in ("number", "symbol"):
        return False
    return contains_variable_like_symbol(node) and len(leaf_nodes(node)) >= 2


def has_insufficient_decomposition_signal(formula_text, target):
    relation_markers = ("=", r"\equiv", r"\le", r"\ge", r"\approx", r"\propto", r"\sim")
    if any(marker in (formula_text or "") for marker in relation_markers):
        return False
    # A two-term addition or multiplication is already a meaningful
    # decomposition pattern.  The old leaf-count shortcut incorrectly
    # rejected standards such as x+y and a*x+b*y.
    if contains_separability_op(target):
        return False
    variable_count = sum(1 for item in leaf_nodes(target) if item.kind == "symbol")
    return variable_count <= 2 and len(leaf_nodes(target)) <= 2


def has_unrepresented_comparison(formula_text, target):
    # Require a complete command: ``\\left`` must not be mistaken for ``\\le``.
    if not re.search(r"\\(?:le|ge|approx|propto|sim)(?![A-Za-z])", formula_text or ""):
        return False
    return not any(token in target.preorder() for token in ("<=", ">=", "approx", "propto"))


def has_unresolved_ocr_layout(formula_text, target):
    """Arrays/alignment markup must be segmented before structural clustering."""
    raw = formula_text or ""
    tree_text = target.preorder()
    layout_markers = (r"\begin{array}", r"\end{array}", r"\begin{aligned}", r"\end{aligned}", r"\nonumber")
    has_layout = any(marker in raw for marker in layout_markers) or " array" in tree_text
    if not has_layout:
        return False
    return (
        raw.count(r"\begin{array}") >= 1
        or raw.count(r"\qquad") >= 4
        or len(raw) >= 260
        or " array" in tree_text
    )


def is_trivial_function_call_or_evaluation(target):
    if target.kind != "func":
        return False
    if not target.children:
        return True
    if all(is_atomic_or_unary_constant(child) for child in target.children):
        return True
    if str(target.value) in GENERIC_FUNCTION_NAMES:
        return not any(child.kind == "func" or child.contains_kind("func") for child in target.children)
    return False


def is_trivial_function_placeholder(formula_text, normalized, target):
    compact_raw = re.sub(r"\s+", "", normalize_pdf_math_text(formula_text or ""))
    compact_norm = re.sub(r"\s+", "", normalized or "")
    simple_call_eq = re.match(
        r"^[A-Za-z][A-Za-z0-9_]*=[A-Za-z][A-Za-z0-9_]*\([A-Za-z][A-Za-z0-9_]*\)$",
        compact_raw,
    )
    simple_call_as_product = (
        re.search(r"[A-Za-z][A-Za-z0-9_]*\s*\(", formula_text or "")
        and re.match(
            r"^[A-Za-z][A-Za-z0-9_]*=[A-Za-z][A-Za-z0-9_]*\*+\(?[A-Za-z][A-Za-z0-9_]*\)?$",
            compact_norm,
        )
    )
    if not (simple_call_eq or simple_call_as_product):
        return False
    leaves = leaf_nodes(target)
    if len(leaves) <= 2 and all(is_simple_symbol_node(item) for item in leaves):
        return True
    return False


def looks_like_document_identifier(text):
    compact = re.sub(r"\s+", "", text or "")
    return bool(re.match(
        r"^[A-Z]{1,5}\d?-\d{4}-\d{2,5}(?:\([0-9]{1,2}/[0-9]{1,2}\))?(?:-[A-Z]{1,5})?$",
        compact,
    ))


def looks_like_bibliographic_noise(text):
    text = " ".join((text or "").split())
    if not text:
        return False
    lowered = text.lower()
    reference_markers = [
        "doi", "ieee", "trans ", "journal", "bioinformatics", "nature",
        "cell.", "commun.", "comput sci", "article", "proceedings",
        "conference", "mag.", "pp.", "arxiv", "springer",
    ]
    if re.search(r"\b10\.\d{4,9}/", lowered):
        return True
    if any(marker in lowered for marker in reference_markers):
        return True
    if re.search(r"\b(19|20)\d{2};\d+|\b(19|20)\d{2};\d+\(\d+\):\d+", text):
        return True
    comma_count = text.count(",")
    name_like = len(re.findall(r"\b[A-Z][a-z]{1,20}\s+[A-Z]{1,3}\b", text))
    has_relation = bool(re.search(r"[=<>]", text))
    if comma_count >= 2 and name_like >= 2 and not has_relation:
        return True
    return False


def looks_like_labeled_table_value_noise(text):
    text = " ".join((text or "").split())
    if not text or "," not in text:
        return False
    if re.match(r"^[A-Za-z][A-Za-z ]{2,30},\s*[A-Za-z0-9_/^+\-*.()= ]{3,40}$", text):
        prefix = text.split(",", 1)[0]
        if len(symbol_tokens_from_text(prefix)) >= 1 and count_math_ops(prefix) == 0:
            return True
    return False


def looks_like_prose_wrapped_formula(text):
    text = " ".join((text or "").split())
    if not text:
        return False
    if re.match(r"^(hence|then|given|definition|result|which|where|therefore|let)\b", text, re.I):
        return True
    if re.match(r"^[A-Za-z]{4,}(?:\s+[A-Za-z]{4,}){1,4},\s*", text):
        return True
    return False


def assess_core_validity(row, normalized, target, pattern_result, diagnostics=None):
    method = row.get("extraction_method", "")
    formula_text = row.get("formula_latex", "") or ""
    raw_text = row.get("raw_text", "") or formula_text
    combined_text = " ".join([formula_text, raw_text, row.get("context_before", ""), row.get("context_after", "")])

    try:
        confidence = float(row.get("confidence", "") or 0)
    except ValueError:
        confidence = 0

    if row.get("image_screen_status") in {"non_formula_image", "rejected_non_formula"}:
        return "excluded_from_core_stats", "non_formula_image"

    ocr_quality = row.get("ocr_quality_status", "")
    if ocr_quality and ocr_quality != "passed":
        return "excluded_from_core_stats", "ocr_quality_" + ocr_quality

    if diagnostics is not None:
        if diagnostics.ambiguous_symbolic_calls:
            return "excluded_from_core_stats", "ambiguous_symbolic_call"
        if diagnostics.parse_mode == "lossy_heuristic":
            return "excluded_from_core_stats", "lossy_heuristic_parse"
        if diagnostics.tree_fidelity_status == "failed":
            return "excluded_from_core_stats", "tree_fidelity_failed"
        if diagnostics.tree_fidelity_status == "unsupported":
            return "excluded_from_core_stats", "valid_but_parser_unsupported"
        if diagnostics.raw_expression_count != diagnostics.parsed_expression_count:
            return "excluded_from_core_stats", "expression_count_mismatch"
        if diagnostics.repaired_delimiter_count > 0:
            return "excluded_from_core_stats", "repaired_delimiter_structure"
        if diagnostics.dropped_semantic_commands:
            return "excluded_from_core_stats", "dropped_semantic_commands"
        if diagnostics.semantic_coverage < 0.75:
            return "excluded_from_core_stats", "low_semantic_coverage"

    if row.get("image_screen_status") == "formula_candidate_strict":
        has_relation = bool(re.search(r"=|\\equiv|\\approx|\\le|\\ge|\\propto|\\sim", formula_text))
        has_strong_math_command = bool(re.search(
            r"\\(?:frac|sqrt|sum|prod|int|log|ln|exp|sin|cos|tan)\b",
            formula_text,
        ))
        raw_binary_operator_count = len(re.findall(r"[+\-*/]", formula_text))
        clear_short_algebra = bool(re.fullmatch(
            r"[A-Za-z](?:_[A-Za-z0-9]+)?[+\-*/][A-Za-z](?:_[A-Za-z0-9]+)?",
            normalized,
        ))
        if (
            not has_relation
            and not has_strong_math_command
            and raw_binary_operator_count <= 1
            and not clear_short_algebra
        ):
            return "excluded_from_core_stats", "insufficient_formula_signal_strict_candidate"

    if is_trivial_function_placeholder(formula_text, normalized, target):
        return "excluded_from_core_stats", "trivial_function_placeholder"

    if is_trivial_function_call_or_evaluation(target):
        return "excluded_from_core_stats", "trivial_function_call_or_evaluation"

    if has_unresolved_ocr_layout(formula_text, target):
        return "excluded_from_core_stats", "ocr_layout_or_multiline_unresolved"

    if has_insufficient_decomposition_signal(formula_text, target):
        return "excluded_from_core_stats", "insufficient_decomposition_signal"

    if not pattern_result["formula_level_tags"]:
        return "excluded_from_core_stats", "unsupported_expression"

    if method in PDF_TEXT_EXTRACTION_METHODS and confidence and confidence < 0.70:
        return "excluded_from_core_stats", "low_confidence_extraction"

    word_tokens = symbol_tokens_from_text(combined_text)
    noise_words = [token for token in word_tokens if token in TEXT_NOISE_WORDS]
    variable_tokens = [token for token in word_tokens if len(token) <= 3 or "_" in token]
    raw_word_count = len(symbol_tokens_from_text(raw_text))
    normalized_noise_words = [
        token for token in symbol_tokens_from_text(normalized)
        if token in TEXT_NOISE_WORDS
    ]
    clean_inline_candidate = (
        method in PDF_TEXT_EXTRACTION_METHODS
        and len(normalized) <= 120
        and math_signal_score(normalized) >= 2
        and uses_inline_formula_candidate(formula_text, normalized)
    )

    if method in PDF_TEXT_EXTRACTION_METHODS:
        if looks_like_document_identifier(formula_text):
            return "excluded_from_core_stats", "document_identifier_or_code"
        if looks_like_bibliographic_noise(formula_text) or looks_like_bibliographic_noise(raw_text):
            return "excluded_from_core_stats", "bibliographic_or_reference_noise"
        if looks_like_labeled_table_value_noise(formula_text):
            return "excluded_from_core_stats", "table_label_or_caption_value"
        if not clean_inline_candidate and looks_like_prose_wrapped_formula(formula_text):
            return "excluded_from_core_stats", "prose_wrapped_non_formula"
        if normalized_noise_words:
            return "excluded_from_core_stats", "text_noise_or_non_formula"
        if (
            not clean_inline_candidate
            and re.search(r"\band\b", raw_text, re.IGNORECASE)
            and raw_text.count("=") > 1
        ):
            return "excluded_from_core_stats", "text_noise_or_non_formula"
        if not clean_inline_candidate and len(formula_text) > 180 and raw_word_count > 12:
            return "excluded_from_core_stats", "text_noise_or_non_formula"
        if not clean_inline_candidate and len(noise_words) >= 5 and len(noise_words) > len(variable_tokens):
            return "excluded_from_core_stats", "text_noise_or_non_formula"
        signal_text = normalized if clean_inline_candidate else formula_text
        if math_signal_score(signal_text) < 2 and target.kind != "func":
            return "excluded_from_core_stats", "unsupported_expression"

    if target.kind == "symbol" and len(str(target.value)) > 3:
        return "excluded_from_core_stats", "text_noise_or_non_formula"

    return "valid_for_core_stats", ""


def determine_record_status(row, validity_status, exclude_reason, diagnostics):
    if row.get("image_screen_status") in {"non_formula_image", "rejected_non_formula"}:
        return "rejected_non_formula"
    if row.get("ocr_quality_status") and row.get("ocr_quality_status") != "passed":
        return "ocr_quality_suspicious"
    if diagnostics.tree_fidelity_status == "failed":
        return "parse_structure_suspicious"
    if diagnostics.tree_fidelity_status == "unsupported" or exclude_reason == "valid_but_parser_unsupported":
        return "valid_but_unsupported"
    if exclude_reason == "ambiguous_symbolic_call":
        return "ambiguous_symbolic_call"
    if validity_status == "valid_for_core_stats":
        return "valid_for_core_stats"
    if exclude_reason == "parse_failed":
        return "parse_structure_suspicious"
    return "valid_no_target_pattern"


def formula_text_prefilter_passes(text, mode="parseable"):
    row = {
        "extraction_method": "prefilter_candidate",
        "formula_latex": text,
        "raw_text": text,
        "confidence": "0.80",
    }
    keep, _status, _reason = evaluate_formula_row_prefilter(row, mode)
    return keep


def evaluate_formula_row_prefilter(row, mode):
    if mode in ("", "off"):
        return True, "not_applied", ""
    try:
        normalized, tree = parse_formula(row.get("formula_latex", ""))
        target, _legacy_tags, pattern_result = classify(tree)
        validity_status, exclude_reason = assess_core_validity(row, normalized, target, pattern_result)
    except Exception as exc:
        return False, "parse_failed", str(exc)

    if mode == "parseable":
        return True, "parseable", ""
    if mode == "core":
        if validity_status == "valid_for_core_stats":
            return True, "valid_core", ""
        return False, validity_status, exclude_reason or "not_in_core_patterns"
    raise ValueError("unknown prefilter mode: %s" % mode)


def rejected_formula_diagnostics(row):
    try:
        normalized, tree = parse_formula(row.get("formula_latex", ""))
        target, _legacy_tags, pattern_result = classify(tree)
        return normalized, "; ".join(pattern_result["formula_level_tags"])
    except Exception:
        return "", ""


def prefilter_extracted_formula_rows(rows, mode):
    if mode in ("", "off"):
        return rows, []
    kept = []
    rejected = []
    seen = set()
    for row in rows:
        normalized_key = " ".join((row.get("formula_latex", "") or "").split())
        unique_key = (
            row.get("source_id", ""),
            row.get("page", ""),
            row.get("locator", ""),
            normalized_key,
        )
        if unique_key in seen:
            continue
        seen.add(unique_key)
        keep, status, reason = evaluate_formula_row_prefilter(row, mode)
        if keep:
            row["note"] = (row.get("note", "") + "; extraction_prefilter=%s" % status).strip("; ")
            kept.append(row)
        else:
            normalized, candidate_tags = rejected_formula_diagnostics(row)
            rejected.append({
                "source_id": row.get("source_id", ""),
                "locator": row.get("locator", ""),
                "extraction_method": row.get("extraction_method", ""),
                "prefilter_status": status,
                "prefilter_reason": reason,
                "normalized_formula": normalized,
                "candidate_formula_level_tags": candidate_tags,
                "formula_latex": row.get("formula_latex", ""),
                "raw_text": row.get("raw_text", ""),
            })
    return kept, rejected


def legacy_classify(target):
    tags = []
    root = target.value

    if root in ("+", "-"):
        tags.append("root_additive")
        tags.append("ai_feynman_additive_separability")
    if root in ("*", "/"):
        tags.append("root_multiplicative")
        tags.append("ai_feynman_multiplicative_separability")
    if root in ("+", "-") and child_has_op(target, {"*", "/"}):
        tags.append("layer_add_then_mul")
    if root in ("*", "/") and child_has_op(target, {"+", "-"}):
        tags.append("layer_mul_then_add")
    if target.contains_value({"log", "ln"}):
        tags.append("log_nested_or_identity")
    if target.contains_value({"exp"}):
        tags.append("exp_nested")
    if target.contains_value({"sin"}):
        tags.append("sin_nested")
    if target.contains_value({"^"}):
        tags.append("power_form")
    if root in ("+", "-"):
        product_child = any(direct_product_like(child) for child in target.children)
        if product_child and has_numeric_leaf(target):
            tags.append("product_with_constant_or_coefficient")
    if target.kind == "func":
        tags.append("ai_feynman_compositionality")
        if target.children and target.children[0].value in ("+", "-"):
            tags.append("ai_feynman_generalized_additivity")
        if target.children and target.children[0].value in ("+", "-", "*", "/"):
            tags.append("ai_feynman_generalized_symmetry")
    elif target.contains_kind("func"):
        tags.append("ai_feynman_compositionality")
    if has_simple_symmetry(target):
        tags.append("ai_feynman_simple_symmetry")
        tags.append("ai_feynman_generalized_symmetry")

    if not tags:
        tags.append("unclassified_or_atomic")
    return sorted(set(tags))


def classify(tree):
    if tree.kind == "relation_chain":
        targets = list(tree.children)
    elif tree.kind == "expression_bundle":
        targets = []
        for expression in tree.children:
            if expression.kind == "relation_chain":
                targets.extend(expression.children)
            elif expression.kind == "relation":
                targets.extend(expression.children)
            else:
                targets.append(expression)
    elif tree.kind == "relation":
        targets = list(tree.children)
    else:
        targets = [tree]
    target = max(targets, key=complexity)
    legacy_tags = sorted({tag for item in targets for tag in legacy_classify(item)})
    occurrence_counts = Counter()
    for item in targets:
        occurrence_counts.update(match_pattern_templates(item)["pattern_occurrence_counts"])
    formula_level_tags = [
        PATTERN_BY_CODE[code]["tag"] for code in sorted(occurrence_counts)
        if occurrence_counts[code] > 0
    ]
    pattern_result = {
        "formula_level_tags": formula_level_tags,
        "pattern_occurrence_counts": dict(sorted(occurrence_counts.items())),
        "matched_templates": [
            "%s. %s" % (code, PATTERN_BY_CODE[code]["name"])
            for code in sorted(occurrence_counts) if occurrence_counts[code] > 0
        ],
    }
    return target, legacy_tags, pattern_result


def top_signature(node, levels=3):
    values = []

    def walk(n, depth):
        if depth > levels:
            return
        values.append(n.value)
        for child in n.children:
            walk(child, depth + 1)

    walk(node, 1)
    return " ".join(values)


def compact_formula_similarity_key(text):
    text = text or ""
    text = re.sub(r"\s+", "", text)
    text = re.sub(r"[^A-Za-z0-9_+=+\-*/^().,]", "", text)
    return text.lower()


def mark_duplicate_or_near_duplicate_results(results, threshold=0.96):
    """Keep candidate rows, but remove repeated formulas from core statistics."""
    seen_by_source = defaultdict(list)
    for row in results:
        if row.get("validity_status") != "valid_for_core_stats":
            continue
        source_id = row.get("source_id", "")
        key = compact_formula_similarity_key(row.get("normalized", "") or row.get("formula_latex", ""))
        if not key:
            continue
        duplicate_of = ""
        duplicate_kind = ""
        for previous_key, previous_id in seen_by_source[source_id]:
            if key == previous_key:
                duplicate_of = previous_id
                duplicate_kind = "exact"
                break
            if min(len(key), len(previous_key)) >= 8:
                ratio = difflib.SequenceMatcher(None, key, previous_key).ratio()
                if ratio >= threshold:
                    duplicate_of = previous_id
                    duplicate_kind = "near"
                    break
        if duplicate_of:
            row["validity_status"] = "excluded_from_core_stats"
            row["exclude_reason"] = "duplicate_or_near_duplicate_formula"
            row["record_status"] = "valid_no_target_pattern"
            row["final_status"] = "valid_no_target_pattern"
            row["core_eligibility"] = False
            row["quality_reasons"] = sorted(set(
                list(row.get("quality_reasons", [])) + ["duplicate_or_near_duplicate_formula"]
            ))
            row["tags"] = []
            row["pattern_occurrence_counts"] = {}
            row["matched_templates"] = []
            row["note"] = (row.get("note", "") + "; dedup=%s:%s" % (duplicate_kind, duplicate_of)).strip("; ")
        else:
            seen_by_source[source_id].append((key, row.get("formula_id", "")))
    return results


def process_formulas(rows):
    results = []
    tag_counts = Counter()
    source_counts = defaultdict(Counter)
    failures = []

    for row in rows:
        try:
            normalized, tree, diagnostics = parse_formula_with_ocr_fallback(row["formula_latex"])
            target, legacy_tags, pattern_result = classify(tree)
            validity_status, exclude_reason = assess_core_validity(
                row, normalized, target, pattern_result, diagnostics,
            )
            record_status = determine_record_status(
                row, validity_status, exclude_reason, diagnostics,
            )
            quality_reasons = list(diagnostics.tree_fidelity_reasons)
            if exclude_reason:
                quality_reasons.append(exclude_reason)
            upstream_ocr_reasons = row.get("ocr_quality_reasons", [])
            if isinstance(upstream_ocr_reasons, str):
                upstream_ocr_reasons = [item for item in re.split(r"[;,]", upstream_ocr_reasons) if item]
            quality_reasons.extend(upstream_ocr_reasons)
            expression_nodes = tree.children if tree.kind == "expression_bundle" else [tree]
            expression_records = [
                {
                    "expression_id": "%s_E%03d" % (row.get("formula_id", ""), index),
                    "tree_preorder": expression.preorder(),
                }
                for index, expression in enumerate(expression_nodes, start=1)
            ]
            candidate_formula_level_tags = pattern_result["formula_level_tags"]
            candidate_occurrence_counts = pattern_result["pattern_occurrence_counts"]
            if validity_status == "valid_for_core_stats":
                formula_level_tags = candidate_formula_level_tags
                occurrence_counts = candidate_occurrence_counts
            else:
                formula_level_tags = []
                occurrence_counts = {}
            for tag in formula_level_tags:
                tag_counts[tag] += 1
                source_counts[row["source_id"]][tag] += 1
            features = structure_features(target, pattern_result)
            results.append({
                "formula_id": row.get("formula_id", ""),
                "source_id": row["source_id"],
                "source_title": row.get("source_title", ""),
                "chapter": row.get("chapter", ""),
                "section": row.get("section", ""),
                "page": row.get("page", ""),
                "equation_number": row.get("equation_number", ""),
                "locator": row.get("locator", ""),
                "extraction_method": row.get("extraction_method", ""),
                "formula_latex": row["formula_latex"],
                "raw_text": row.get("raw_text", ""),
                "context_before": row.get("context_before", ""),
                "context_after": row.get("context_after", ""),
                "screenshot_path": row.get("screenshot_path", ""),
                "bbox": row.get("bbox", ""),
                "source_file": row.get("source_file", ""),
                "confidence": row.get("confidence", ""),
                "needs_review": row.get("needs_review", ""),
                "image_screen_status": row.get("image_screen_status", ""),
                "image_screen_reason": row.get("image_screen_reason", ""),
                "image_screen_metrics": row.get("image_screen_metrics", ""),
                "upstream_formula_label": row.get("upstream_formula_label", ""),
                "upstream_formula_score_raw": row.get("upstream_formula_score_raw", ""),
                "ocr_generated_status": row.get("ocr_generated_status", ""),
                "ocr_quality_status": row.get("ocr_quality_status", ""),
                "ocr_quality_reasons": row.get("ocr_quality_reasons", ""),
                "ocr_variant_latex": row.get("ocr_variant_latex", ""),
                "ocr_variant_similarity": row.get("ocr_variant_similarity", ""),
                "normalized": normalized,
                "tree_preorder": tree.preorder(),
                "analysis_target_preorder": target.preorder(),
                "validity_status": validity_status,
                "exclude_reason": exclude_reason,
                "record_status": record_status,
                "final_status": record_status,
                "image_formula_status": row.get("image_screen_status", "not_checked"),
                "ocr_semantic_status": row.get("ocr_quality_status", "not_checked"),
                "parser_support_status": "supported" if diagnostics.tree_fidelity_status == "passed" else diagnostics.tree_fidelity_status,
                "tree_fidelity_status": diagnostics.tree_fidelity_status,
                "core_eligibility": validity_status == "valid_for_core_stats",
                "quality_reasons": sorted(set(quality_reasons)),
                **features,
                "depth": tree.depth(),
                "top_signature": top_signature(target),
                "tags": formula_level_tags,
                "legacy_tags": legacy_tags,
                "pattern_occurrence_counts": occurrence_counts,
                "matched_templates": pattern_result["matched_templates"] if validity_status == "valid_for_core_stats" else [],
                "candidate_formula_level_tags": candidate_formula_level_tags,
                "candidate_pattern_occurrence_counts": candidate_occurrence_counts,
                "parse_mode": diagnostics.parse_mode,
                "semantic_coverage": diagnostics.semantic_coverage,
                "normalization_semantic_coverage": diagnostics.normalization_semantic_coverage,
                "raw_structure_signature": diagnostics.raw_structure_signature,
                "tree_structure_signature": diagnostics.tree_structure_signature,
                "tree_fidelity_reasons": diagnostics.tree_fidelity_reasons,
                "raw_expression_count": diagnostics.raw_expression_count,
                "parsed_expression_count": diagnostics.parsed_expression_count,
                "discarded_expression_spans": diagnostics.discarded_expression_spans,
                "segmentation_status": diagnostics.segmentation_status,
                "ambiguous_symbolic_calls": diagnostics.ambiguous_symbolic_calls,
                "main_expression_latex": diagnostics.main_expression_latex,
                "condition_spans": diagnostics.condition_spans,
                "condition_connector": diagnostics.condition_connector,
                "expression_records": expression_records,
                "latex_command_registry_version": REGISTRY_VERSION,
                "dropped_semantic_commands": diagnostics.dropped_semantic_commands,
                "repaired_delimiter_count": diagnostics.repaired_delimiter_count,
                "raw_math_token_count": diagnostics.raw_math_token_count,
                "normalized_math_token_count": diagnostics.normalized_math_token_count,
                "note": (row.get("note", "") + ("; parse_mode=" + diagnostics.parse_mode if diagnostics.parse_mode != "standard" else "")).strip("; "),
            })
        except Exception as exc:
            failures.append({
                "formula_id": row.get("formula_id", ""),
                "source_id": row.get("source_id", ""),
                "locator": row.get("locator", ""),
                "extraction_method": row.get("extraction_method", ""),
                "formula_latex": row.get("formula_latex", ""),
                "raw_text": row.get("raw_text", ""),
                "error": str(exc),
            })

    results = mark_duplicate_or_near_duplicate_results(results)
    tag_counts = Counter()
    source_counts = defaultdict(Counter)
    for result in results:
        if result.get("validity_status") != "valid_for_core_stats":
            continue
        for tag in result.get("tags", []):
            tag_counts[tag] += 1
            source_counts[result.get("source_id", "")][tag] += 1

    return results, tag_counts, source_counts, failures


def apply_parse_results_to_formula_rows(formula_rows, results, failures):
    result_by_id = {row.get("formula_id", ""): row for row in results}
    failure_by_id = {row.get("formula_id", ""): row for row in failures}
    for row in formula_rows:
        formula_id = row.get("formula_id", "")
        if not row.get("formula_latex", "").strip():
            row["parse_status"] = "skipped_empty"
            row["parse_error"] = ""
            row["validity_status"] = "excluded_from_core_stats"
            row["exclude_reason"] = "skipped_empty"
            row["normalized_formula"] = ""
            row["formula_tree_prefix"] = ""
            row["analysis_target_prefix"] = ""
            row["root_operator"] = ""
            row["root_pattern"] = ""
            row["layer_pattern"] = ""
            row["function_nodes"] = ""
            row["has_constant_or_coefficient"] = ""
            row["variable_sets"] = ""
            row["variable_overlap_status"] = ""
            row["tree_depth"] = ""
            row["top_signature"] = ""
            row["subtree_pattern_tags"] = ""
            row["operator_path_signatures"] = ""
            row["nested_function_patterns"] = ""
            row["pattern_tags"] = ""
            row["formula_level_tags"] = ""
            row["pattern_occurrence_counts"] = ""
            row["matched_pattern_templates"] = ""
            row["candidate_formula_level_tags"] = ""
            row["candidate_pattern_occurrence_counts"] = ""
        elif formula_id in result_by_id:
            result = result_by_id[formula_id]
            row["parse_status"] = "ok"
            row["parse_error"] = ""
            row["validity_status"] = result.get("validity_status", "")
            row["exclude_reason"] = result.get("exclude_reason", "")
            row["normalized_formula"] = result.get("normalized", "")
            row["formula_tree_prefix"] = result.get("tree_preorder", "")
            row["analysis_target_prefix"] = result.get("analysis_target_preorder", "")
            row["root_operator"] = result.get("root_operator", "")
            row["root_pattern"] = result.get("root_pattern", "")
            row["layer_pattern"] = result.get("layer_pattern", "")
            row["function_nodes"] = result.get("function_nodes", "")
            row["has_constant_or_coefficient"] = result.get("has_constant_or_coefficient", "")
            row["variable_sets"] = result.get("variable_sets", "")
            row["variable_overlap_status"] = result.get("variable_overlap_status", "")
            row["tree_depth"] = str(result.get("depth", ""))
            row["top_signature"] = result.get("top_signature", "")
            row["subtree_pattern_tags"] = result.get("subtree_pattern_tags", "")
            row["operator_path_signatures"] = result.get("operator_path_signatures", "")
            row["nested_function_patterns"] = result.get("nested_function_patterns", "")
            row["pattern_tags"] = "; ".join(result.get("legacy_tags", []))
            row["formula_level_tags"] = "; ".join(result.get("tags", []))
            row["pattern_occurrence_counts"] = json.dumps(
                result.get("pattern_occurrence_counts", {}),
                ensure_ascii=False,
                sort_keys=True,
            )
            row["matched_pattern_templates"] = "; ".join(result.get("matched_templates", []))
            row["candidate_formula_level_tags"] = "; ".join(result.get("candidate_formula_level_tags", []))
            row["candidate_pattern_occurrence_counts"] = json.dumps(
                result.get("candidate_pattern_occurrence_counts", {}),
                ensure_ascii=False,
                sort_keys=True,
            )
        elif formula_id in failure_by_id:
            row["parse_status"] = "failed"
            row["parse_error"] = failure_by_id[formula_id].get("error", "")
            row["validity_status"] = "excluded_from_core_stats"
            row["exclude_reason"] = "parse_failed"
            row["normalized_formula"] = ""
            row["formula_tree_prefix"] = ""
            row["analysis_target_prefix"] = ""
            row["root_operator"] = ""
            row["root_pattern"] = ""
            row["layer_pattern"] = ""
            row["function_nodes"] = ""
            row["has_constant_or_coefficient"] = ""
            row["variable_sets"] = ""
            row["variable_overlap_status"] = ""
            row["tree_depth"] = ""
            row["top_signature"] = ""
            row["subtree_pattern_tags"] = ""
            row["operator_path_signatures"] = ""
            row["nested_function_patterns"] = ""
            row["pattern_tags"] = ""
            row["formula_level_tags"] = ""
            row["pattern_occurrence_counts"] = ""
            row["matched_pattern_templates"] = ""
            row["candidate_formula_level_tags"] = ""
            row["candidate_pattern_occurrence_counts"] = ""
    return formula_rows


DISPLAY_ENV_RE = re.compile(
    r"\\begin\{(equation\*?|align\*?|gather\*?)\}(.*?)\\end\{\1\}"
    r"|\\\[(.*?)\\\]"
    r"|\$\$(.*?)\$\$",
    re.DOTALL,
)


def clean_extracted_equation(text):
    text = re.sub(r"\\label\{[^{}]*\}", "", text)
    text = re.sub(r"\\tag\{[^{}]*\}", "", text)
    text = text.replace("&", "")
    text = text.replace("\\\\", " ")
    return " ".join(text.split())


def fetch_arxiv_source(arxiv_id, max_formulas=8):
    """Fetch arXiv TeX source and return parseable display-equation rows.

    Raw PDF to LaTeX extraction generally requires OCR or commercial APIs.
    For arXiv PDFs, the TeX source is the most reproducible extractor and still
    points back to the same PDF literature item.
    """
    url = "https://arxiv.org/e-print/%s" % arxiv_id
    with urllib.request.urlopen(url, timeout=60) as response:
        payload = response.read()

    rows = []
    try:
        archive = tarfile.open(fileobj=io.BytesIO(payload), mode="r:*")
        members = [m for m in archive.getmembers() if m.isfile() and m.name.endswith(".tex")]
        for member in members:
            data = archive.extractfile(member).read().decode("utf-8", errors="ignore")
            rows.extend(extract_equation_rows(arxiv_id, member.name, data, max_formulas - len(rows)))
            if len(rows) >= max_formulas:
                break
        archive.close()
    except tarfile.TarError:
        data = payload.decode("utf-8", errors="ignore")
        rows.extend(extract_equation_rows(arxiv_id, "source.tex", data, max_formulas))
    return rows[:max_formulas]


def extract_equation_rows(arxiv_id, tex_name, data, remaining):
    rows = []
    for idx, match in enumerate(DISPLAY_ENV_RE.finditer(data), start=1):
        raw = next(group for group in match.groups()[1:] if group)
        formula = clean_extracted_equation(raw)
        if not formula or len(formula) > 220:
            continue
        try:
            parse_formula(formula)
        except Exception:
            continue
        rows.append({
            "formula_id": "A%s_%03d" % (arxiv_id.replace(".", ""), idx),
            "source_id": "arxiv:%s" % arxiv_id,
            "locator": "%s display-equation %d" % (tex_name, idx),
            "formula_latex": formula,
            "note": "Auto-extracted from arXiv TeX source.",
        })
        if len(rows) >= remaining:
            break
    return rows


def ensure_dir(path):
    if not os.path.isdir(path):
        os.makedirs(path)


def build_source_route_outputs(sources, results, valid_results, excluded_results, failures):
    source_lookup = {row.get("source_id", ""): row for row in sources}
    plan_rows = [source_processing_plan_row(row) for row in sources]

    parsed_by_source = Counter(row.get("source_id", "") for row in results)
    valid_by_source = Counter(row.get("source_id", "") for row in valid_results)
    excluded_by_source = Counter(row.get("source_id", "") for row in excluded_results)
    failure_by_source = Counter(row.get("source_id", "") for row in failures)

    grouped = {}
    for source in sources:
        route = classify_source_processing(source)
        key = (
            route.get("priority", ""),
            route.get("source_kind", ""),
            route.get("preferred_channel", ""),
        )
        if key not in grouped:
            grouped[key] = Counter()
        source_id = source.get("source_id", "")
        grouped[key]["source_count"] += 1
        grouped[key]["parsed_formula_count"] += parsed_by_source[source_id]
        grouped[key]["valid_core_formula_count"] += valid_by_source[source_id]
        grouped[key]["excluded_parsed_formula_count"] += excluded_by_source[source_id]
        grouped[key]["parse_failure_count"] += failure_by_source[source_id]

    # If formula rows reference sources not present in the source table, keep
    # the counts visible instead of silently dropping them.
    referenced_source_ids = (
        set(parsed_by_source)
        | set(valid_by_source)
        | set(excluded_by_source)
        | set(failure_by_source)
    )
    for source_id in referenced_source_ids:
        if source_id in source_lookup or not source_id:
            continue
        key = ("unknown", "missing_source_metadata", "unknown")
        if key not in grouped:
            grouped[key] = Counter()
        grouped[key]["source_count"] += 1
        grouped[key]["parsed_formula_count"] += parsed_by_source[source_id]
        grouped[key]["valid_core_formula_count"] += valid_by_source[source_id]
        grouped[key]["excluded_parsed_formula_count"] += excluded_by_source[source_id]
        grouped[key]["parse_failure_count"] += failure_by_source[source_id]

    summary_rows = []
    for key, counts in sorted(grouped.items()):
        priority, source_kind, preferred_channel = key
        summary_rows.append({
            "priority": priority,
            "source_kind": source_kind,
            "preferred_channel": preferred_channel,
            "source_count": counts["source_count"],
            "parsed_formula_count": counts["parsed_formula_count"],
            "valid_core_formula_count": counts["valid_core_formula_count"],
            "excluded_parsed_formula_count": counts["excluded_parsed_formula_count"],
            "parse_failure_count": counts["parse_failure_count"],
        })
    return plan_rows, summary_rows


def write_outputs(out_dir, sources, results, tag_counts, source_counts, failures):
    ensure_dir(out_dir)
    valid_results = [row for row in results if row.get("validity_status") == "valid_for_core_stats"]
    excluded_results = [row for row in results if row.get("validity_status") != "valid_for_core_stats"]

    with open(os.path.join(out_dir, "formula_trees.jsonl"), "w", encoding="utf-8") as f:
        for row in results:
            f.write(json.dumps(row, ensure_ascii=False) + "\n")

    count_rows = [{"tag": tag, "count": count} for tag, count in tag_counts.most_common()]
    write_csv(os.path.join(out_dir, "pattern_counts.csv"), ["tag", "count"], count_rows)

    legacy_counts = Counter()
    for row in results:
        for tag in row.get("legacy_tags", []):
            legacy_counts[tag] += 1
    legacy_count_rows = [{"tag": tag, "count": count} for tag, count in legacy_counts.most_common()]
    write_csv(os.path.join(out_dir, "legacy_pattern_counts.csv"), ["tag", "count"], legacy_count_rows)

    template_rows = [
        {
            "code": item["code"],
            "tag": item["tag"],
            "name": item["name"],
            "rule": item["rule"],
        }
        for item in PATTERN_TEMPLATES
    ]
    write_csv(
        os.path.join(out_dir, "pattern_template_catalog.csv"),
        ["code", "tag", "name", "rule"],
        template_rows,
    )

    source_lookup = {row["source_id"]: row for row in sources}
    source_rows = []
    by_source_formula_count = Counter(row["source_id"] for row in results)
    by_source_valid_count = Counter(row["source_id"] for row in valid_results)
    by_source_excluded_count = Counter(row["source_id"] for row in excluded_results)
    for source_id, count in sorted(by_source_formula_count.items()):
        source = source_lookup.get(source_id, {"title": source_id, "type": "unknown"})
        source_rows.append({
            "source_id": source_id,
            "type": source.get("type", ""),
            "title": source.get("title", ""),
            "parsed_formula_count": count,
            "valid_core_formula_count": by_source_valid_count[source_id],
            "excluded_parsed_formula_count": by_source_excluded_count[source_id],
            "top_tags": "; ".join("%s=%s" % item for item in source_counts[source_id].most_common(5)),
        })
    write_csv(
        os.path.join(out_dir, "source_formula_summary.csv"),
        ["source_id", "type", "title", "parsed_formula_count", "valid_core_formula_count", "excluded_parsed_formula_count", "top_tags"],
        source_rows,
    )

    if failures:
        write_csv(
            os.path.join(out_dir, "parse_failures.csv"),
            ["formula_id", "source_id", "locator", "extraction_method", "formula_latex", "raw_text", "error"],
            failures,
        )

    excluded_rows = [
        {
            "formula_id": row.get("formula_id", ""),
            "source_id": row.get("source_id", ""),
            "locator": row.get("locator", ""),
            "extraction_method": row.get("extraction_method", ""),
            "parse_status": "ok",
            "validity_status": row.get("validity_status", ""),
            "exclude_reason": row.get("exclude_reason", ""),
            "formula_latex": row.get("formula_latex", ""),
            "raw_text": row.get("raw_text", ""),
        }
        for row in excluded_results
    ]
    excluded_rows.extend({
        "formula_id": row.get("formula_id", ""),
        "source_id": row.get("source_id", ""),
        "locator": row.get("locator", ""),
        "extraction_method": row.get("extraction_method", ""),
        "parse_status": "failed",
        "validity_status": "excluded_from_core_stats",
        "exclude_reason": "parse_failed",
        "formula_latex": row.get("formula_latex", ""),
        "raw_text": row.get("raw_text", ""),
    } for row in failures)
    write_csv(
        os.path.join(out_dir, "excluded_formula_summary.csv"),
        ["formula_id", "source_id", "locator", "extraction_method", "parse_status", "validity_status", "exclude_reason", "formula_latex", "raw_text"],
        excluded_rows,
    )

    def result_has(row, prefix):
        return any(tag.startswith(prefix) for tag in row.get("tags", []))

    derived_rows = [
        {"summary": "valid_core_formula_count", "count": len(valid_results)},
        {"summary": "additive_total_M01_or_M03", "count": sum(1 for row in valid_results if result_has(row, "M01_") or result_has(row, "M03_"))},
        {"summary": "multiplicative_total_M02_or_M04_or_M05", "count": sum(1 for row in valid_results if result_has(row, "M02_") or result_has(row, "M04_") or result_has(row, "M05_"))},
        {"summary": "compositionality_total_M06", "count": sum(1 for row in valid_results if result_has(row, "M06_"))},
        {"summary": "symmetry_total_M11", "count": sum(1 for row in valid_results if result_has(row, "M11_"))},
        {"summary": "simple_symmetry_total_M12", "count": sum(1 for row in valid_results if result_has(row, "M12_"))},
        {"summary": "generalized_symmetry_non_simple", "count": sum(1 for row in valid_results if result_has(row, "M11_") and not result_has(row, "M12_"))},
    ]
    write_csv(os.path.join(out_dir, "derived_summary_counts.csv"), ["summary", "count"], derived_rows)

    method_rows = []
    method_counts = Counter(row.get("extraction_method", "") for row in results)
    method_valid_counts = Counter(row.get("extraction_method", "") for row in valid_results)
    method_excluded_counts = Counter(row.get("extraction_method", "") for row in excluded_results)
    method_failure_counts = Counter(row.get("extraction_method", "") for row in failures)
    methods = sorted(set(method_counts) | set(method_failure_counts))
    for method in methods:
        method_rows.append({
            "extraction_method": method,
            "parsed_formula_count": method_counts[method],
            "valid_core_formula_count": method_valid_counts[method],
            "excluded_parsed_formula_count": method_excluded_counts[method],
            "parse_failure_count": method_failure_counts[method],
        })
    write_csv(
        os.path.join(out_dir, "extraction_method_summary.csv"),
        ["extraction_method", "parsed_formula_count", "valid_core_formula_count", "excluded_parsed_formula_count", "parse_failure_count"],
        method_rows,
    )

    source_plan_rows, source_route_summary_rows = build_source_route_outputs(
        sources,
        results,
        valid_results,
        excluded_results,
        failures,
    )
    write_csv(
        os.path.join(out_dir, "source_processing_plan.csv"),
        SOURCE_PROCESSING_PLAN_FIELDS,
        source_plan_rows,
    )
    write_csv(
        os.path.join(out_dir, "source_route_summary.csv"),
        SOURCE_ROUTE_SUMMARY_FIELDS,
        source_route_summary_rows,
    )

    report_path = os.path.join(out_dir, "demo_report.md")
    with open(report_path, "w", encoding="utf-8") as f:
        f.write("# Formula Knowledge Base Demo Report\n\n")
        f.write("## Inputs\n\n")
        f.write("- Real literature sources: %d\n" % len(sources))
        f.write("- Parsed formulas: %d\n" % len(results))
        f.write("- Valid core-stat formulas: %d\n" % len(valid_results))
        f.write("- Excluded parsed formulas: %d\n" % len(excluded_results))
        f.write("- Parse failures: %d\n\n" % len(failures))
        f.write("## Extraction Methods\n\n")
        f.write("| method | parsed | valid core | excluded parsed | parse failures |\n|---|---:|---:|---:|---:|\n")
        for row in method_rows:
            f.write("| %s | %s | %s | %s | %s |\n" % (
                row["extraction_method"],
                row["parsed_formula_count"],
                row["valid_core_formula_count"],
                row["excluded_parsed_formula_count"],
                row["parse_failure_count"],
            ))
        f.write("\n")
        f.write("## Source Processing Routes\n\n")
        f.write("| priority | source kind | preferred channel | sources | parsed | valid core | excluded parsed | parse failures |\n")
        f.write("|---|---|---|---:|---:|---:|---:|---:|\n")
        for row in source_route_summary_rows:
            f.write("| %s | %s | %s | %s | %s | %s | %s | %s |\n" % (
                row["priority"],
                row["source_kind"],
                row["preferred_channel"],
                row["source_count"],
                row["parsed_formula_count"],
                row["valid_core_formula_count"],
                row["excluded_parsed_formula_count"],
                row["parse_failure_count"],
            ))
        f.write("\n")
        f.write("## Core M01-M12 Pattern Counts\n\n")
        f.write("| pattern tag | count |\n|---|---:|\n")
        for row in count_rows:
            f.write("| %s | %s |\n" % (row["tag"], row["count"]))
        f.write("\n## Derived Summary Counts\n\n")
        f.write("| summary | count |\n|---|---:|\n")
        for row in derived_rows:
            f.write("| %s | %s |\n" % (row["summary"], row["count"]))
        f.write("\n## Legacy Auxiliary Tag Counts\n\n")
        f.write("| auxiliary tag | count |\n|---|---:|\n")
        for row in legacy_count_rows:
            f.write("| %s | %s |\n" % (row["tag"], row["count"]))
        f.write("\n## Example Trees\n\n")
        for row in valid_results[:8]:
            f.write("- `%s` `%s` -> `%s`; formula tags: %s; auxiliary tags: %s\n" % (
                row["formula_id"],
                row["formula_latex"],
                row["tree_preorder"],
                ", ".join(row["tags"]),
                ", ".join(row.get("legacy_tags", [])),
            ))
        f.write("\n## Notes\n\n")
        f.write("- The current parser is a lightweight milestone parser, not a full LaTeX engine.\n")
        f.write("- Core counts now use M01-M12 `formula_level_tags`; legacy auxiliary tags are kept separately for diagnosis.\n")
        f.write("- 第三周教师规则: `M12_simple_symmetry` is also counted as `M11_generalized_symmetry`.\n")
        f.write("- For arXiv PDFs, use `--fetch-arxiv-source` to extract equations from the TeX source linked to the same PDF.\n")
        f.write("- For scanned PDFs or PDFs without TeX source, a formula OCR/API layer should be added before this parser.\n")
    return report_path


def main(argv=None):
    parser = argparse.ArgumentParser()
    parser.add_argument("--sources", default="data/literature_sources.csv")
    parser.add_argument("--formulas", default="data/formula_samples.csv")
    parser.add_argument("--out", default="outputs")
    parser.add_argument(
        "--init-from-pdf-dir",
        default="",
        help="Scan a local PDF/TeX folder and generate/update sources and extracted formula CSV files.",
    )
    parser.add_argument(
        "--pdf-recursive",
        action="store_true",
        help="When initializing from PDFs, scan subfolders recursively.",
    )
    parser.add_argument(
        "--template-rows-per-pdf",
        type=int,
        default=0,
        help="Optional blank formula rows generated for each PDF/source during initialization.",
    )
    parser.add_argument(
        "--no-extract-formulas",
        action="store_true",
        help="Only generate source inventory and optional blank rows; do not auto-extract formulas.",
    )
    parser.add_argument(
        "--max-formulas-per-source",
        type=int,
        default=40,
        help="Maximum formulas to auto-extract from each PDF/TeX source.",
    )
    parser.add_argument(
        "--screenshot-dir",
        default="data/formula_screenshots",
        help="Directory for PDF formula-region screenshots. Empty string disables screenshots.",
    )
    parser.add_argument(
        "--use-arxiv-source",
        action="store_true",
        help="When a local PDF has an arXiv id, fetch arXiv TeX source and copy display formulas from it.",
    )
    parser.add_argument(
        "--tiered-source-routing",
        action="store_true",
        help="Route sources by priority: TeX/arXiv first, electronic PDF second, scanned/image OCR third.",
    )
    parser.add_argument(
        "--prefilter-extracted-formulas",
        choices=("off", "parseable", "core"),
        default="off",
        help="Validate extracted candidates before writing formula rows. 'core' keeps only candidates matching M01-M12.",
    )
    parser.add_argument(
        "--metadata-manifest",
        default="",
        help="Optional CSV manifest with curated source metadata to merge into literature_sources.csv.",
    )
    parser.add_argument(
        "--overwrite-init",
        action="store_true",
        help="Rebuild sources/formulas from the PDF folder and discard existing CSV rows.",
    )
    parser.add_argument(
        "--run-after-init",
        action="store_true",
        help="Continue into formula parsing after generating/updating CSV templates.",
    )
    parser.add_argument("--fetch-arxiv-source", nargs="*", default=[])
    parser.add_argument("--max-arxiv-formulas", type=int, default=8)
    args = parser.parse_args(argv)

    if args.init_from_pdf_dir:
        init_summary = init_from_pdf_dir(
            args.init_from_pdf_dir,
            args.sources,
            args.formulas,
            rows_per_pdf=args.template_rows_per_pdf,
            recursive=args.pdf_recursive,
            overwrite=args.overwrite_init,
            extract_formulas=not args.no_extract_formulas,
            max_formulas_per_source=args.max_formulas_per_source,
            screenshot_dir=args.screenshot_dir,
            use_arxiv_source=args.use_arxiv_source,
            metadata_manifest_path=args.metadata_manifest,
            tiered_source_routing=args.tiered_source_routing,
            extraction_prefilter_mode=args.prefilter_extracted_formulas,
        )
        print("document_count=%d pdf_count=%d" % (init_summary["document_count"], init_summary["pdf_count"]))
        print("source_count=%d added_sources=%d updated_sources=%d" % (
            init_summary["source_count"],
            init_summary["added_sources"],
            init_summary["updated_sources"],
        ))
        print("formula_rows=%d extracted_formula_rows=%d added_blank_rows=%d" % (
            init_summary["formula_template_rows"],
            init_summary["extracted_formula_rows"],
            init_summary["added_formula_rows"],
        ))
        print("sources=%s" % init_summary["sources_path"])
        print("formulas=%s" % init_summary["formulas_path"])
        print("fill_guide=%s" % init_summary["guide_path"])
        print("source_processing_plan=%s" % init_summary["source_processing_plan_path"])
        if init_summary["prefilter_rejections_path"]:
            print("prefilter_rejections=%s count=%d" % (
                init_summary["prefilter_rejections_path"],
                init_summary["prefilter_rejection_count"],
            ))
        if not args.run_after_init:
            print("next=review %s, then run this script without --init-from-pdf-dir" % args.formulas)
            return

    sources = [row for row in read_csv(args.sources) if is_data_row(row, "source_id", "来源编号")]
    all_formula_rows = [row for row in read_csv(args.formulas) if is_data_row(row, "formula_id", "公式编号")]
    formula_rows = [row for row in all_formula_rows if row.get("formula_latex", "").strip()]
    skipped_empty = len(all_formula_rows) - len(formula_rows)

    for arxiv_id in args.fetch_arxiv_source:
        formula_rows.extend(fetch_arxiv_source(arxiv_id, args.max_arxiv_formulas))

    results, tag_counts, source_counts, failures = process_formulas(formula_rows)
    apply_parse_results_to_formula_rows(all_formula_rows, results, failures)
    write_csv(args.formulas, FORMULA_FIELDS, all_formula_rows)
    report_path = write_outputs(args.out, sources, results, tag_counts, source_counts, failures)

    print("sources=%d" % len(sources))
    print("formula_rows=%d parsed=%d failures=%d skipped_empty=%d" % (
        len(formula_rows),
        len(results),
        len(failures),
        skipped_empty,
    ))
    print("top_patterns=" + ", ".join("%s:%d" % item for item in tag_counts.most_common(8)))
    print("report=%s" % report_path)
    if failures:
        print("failure_file=%s" % os.path.join(args.out, "parse_failures.csv"))


if __name__ == "__main__":
    main()
