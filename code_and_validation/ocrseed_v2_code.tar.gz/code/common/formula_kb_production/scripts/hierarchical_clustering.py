#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Hierarchical clustering pipeline for formula decomposition patterns.

This script consumes formula_trees.jsonl files produced by the fixed extraction
chain and builds a coarse-to-fine clustering view that finally converges to the
fixed M01-M12 decomposition pattern catalogue.
"""

from __future__ import annotations

import argparse
import csv
import json
import math
import re
from collections import Counter, defaultdict
from pathlib import Path
from typing import Any, Dict, Iterable, List, Tuple


M12_CATALOG = {
    "M01_basic_additive_separable_no_overlap": "基础加法可分离：无变量重合的加法分解",
    "M02_basic_multiplicative_separable_no_overlap": "基础乘法可分离：无变量重合的乘法分解",
    "M03_overlapping_additive": "有变量重合的加法型分解",
    "M04_overlapping_multiplicative": "有变量重合的乘法型分解",
    "M05_product_with_constant": "含常数/系数的乘积型结构",
    "M06_compositionality": "复合函数/嵌套函数结构",
    "M07_log_exp_nested": "log / exp 嵌套特殊分离",
    "M08_sin_nested": "sin 嵌套特殊分离",
    "M09_universal_additive_generalized_additivity": "通用加法分离 U(g+h)",
    "M10_universal_multiplicative": "通用乘法分离 U(g*h)",
    "M11_generalized_symmetry": "广义对称结构",
    "M12_simple_symmetry": "简单对称结构",
}

TAG_ALIASES = {
    # Historical clustering builds used this label while the formula engine
    # has always emitted M08_sin_nested. Normalize both to one canonical tag.
    "M08_nested_separable_sum_product": "M08_sin_nested",
}

DEFAULT_INPUTS = [
    ("mixed_pdf_300", "outputs_300_week4_quality/formula_trees.jsonl"),
    ("nonpreprint_pdf_100", "outputs_nonpreprint_week4_quality_full/formula_trees.jsonl"),
    ("formula_images_23", "outputs_formula_images_23_week5/formula_trees.jsonl"),
]

def safe_text(value: Any) -> str:
    if value is None:
        return ""
    if isinstance(value, str):
        return value
    return json.dumps(value, ensure_ascii=False, sort_keys=True)


def clean_token(value: str, fallback: str = "unknown") -> str:
    value = safe_text(value).strip()
    if not value:
        return fallback
    value = re.sub(r"\s+", "_", value)
    value = re.sub(r"[^0-9A-Za-z_\-\u4e00-\u9fff]+", "_", value)
    value = re.sub(r"_+", "_", value).strip("_")
    return value or fallback


def m_order(tag: str) -> int:
    m = re.match(r"M(\d{2})", tag or "")
    return int(m.group(1)) if m else 999


def read_jsonl(path: Path) -> Iterable[Dict[str, Any]]:
    with path.open(encoding="utf-8") as f:
        for line in f:
            if line.strip():
                yield json.loads(line)


def parse_tags(row: Dict[str, Any]) -> List[str]:
    tags = row.get("tags") or []
    if isinstance(tags, str):
        if tags.startswith("["):
            try:
                tags = json.loads(tags)
            except Exception:
                tags = re.split(r"[;,]\s*", tags)
        else:
            tags = re.split(r"[;,]\s*", tags)
    tags = [TAG_ALIASES.get(t, t) for t in tags if isinstance(t, str) and t.startswith("M")]
    return sorted(set(tags), key=m_order)


def depth_bin(row: Dict[str, Any]) -> str:
    try:
        depth = int(float(row.get("depth") or 0))
    except Exception:
        depth = 0
    if depth <= 2:
        return "D1_shallow"
    if depth <= 4:
        return "D2_medium"
    if depth <= 7:
        return "D3_deep"
    return "D4_very_deep"


def function_bin(row: Dict[str, Any]) -> str:
    funcs = safe_text(row.get("function_nodes"))
    tree = safe_text(row.get("tree_preorder")) + " " + safe_text(row.get("formula_latex"))
    text = (funcs + " " + tree).lower()
    if any(x in text for x in ["log", "ln", "exp", "sqrt", "^"]):
        return "F_log_exp_power"
    if any(x in text for x in ["sin", "cos", "tan", "sinh", "cosh"]):
        return "F_trigonometric"
    if any(x in text for x in ["sum", "prod", "int", "lim", "mathbb{e}", "expect", "pr", "operatorname"]):
        return "F_operator_statistical"
    if funcs.strip():
        return "F_named_or_nested_function"
    return "F_none"


def exclusion_reason_group(row: Dict[str, Any]) -> str:
    reason = safe_text(row.get("exclude_reason")).strip()
    status = safe_text(row.get("parse_status") or row.get("validity_status")).strip()
    method = safe_text(row.get("extraction_method")).lower()
    if "parse" in status.lower() and "fail" in status.lower():
        return "parse_failed"
    if reason:
        if "noise" in reason or "non_formula" in reason:
            return "text_noise_or_non_formula"
        if "confidence" in reason or "low" in reason:
            return "low_confidence_extraction"
        if "unsupported" in reason:
            return "unsupported_expression"
        if "duplicate" in reason:
            return "duplicate_or_near_duplicate"
        if "trivial" in reason:
            return "trivial_or_too_simple"
        return reason
    if "ocr" in method:
        return "low_confidence_extraction"
    return "other_excluded"


def root_structure_layer(row: Dict[str, Any], tags: List[str], valid: bool) -> str:
    if not valid or not tags:
        return "质量过滤出口"
    tag_set = set(tags)
    root_operator = safe_text(row.get("root_operator")).lower()
    root_pattern = safe_text(row.get("root_pattern")).lower()
    layer_pattern = safe_text(row.get("layer_pattern")).lower()

    # The coarse cluster must be derived from the parsed tree before looking at
    # M01-M12 tags.  Otherwise the hierarchy only restates the final labels.
    if root_pattern == "root_additive" or "+" in root_operator or "add" in root_operator:
        return "加法主结构"
    if root_pattern == "root_multiplicative" or "*" in root_operator or "mul" in root_operator:
        return "乘法主结构"
    if root_pattern == "root_function" or "func" in root_pattern or "function" in root_operator:
        return "函数复合主结构"
    if root_pattern == "root_power" or "^" in root_operator or "power" in root_pattern:
        return "幂与根式主结构"
    if root_pattern == "root_relation" or root_operator in {"=", "==", "<=", ">=", "!=", "~=", "~", "->"}:
        return "关系表达式主结构"

    # Only use final tags as a fallback for legacy rows that do not yet carry
    # root-pattern fields.
    if tag_set & {
        "M01_basic_additive_separable_no_overlap",
        "M03_overlapping_additive",
        "M09_universal_additive_generalized_additivity",
    } or "+" in root_operator or "add" in root_operator or "add" in root_pattern:
        return "加法主结构"
    if tag_set & {
        "M02_basic_multiplicative_separable_no_overlap",
        "M04_overlapping_multiplicative",
        "M05_product_with_constant",
        "M10_universal_multiplicative",
    } or "*" in root_operator or "mul" in root_operator or "product" in root_pattern:
        return "乘法主结构"
    if tag_set & {
        "M06_compositionality",
        "M07_log_exp_nested",
        "M08_sin_nested",
    } or "compos" in layer_pattern:
        return "函数复合主结构"
    if tag_set & {"M11_generalized_symmetry", "M12_simple_symmetry"}:
        return "对称主结构"
    return "其他可用结构"


def separability_layer(row: Dict[str, Any], tags: List[str], valid: bool) -> str:
    if not valid or not tags:
        return exclusion_reason_group(row)
    tag_set = set(tags)
    # A function-root formula is first grouped by its inner decomposition.
    # Otherwise a generic M01 tag masks the more informative M09/M10 path.
    if root_structure_layer(row, tags, valid) == "函数复合主结构":
        if "M07_log_exp_nested" in tag_set:
            return "log/exp 嵌套特殊分离"
        if "M08_sin_nested" in tag_set:
            return "sin 嵌套特殊分离"
        if "M09_universal_additive_generalized_additivity" in tag_set:
            return "通用加法分离 U(g+h)"
        if "M10_universal_multiplicative" in tag_set:
            return "通用乘法分离 U(g*h)"
        if "M06_compositionality" in tag_set:
            return "复合结构"
    if "M01_basic_additive_separable_no_overlap" in tag_set:
        return "基础加法可分离（无重合变量）"
    if "M02_basic_multiplicative_separable_no_overlap" in tag_set:
        return "基础乘法可分离（无重合变量）"
    if tag_set & {"M03_overlapping_additive", "M04_overlapping_multiplicative"}:
        return "带重合变量的可分离"
    if "M05_product_with_constant" in tag_set:
        return "带常数项的乘法可分离"
    if "M07_log_exp_nested" in tag_set:
        return "log/exp 嵌套特殊分离"
    if "M08_sin_nested" in tag_set:
        return "sin 嵌套特殊分离"
    if "M09_universal_additive_generalized_additivity" in tag_set:
        return "通用加法分离 U(g+h)"
    if "M10_universal_multiplicative" in tag_set:
        return "通用乘法分离 U(g*h)"
    if "M06_compositionality" in tag_set:
        return "复合结构"
    if "M12_simple_symmetry" in tag_set:
        return "简单对称结构"
    if "M11_generalized_symmetry" in tag_set:
        return "广义对称结构"
    return "其他可用结构"


def detail_layer(row: Dict[str, Any], tags: List[str], valid: bool) -> str:
    if not valid or not tags:
        return safe_text(row.get("exclude_reason")) or "not_valid_for_core_stats"
    tag_set = set(tags)
    if "M03_overlapping_additive" in tag_set:
        return "带重合变量的加法可分离"
    if "M04_overlapping_multiplicative" in tag_set:
        return "带重合变量的乘法可分离"
    if "M12_simple_symmetry" in tag_set:
        return "简单对称"
    if "M11_generalized_symmetry" in tag_set:
        return "广义对称"
    return separability_layer(row, tags, valid)


def feature_cluster_layer(row: Dict[str, Any], tags: List[str], valid: bool) -> str:
    if not valid or not tags:
        return "质量过滤出口|" + exclusion_reason_group(row)
    parts = [
        root_structure_layer(row, tags, valid),
        clean_token(row.get("root_pattern"), "root_unknown"),
        clean_token(row.get("layer_pattern"), "layer_unknown"),
        clean_token(row.get("variable_overlap_status"), "overlap_unknown"),
        "含常数或系数" if safe_text(row.get("has_constant_or_coefficient")) in {"1", "true", "True"} else "无显式常数系数",
        function_bin(row),
    ]
    return "|".join(parts)


def hierarchy_levels(row: Dict[str, Any], tags: List[str], valid: bool) -> Tuple[str, str, str, str]:
    quality = "进入核心统计" if valid and tags else "质量过滤出口"
    root_layer = root_structure_layer(row, tags, valid)
    sep_layer = separability_layer(row, tags, valid)
    det_layer = detail_layer(row, tags, valid)
    return quality, root_layer, sep_layer, f"{quality} > {root_layer} > {sep_layer} > {det_layer}"


def operator_family(row: Dict[str, Any], tags: List[str]) -> str:
    valid = row.get("validity_status") == "valid_for_core_stats"
    return root_structure_layer(row, tags, valid)


def middle_cluster(row: Dict[str, Any], tags: List[str]) -> str:
    valid = row.get("validity_status") == "valid_for_core_stats"
    return separability_layer(row, tags, valid)


def fine_signature(row: Dict[str, Any], tags: List[str]) -> str:
    valid = row.get("validity_status") == "valid_for_core_stats"
    parts = [
        root_structure_layer(row, tags, valid),
        separability_layer(row, tags, valid),
        detail_layer(row, tags, valid),
        feature_cluster_layer(row, tags, valid),
        depth_bin(row),
        clean_token(",".join(tags), "no_m_tag"),
    ]
    return "|".join(parts)


def primary_m12(tags: List[str]) -> str:
    if not tags:
        return "REVIEW_NON_M12"
    # Specific nested-function patterns must win over their generic parent
    # M06; otherwise M07/M08 are detected in multi-label statistics but vanish
    # from the mutually exclusive primary-class counts.
    for specific in (
        "M07_log_exp_nested",
        "M08_sin_nested",
        "M09_universal_additive_generalized_additivity",
        "M10_universal_multiplicative",
        "M12_simple_symmetry",
        "M06_compositionality",
        "M11_generalized_symmetry",
    ):
        if specific in tags:
            return specific
    return sorted(tags, key=m_order)[0]


def load_records(root: Path, inputs: List[Tuple[str, str]]) -> List[Dict[str, Any]]:
    rows: List[Dict[str, Any]] = []
    for dataset, rel in inputs:
        path = root / rel
        if not path.exists():
            print(f"[skip] missing input: {path}")
            continue
        for i, row in enumerate(read_jsonl(path), start=1):
            tags = parse_tags(row)
            valid = row.get("validity_status") == "valid_for_core_stats"
            record = {
                "dataset": dataset,
                "dataset_formula_index": i,
                "formula_id": row.get("formula_id", ""),
                "source_id": row.get("source_id", ""),
                "source_title": row.get("source_title", ""),
                "source_file": row.get("source_file", ""),
                "page": row.get("page", ""),
                "locator": row.get("locator", ""),
                "extraction_method": row.get("extraction_method", ""),
                "image_screen_status": row.get("image_screen_status", ""),
                "image_screen_reason": row.get("image_screen_reason", ""),
                "image_screen_metrics": safe_text(row.get("image_screen_metrics")),
                "ocr_generated_status": row.get("ocr_generated_status", ""),
                "ocr_quality_status": row.get("ocr_quality_status", ""),
                "ocr_quality_reasons": row.get("ocr_quality_reasons", ""),
                "ocr_variant_similarity": row.get("ocr_variant_similarity", ""),
                "formula_latex": row.get("formula_latex", ""),
                "normalized": row.get("normalized", ""),
                "tree_preorder": row.get("tree_preorder", ""),
                "analysis_target_preorder": row.get("analysis_target_preorder", ""),
                "root_operator": row.get("root_operator", ""),
                "root_pattern": row.get("root_pattern", ""),
                "layer_pattern": row.get("layer_pattern", ""),
                "variable_overlap_status": row.get("variable_overlap_status", ""),
                "variable_sets": safe_text(row.get("variable_sets")),
                "function_nodes": row.get("function_nodes", ""),
                "depth": row.get("depth", ""),
                "parse_mode": row.get("parse_mode", ""),
                "semantic_coverage": row.get("semantic_coverage", ""),
                "dropped_semantic_commands": safe_text(row.get("dropped_semantic_commands")),
                "repaired_delimiter_count": row.get("repaired_delimiter_count", ""),
                "has_constant_or_coefficient": row.get("has_constant_or_coefficient", ""),
                "validity_status": row.get("validity_status", ""),
                "exclude_reason": row.get("exclude_reason", ""),
                "m01_m12_tags": ";".join(tags),
                "primary_m12": primary_m12(tags) if valid else "NON_CORE_REVIEW",
                "is_core_formula": "1" if valid and tags else "0",
            }
            quality_layer, root_layer, sep_layer, hpath = hierarchy_levels(row, tags, valid)
            det_layer = detail_layer(row, tags, valid)
            feature_layer = feature_cluster_layer(row, tags, valid)
            record["quality_layer"] = quality_layer
            record["root_structure_layer"] = root_layer
            record["separability_layer"] = sep_layer
            record["detail_layer"] = det_layer
            record["feature_cluster_layer"] = feature_layer
            record["hierarchy_level_1"] = quality_layer
            record["hierarchy_level_2"] = root_layer
            record["hierarchy_level_3"] = sep_layer
            record["hierarchy_path"] = hpath
            record["coarse_cluster"] = root_layer
            record["middle_cluster"] = sep_layer
            record["fine_signature"] = fine_signature(row, tags)
            rows.append(record)
    return rows


def write_csv(path: Path, rows: List[Dict[str, Any]], fieldnames: List[str] | None = None) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    if fieldnames is None:
        fieldnames = list(rows[0].keys()) if rows else []
    with path.open("w", encoding="utf-8-sig", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(rows)


def frequency_rows(records: List[Dict[str, Any]], level: str, total: int, low_threshold: int) -> List[Dict[str, Any]]:
    counted_records = (
        [r for r in records if r["is_core_formula"] == "1"]
        if level == "fine_signature"
        else records
    )
    denominator = len(counted_records)
    counter = Counter(r[level] for r in counted_records)
    core_counter = Counter(r[level] for r in records if r["is_core_formula"] == "1")
    rows = []
    for cluster, count in counter.most_common():
        rows.append({
            "level": level,
            "cluster": cluster,
            "formula_count": count,
            "core_formula_count": core_counter.get(cluster, 0),
            "support_ratio": f"{count / denominator:.6f}" if denominator else "0",
            "low_frequency_status": "low_frequency_pruned" if level == "fine_signature" and count < low_threshold else "stable",
        })
    return rows


def representative_examples(records: List[Dict[str, Any]], limit_per_m: int = 3) -> List[Dict[str, Any]]:
    grouped: Dict[str, List[Dict[str, Any]]] = defaultdict(list)
    for r in records:
        if r["is_core_formula"] == "1":
            for tag in r["m01_m12_tags"].split(";"):
                if tag in M12_CATALOG:
                    grouped[tag].append(r)
    rows = []
    for tag in sorted(M12_CATALOG, key=m_order):
        examples = sorted(grouped.get(tag, []), key=lambda r: (r["dataset"], r["source_id"], r["formula_id"]))[:limit_per_m]
        for ex in examples:
            rows.append({
                "m12_tag": tag,
                "m12_name": M12_CATALOG[tag],
                "dataset": ex["dataset"],
                "source_title": ex["source_title"],
                "page": ex["page"],
                "formula_id": ex["formula_id"],
                "formula_latex": ex["formula_latex"],
                "tree_preorder": ex["tree_preorder"],
                "coarse_cluster": ex["coarse_cluster"],
                "middle_cluster": ex["middle_cluster"],
                "fine_signature": ex["fine_signature"],
            })
    return rows


def build_report(root: Path, records: List[Dict[str, Any]], low_threshold: int, freq_rows: List[Dict[str, Any]], inputs: List[Tuple[str, str]]) -> str:
    total = len(records)
    core = sum(r["is_core_formula"] == "1" for r in records)
    non_core = total - core
    dataset_counts = Counter(r["dataset"] for r in records)
    m12_counts = Counter(
        tag
        for r in records
        if r["is_core_formula"] == "1"
        for tag in r["m01_m12_tags"].split(";")
        if tag in M12_CATALOG
    )
    quality_counts = Counter(r["quality_layer"] for r in records)
    root_counts = Counter(r["root_structure_layer"] for r in records)
    sep_counts = Counter(r["separability_layer"] for r in records)
    detail_counts = Counter(r["detail_layer"] for r in records)
    feature_counts = Counter(r["feature_cluster_layer"] for r in records)
    root_sep_counts: Dict[str, Counter] = defaultdict(Counter)
    root_detail_counts: Dict[str, Counter] = defaultdict(Counter)
    for r in records:
        root_sep_counts[r["root_structure_layer"]][r["separability_layer"]] += 1
        root_detail_counts[r["root_structure_layer"]][r["detail_layer"]] += 1
    fine_counts = Counter(r["fine_signature"] for r in records if r["is_core_formula"] == "1")
    low_fine = sum(1 for _, c in fine_counts.items() if c < low_threshold)
    low_formula_count = sum(c for _, c in fine_counts.items() if c < low_threshold)

    m12_lines = "\n".join(
        f"- {tag}（{M12_CATALOG[tag]}）：{m12_counts.get(tag, 0)}"
        for tag in sorted(M12_CATALOG, key=m_order)
    )
    dataset_lines = "\n".join(f"- {k}：{v}" for k, v in dataset_counts.most_common())
    root_lines = "\n".join(f"- {k}：{v}" for k, v in root_counts.most_common())
    sep_lines = "\n".join(f"- {k}：{v}" for k, v in sep_counts.most_common())
    detail_lines = "\n".join(f"- {k}：{v}" for k, v in detail_counts.most_common(12))

    known_exclusion = {
        "parse_failed",
        "low_confidence_extraction",
        "unsupported_expression",
        "text_noise_or_non_formula",
    }
    stable_non_exclusion_prefixes = ("基础", "带", "复合", "log", "sin", "通用", "广义", "简单")
    other_excluded_count = sum(
        v
        for k, v in sep_counts.items()
        if k in {"other_excluded", "duplicate_or_near_duplicate", "trivial_or_too_simple"}
        or (k not in known_exclusion and not k.startswith(stable_non_exclusion_prefixes))
    )

    process_tree = f"""表达式分解模式（总公式记录：{total}）
├─ 第1层：质量入口
│  ├─ 进入核心统计：{core}
│  └─ 质量过滤出口：{non_core}
│     ├─ 文本噪声或非公式：{sep_counts.get('text_noise_or_non_formula', 0)}
│     ├─ 过简单或占位表达式：{sep_counts.get('trivial_or_too_simple', 0)}
│     ├─ 表格/编号/说明性值：{sep_counts.get('table_label_or_caption_value', 0) + sep_counts.get('document_identifier_or_code', 0)}
│     └─ 暂不支持表达式：{sep_counts.get('unsupported_expression', 0)}
├─ 第2层：根节点与主结构粗聚类（核心公式）
│  ├─ 加法主结构：{root_counts.get('加法主结构', 0)}
│  │  ├─ 第3层：可分离属性
│  │  │  ├─ 基础加法可分离候选：{root_sep_counts['加法主结构'].get('基础加法可分离（无重合变量）', 0)}
│  │  │  ├─ 乘法交叉候选：{root_sep_counts['加法主结构'].get('基础乘法可分离（无重合变量）', 0)}
│  │  │  ├─ 带重合变量候选：{root_sep_counts['加法主结构'].get('带重合变量的可分离', 0)}
│  │  │  ├─ 常数/系数候选：{root_sep_counts['加法主结构'].get('带常数项的乘法可分离', 0)}
│  │  │  └─ 复合候选：{root_sep_counts['加法主结构'].get('复合结构', 0)}
│  │  └─ 第4层：结构细节签名
│  │     ├─ 重合变量-加法细节：{root_detail_counts['加法主结构'].get('带重合变量的加法可分离', 0)}
│  │     ├─ 基础加法细节：{root_detail_counts['加法主结构'].get('基础加法可分离（无重合变量）', 0)}
│  │     ├─ 对称细节：{root_detail_counts['加法主结构'].get('简单对称', 0) + root_detail_counts['加法主结构'].get('广义对称', 0)}
│  │     └─ 其他交叉细节：{root_detail_counts['加法主结构'].get('带重合变量的乘法可分离', 0) + root_detail_counts['加法主结构'].get('带常数项的乘法可分离', 0) + root_detail_counts['加法主结构'].get('基础乘法可分离（无重合变量）', 0) + root_detail_counts['加法主结构'].get('复合结构', 0)}
│  ├─ 乘法主结构：{root_counts.get('乘法主结构', 0)}
│  │  ├─ 第3层：可分离属性
│  │  │  ├─ 基础乘法可分离候选：{root_sep_counts['乘法主结构'].get('基础乘法可分离（无重合变量）', 0)}
│  │  │  ├─ 带重合变量候选：{root_sep_counts['乘法主结构'].get('带重合变量的可分离', 0)}
│  │  │  ├─ 复合候选：{root_sep_counts['乘法主结构'].get('复合结构', 0)}
│  │  │  ├─ 常数/系数候选：{root_sep_counts['乘法主结构'].get('带常数项的乘法可分离', 0)}
│  │  │  └─ 对称候选：{root_sep_counts['乘法主结构'].get('广义对称结构', 0)}
│  │  └─ 第4层：结构细节签名
│  │     ├─ 重合变量-乘法细节：{root_detail_counts['乘法主结构'].get('带重合变量的乘法可分离', 0)}
│  │     ├─ 基础乘法细节：{root_detail_counts['乘法主结构'].get('基础乘法可分离（无重合变量）', 0)}
│  │     ├─ 对称细节：{root_detail_counts['乘法主结构'].get('简单对称', 0) + root_detail_counts['乘法主结构'].get('广义对称', 0)}
│  │     └─ 复合/常数细节：{root_detail_counts['乘法主结构'].get('复合结构', 0) + root_detail_counts['乘法主结构'].get('带常数项的乘法可分离', 0)}
│  └─ 函数复合主结构：{root_counts.get('函数复合主结构', 0)}
│     ├─ 第3层：复合结构候选：{root_sep_counts['函数复合主结构'].get('复合结构', 0)}
│     └─ 第4层：复合/对称细节：{root_detail_counts['函数复合主结构'].get('复合结构', 0)} / {root_detail_counts['函数复合主结构'].get('广义对称', 0)}
├─ 第5层：细粒度签名频率筛选
│  ├─ 细粒度结构签名总数：{len(fine_counts)}
│  ├─ 稳定细签名：{len(fine_counts) - low_fine}
│  ├─ 低频细签名：{low_fine}
│  └─ 低频细签名覆盖公式：{low_formula_count}
└─ 第6层：固定模式收敛（M01-M12）
   ├─ M01 基础加法可分离：{m12_counts.get('M01_basic_additive_separable_no_overlap', 0)}
   ├─ M02 基础乘法可分离：{m12_counts.get('M02_basic_multiplicative_separable_no_overlap', 0)}
   ├─ M03/M04 带重合变量可分离：{m12_counts.get('M03_overlapping_additive', 0)} / {m12_counts.get('M04_overlapping_multiplicative', 0)}
   ├─ M05 常数/系数乘积结构：{m12_counts.get('M05_product_with_constant', 0)}
   ├─ M06 复合结构总数：{m12_counts.get('M06_compositionality', 0)}
   │  └─ 其中 M07/M08/M09/M10：{m12_counts.get('M07_log_exp_nested', 0)} / {m12_counts.get('M08_sin_nested', 0)} / {m12_counts.get('M09_universal_additive_generalized_additivity', 0)} / {m12_counts.get('M10_universal_multiplicative', 0)}
   └─ M11 广义对称总数：{m12_counts.get('M11_generalized_symmetry', 0)}（其中 M12 简单对称：{m12_counts.get('M12_simple_symmetry', 0)}）
"""

    return f"""# 公式分解模式聚类链路与结果汇报

## 本轮输入与结果

本报告仅根据本轮传入的 `formula_trees.jsonl` 自动生成；资料规模、来源和统计值均从当前运行结果读取，不混入历史周次或固定样本规模。

- 聚类输入公式记录：{total} 条。
- 进入核心统计：{core} 条。
- 保留但不进入核心统计：{non_core} 条。
- 本轮输入数据集：
{dataset_lines}

## 由粗到细的层级聚类

```text
{process_tree}
```

第 1 层先做质量入口控制；第 2 层按公式树根节点得到主结构；第 3 层判断可分离性、嵌套函数、变量重合和对称候选；第 4 层结合根模式、层模式、变量重合、常数/系数、函数族和树深度形成细粒度结构签名；第 5 层仅在核心公式中统计细签名频率，并将低频签名合并为稳定上位簇；第 6 层以固定的 M01-M12 规则输出可横向比较的模式统计。前五层是逐步聚类，M01-M12 是最终统一口径，不改变类别数量。

## 各层统计

质量入口：进入核心统计 {quality_counts.get('进入核心统计', 0)} 条，质量过滤出口 {quality_counts.get('质量过滤出口', 0)} 条。

根节点主结构：
{root_lines}

可分离属性：
{sep_lines}

结构细节前 12 项：
{detail_lines}

细粒度签名阈值：{low_threshold}；细签名总数：{len(fine_counts)}；稳定细签名：{len(fine_counts) - low_fine}；低频细签名：{low_fine}；其覆盖公式：{low_formula_count} 条。

## M01-M12 多标签统计

{m12_lines}

一个公式可同时具有多个结构性质，因此上述 M01-M12 是多标签命中频次；用于互斥频率统计时，程序按“特殊嵌套结构优先、通用结构其次、一般结构随后”的规则写入 `primary_m12`。

## 输出与追溯

运行目录会输出公式级聚类明细、各层频率表、低频细签名表、M01-M12 频率表和代表公式样例。每条记录保留来源文献、原始图片路径、OCR LaTeX、标准化表达式、公式树、解析方式、质量状态、层级路径和分类标签，统计结果可回溯到原始公式图片。
"""


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", default=".", help="Project run directory.")
    parser.add_argument("--min-support", type=int, default=5, help="Minimum support for a stable fine signature.")
    parser.add_argument("--input", action="append", default=[], help="Optional dataset=relative/path/to/formula_trees.jsonl. Can be used multiple times.")
    args = parser.parse_args()

    root = Path(args.root).resolve()
    data_dir = root / "data_production"
    out_dir = root / "outputs_production_clustering_production"
    data_dir.mkdir(parents=True, exist_ok=True)
    out_dir.mkdir(parents=True, exist_ok=True)

    if args.input:
        inputs = []
        for item in args.input:
            if "=" not in item:
                raise SystemExit(f"--input must be dataset=path, got: {item}")
            dataset, rel = item.split("=", 1)
            inputs.append((dataset.strip(), rel.strip()))
    else:
        inputs = DEFAULT_INPUTS

    records = load_records(root, inputs)
    total = len(records)
    core_total = sum(r["is_core_formula"] == "1" for r in records)
    low_threshold = max(args.min_support, math.ceil(core_total * 0.001))
    fine_counter = Counter(
        r["fine_signature"] for r in records if r["is_core_formula"] == "1"
    )
    for r in records:
        if r["is_core_formula"] == "1":
            is_low = fine_counter[r["fine_signature"]] < low_threshold
            r["fine_signature_count"] = fine_counter[r["fine_signature"]]
            r["fine_signature_status"] = "low_frequency_pruned" if is_low else "stable"
            r["final_converged_class"] = r["primary_m12"]
            r["stable_cluster_after_pruning"] = (
                f"{r['final_converged_class']}::LOW_FREQ_MERGED"
                if is_low
                else f"{r['final_converged_class']}::{r['fine_signature']}"
            )
        else:
            r["fine_signature_count"] = 0
            r["fine_signature_status"] = "not_counted_non_core"
            r["final_converged_class"] = "NON_CORE_REVIEW"
            r["stable_cluster_after_pruning"] = "NON_CORE_REVIEW"

    record_fields = [
        "dataset", "dataset_formula_index", "formula_id", "source_id", "source_title", "source_file",
        "page", "locator", "extraction_method", "image_screen_status", "image_screen_reason", "image_screen_metrics",
        "ocr_generated_status", "ocr_quality_status", "ocr_quality_reasons", "ocr_variant_similarity", "formula_latex", "normalized", "tree_preorder",
        "analysis_target_preorder", "root_operator", "root_pattern", "layer_pattern",
        "variable_overlap_status", "variable_sets", "function_nodes", "depth", "parse_mode",
        "semantic_coverage", "dropped_semantic_commands", "repaired_delimiter_count",
        "has_constant_or_coefficient", "validity_status", "exclude_reason", "m01_m12_tags",
        "primary_m12", "is_core_formula", "quality_layer", "root_structure_layer",
        "separability_layer", "detail_layer", "feature_cluster_layer", "hierarchy_level_1",
        "hierarchy_level_2", "hierarchy_level_3", "hierarchy_path", "coarse_cluster",
        "middle_cluster", "fine_signature", "fine_signature_count", "fine_signature_status",
        "stable_cluster_after_pruning", "final_converged_class",
    ]
    write_csv(data_dir / "production_formula_cluster_records_production.csv", records, record_fields)

    all_freq = []
    for level in ["quality_layer", "root_structure_layer", "separability_layer", "detail_layer", "feature_cluster_layer", "fine_signature", "final_converged_class"]:
        all_freq.extend(frequency_rows(records, level, total, low_threshold))
    write_csv(data_dir / "production_cluster_frequency_by_level_production.csv", all_freq)

    low_rows = [
        {
            "fine_signature": sig,
            "formula_count": count,
            "support_ratio": f"{count / max(1, core_total):.6f}",
            "pruning_action": "merge_to_final_m12_or_review",
        }
        for sig, count in fine_counter.most_common()
        if count < low_threshold
    ]
    write_csv(data_dir / "production_low_frequency_pruned_signatures_production.csv", low_rows, ["fine_signature", "formula_count", "support_ratio", "pruning_action"])

    m12_occurrence_counter = Counter(
        tag
        for r in records
        if r["is_core_formula"] == "1"
        for tag in r["m01_m12_tags"].split(";")
        if tag in M12_CATALOG
    )
    m12_primary_counter = Counter(r["primary_m12"] for r in records if r["is_core_formula"] == "1")
    m12_rows = [
        {
            "m12_tag": tag,
            "m12_name": M12_CATALOG[tag],
            "pattern_occurrence_count": m12_occurrence_counter.get(tag, 0),
            "pattern_occurrence_ratio_among_core_formulas": f"{m12_occurrence_counter.get(tag, 0) / max(1, core_total):.6f}",
            "primary_converged_formula_count": m12_primary_counter.get(tag, 0),
            "primary_converged_ratio_among_core_formulas": f"{m12_primary_counter.get(tag, 0) / max(1, core_total):.6f}",
        }
        for tag in sorted(M12_CATALOG, key=m_order)
    ]
    write_csv(data_dir / "production_final_m01_m12_counts_production.csv", m12_rows)

    source_counter = defaultdict(lambda: Counter())
    for r in records:
        key = (r["dataset"], r["source_id"], r["source_title"])
        source_counter[key]["formula_count"] += 1
        if r["is_core_formula"] == "1":
            source_counter[key]["core_formula_count"] += 1
            source_counter[key][r["primary_m12"]] += 1
    source_rows = []
    for (dataset, source_id, title), c in source_counter.items():
        m_items = [(k, v) for k, v in c.items() if isinstance(k, str) and k.startswith("M")]
        m_items = sorted(m_items, key=lambda kv: (-kv[1], m_order(kv[0])))
        source_rows.append({
            "dataset": dataset,
            "source_id": source_id,
            "source_title": title,
            "formula_count": c["formula_count"],
            "core_formula_count": c["core_formula_count"],
            "top_m12": "; ".join(f"{k}={v}" for k, v in m_items[:5]),
        })
    write_csv(data_dir / "production_source_cluster_summary_production.csv", sorted(source_rows, key=lambda r: (r["dataset"], r["source_id"])))

    examples = representative_examples(records)
    write_csv(data_dir / "production_representative_examples_production.csv", examples)

    config = {
        "fixed_final_catalog": M12_CATALOG,
        "input_sources": inputs,
        "low_frequency_threshold": low_threshold,
        "low_frequency_rule": "core fine_signature count < max(min_support, ceil(core_formula_count * 0.001)); non-core rows are retained but not frequency-pruned",
        "hierarchy": ["coarse_cluster", "middle_cluster", "fine_signature", "low_frequency_pruning", "M01-M12"],
    }
    (data_dir / "production_cluster_pipeline_config_production.json").write_text(json.dumps(config, ensure_ascii=False, indent=2), encoding="utf-8")

    report = build_report(root, records, low_threshold, all_freq, inputs)
    (out_dir / "production_clustering_report_production.md").write_text(report, encoding="utf-8-sig")
    (root / "production-聚类链路与结果汇报_production.md").write_text(report, encoding="utf-8-sig")

    print(f"records={len(records)}")
    print(f"core={sum(r['is_core_formula'] == '1' for r in records)}")
    print(f"fine_signatures={len(fine_counter)} low_threshold={low_threshold}")
    print(f"report={root / 'production-聚类链路与结果汇报_production.md'}")


if __name__ == "__main__":
    main()
