#!/usr/bin/env bash
set -euo pipefail

PROJECT=${PROJECT:-$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)}
BASE_PACKAGE=${BASE_PACKAGE:-$PROJECT/common/formula_kb_production}
EXTENSION=${EXTENSION:-$PROJECT/ebook_pipeline}
PY=${PY:-$(command -v python3 || command -v python || true)}
EBOOK_ROOT=${EBOOK_ROOT:-$PROJECT/data/ebooks30}
RESULT_PARENT=${RESULT_PARENT:-$PROJECT/results}
SEED=${1:-2026081001}
RUN_ROOT="$RESULT_PARENT/ebook30_ocrseed_v2_seed${SEED}"
EXTRACT_WORKERS=${EXTRACT_WORKERS:-4}
SHARD_SIZE=${SHARD_SIZE:-1000}
INDEX_ONLY=${INDEX_ONLY:-1}
GPU_APPROVED=${GPU_APPROVED:-0}
GPU_IDS=${GPU_IDS:-0}
FORBIDDEN_GPU_IDS=${FORBIDDEN_GPU_IDS:-}
IFS=',' read -r -a GPUS <<< "$GPU_IDS"
WORKER_COUNT=${#GPUS[@]}
if [[ "$WORKER_COUNT" -lt 1 || -z "${GPUS[0]:-}" ]]; then
  echo "GPU_IDS must be a comma-separated list of GPU indices, e.g. GPU_IDS=0 or GPU_IDS=0,0,1" >&2
  exit 2
fi

for REQUIRED in \
  "$BASE_PACKAGE/server_pipeline.py" \
  "$BASE_PACKAGE/merge_full_formula_results.py" \
  "$EXTENSION/build_ebook_full_index.py" \
  "$EXTENSION/ebook_candidate_prefilter.py" \
  "$EXTENSION/audit_ebook_prefilter.py" \
  "$EXTENSION/run_ebook_local_shard.py" \
  "$EXTENSION/run_ebook_worker_loop.sh"
do
  if [[ ! -f "$REQUIRED" ]]; then
    echo "missing_required_file=$REQUIRED" >&2
    exit 2
  fi
done
if [[ ! -x "$PY" ]]; then
  echo "python_not_executable=$PY" >&2
  exit 2
fi
PDF_COUNT=$(find "$EBOOK_ROOT" -type f -iname '*.pdf' | wc -l)
if [[ "$PDF_COUNT" -ne 30 ]]; then
  echo "expected_30_pdfs_but_found=$PDF_COUNT root=$EBOOK_ROOT" >&2
  exit 2
fi

mkdir -p "$RUN_ROOT/index" "$RUN_ROOT/logs" "$RUN_ROOT/workers" "$RESULT_PARENT/archives"
echo "run_root=$RUN_ROOT"
echo "pdf_count=$PDF_COUNT extract_workers=$EXTRACT_WORKERS gpu_workers=$WORKER_COUNT"

if [[ ! -f "$RUN_ROOT/index/execution_manifest.json" ]]; then
  "$PY" "$EXTENSION/build_ebook_full_index.py" \
    --ebook-root "$EBOOK_ROOT" \
    --output-dir "$RUN_ROOT/index" \
    --dpi 200 \
    --extract-workers "$EXTRACT_WORKERS" \
    --shard-size "$SHARD_SIZE" \
    --min-vector-score 3.0 \
    --min-raster-score 1.5 \
    --scanned-text-threshold 40 \
    --seed "$SEED" \
    > "$RUN_ROOT/logs/index.log" 2>&1
fi

"$PY" "$EXTENSION/audit_ebook_prefilter.py" \
  --index-dir "$RUN_ROOT/index" \
  --output-dir "$RUN_ROOT/index/prefilter_audit" \
  --samples-per-group 20 \
  --seed "$SEED" \
  > "$RUN_ROOT/logs/prefilter_audit.log" 2>&1

if [[ ! -f "$RUN_ROOT/run_manifest.json" ]]; then
  "$PY" - "$RUN_ROOT" "$BASE_PACKAGE" "$EXTENSION" "$EBOOK_ROOT" "$SEED" <<'PY'
import datetime, hashlib, json, os, pathlib, sys
root=pathlib.Path(sys.argv[1])
base=pathlib.Path(sys.argv[2])
extension=pathlib.Path(sys.argv[3])
ebooks=pathlib.Path(sys.argv[4])
seed=int(sys.argv[5])
def inventory(folder):
    rows=[]
    for path in sorted(folder.rglob("*")):
        if path.is_file() and "__pycache__" not in path.parts:
            rows.append({
                "path":str(path.relative_to(folder)),
                "sha256":hashlib.sha256(path.read_bytes()).hexdigest(),
                "bytes":path.stat().st_size,
            })
    return rows
value={
    "run_id":root.name,
    "dataset_name":"ebook30_ocrseed_v2",
    "seed":seed,
    "created_at":datetime.datetime.now(datetime.timezone.utc).isoformat(),
    "ebook_root":str(ebooks),
    "base_package_dir":str(base),
    "extension_dir":str(extension),
    "worker_count":len([value for value in os.environ.get("GPU_IDS", "0").split(",") if value.strip()]),
    "gpu_worker_map":{},
    "forbidden_gpu":[int(value) for value in os.environ.get("FORBIDDEN_GPU_IDS", "").split(",") if value.strip()],
    "selection":"all pages; word-boundary-preserving PDF extraction; relation and matrix boundary repair; explicit code/instruction/graph vetoes; recall-safe review rescue for complete structured formulas; audited v3.5 pre-OCR filter; no per-page or per-book count cap",
    "pre_ocr_policy":{
        "accepted_high_confidence":"send to frozen OCR and formula pipeline",
        "accepted_review":"send to frozen OCR and retain review flag",
        "rejected_pre_ocr":"do not send to OCR; retain crop, text features and reason"
    },
    "classification_standard":"M01-M12 frozen production rules",
    "provenance_policy":"preserve exact PDF, page, bounding box, crop and embedded metadata",
    "base_package_files":inventory(base),
    "extension_files":inventory(extension),
}
for slot, gpu in enumerate(value for value in os.environ.get("GPU_IDS", "0").split(",") if value.strip()):
    value["gpu_worker_map"].setdefault(str(int(gpu)), []).append(slot)
(root/"run_manifest.json").write_text(
    json.dumps(value,ensure_ascii=False,indent=2),encoding="utf-8"
)
PY
fi

if [[ "$INDEX_ONLY" == "1" ]]; then
  echo "index_only_complete=$RUN_ROOT/index/execution_manifest.json"
  cat "$RUN_ROOT/index/prefilter_audit/prefilter_audit_summary.json"
  echo "review_samples=$RUN_ROOT/index/prefilter_audit/samples"
  echo "gpu_not_started=1"
  exit 0
fi

AUDIT_FINGERPRINT="$RUN_ROOT/index/prefilter_audit/prefilter_audit_fingerprint.sha256"
APPROVAL_FINGERPRINT="$RUN_ROOT/GPU_AUDIT_APPROVED.sha256"
if [[ "$GPU_APPROVED" != "1" ]]; then
  echo "gpu_start_refused=GPU_APPROVED_is_not_1" >&2
  echo "review_samples=$RUN_ROOT/index/prefilter_audit/samples" >&2
  exit 3
fi
if [[ ! -f "$AUDIT_FINGERPRINT" || ! -f "$APPROVAL_FINGERPRINT" ]]; then
  echo "gpu_start_refused=missing_audit_or_approval_fingerprint" >&2
  echo "required_approval_file=$APPROVAL_FINGERPRINT" >&2
  exit 3
fi
if ! cmp -s "$AUDIT_FINGERPRINT" "$APPROVAL_FINGERPRINT"; then
  echo "gpu_start_refused=audit_fingerprint_mismatch" >&2
  echo "The index/audit changed after approval; review the samples again." >&2
  exit 3
fi

for SLOT in "${!GPUS[@]}"; do
  if [[ -f "$RUN_ROOT/worker_${SLOT}.complete" ]]; then
    echo "worker_already_complete slot=$SLOT"
    continue
  fi
  PID_FILE="$RUN_ROOT/worker_${SLOT}.pid"
  if [[ -f "$PID_FILE" ]]; then
    OLD_PID=$(cat "$PID_FILE")
    if kill -0 "$OLD_PID" 2>/dev/null; then
      echo "worker_already_running slot=$SLOT pid=$OLD_PID"
      continue
    fi
  fi
  nohup bash "$EXTENSION/run_ebook_worker_loop.sh" \
    "$RUN_ROOT" "$BASE_PACKAGE" "$EXTENSION" "$PY" \
    "$SLOT" "${GPUS[$SLOT]}" "$WORKER_COUNT" \
    > "$RUN_ROOT/logs/launcher_${SLOT}.log" 2>&1 &
  echo $! > "$PID_FILE"
  echo "worker_launched slot=$SLOT gpu=${GPUS[$SLOT]} pid=$!"
done

echo "run_started=$RUN_ROOT"
echo "monitor_command=bash '$EXTENSION/monitor_ebook_full.sh' '$RUN_ROOT'"
