#!/usr/bin/env python3
"""Build a resumable, auditable full-page formula-candidate index for PDF books."""

from __future__ import annotations

import argparse
import hashlib
import json
import math
import os
import re
import time
from concurrent.futures import ProcessPoolExecutor, as_completed
from pathlib import Path
from typing import Any

import fitz
import numpy as np
from PIL import Image

from ebook_candidate_prefilter import classify_candidate


MATH_FONT_RE = re.compile(
    r"(?:math|symbol|stix|cambria|cmmi|cmsy|cmex|msam|msbm|euclid|mt extra|"
    r"latinmodernmath|asana|xits|libertinusmath|texgyre)",
    re.I,
)
STRONG_MATH_RE = re.compile(r"[=≠≈≃≅≤≥∑∏∫√∞∂∇±×÷∈∉⊂⊃⊆⊇∪∩→↔⇒⇔]")
GREEK_RE = re.compile(r"[Α-Ωα-ω]")
ASCII_OPERATOR_RE = re.compile(
    r"(?<!\w)[+\-−*/^<>](?!\w)"
    r"|[A-Za-z0-9]\s*[+\-−*/^<>]\s*[A-Za-z0-9]"
)
FUNCTION_RE = re.compile(
    r"\b(?:sin|cos|tan|cot|sec|csc|log|ln|exp|lim|max|min|det|rank|"
    r"Pr|Var|Cov|E)\s*[\(\[]",
    re.I,
)
SUBSCRIPT_RE = re.compile(r"[A-Za-z][₀-₉ₐ-ₜ]|[A-Za-z]\s*[_^]\s*[A-Za-z0-9{]")
EQUATION_NUMBER_RE = re.compile(
    r"^\s*[\(\[]?\s*(?:[A-Za-z]\.)?\d+(?:\.\d+){1,3}[A-Za-z]?\s*[\)\]]?\s*$"
)
CONTEXT_CONNECTOR_RE = re.compile(
    r"^\s*(?:where|when|whenever|provided|for\s+(?:all|any)|if\s+|with\s+)\b",
    re.I,
)
INLINE_CONTEXT_CONNECTOR_RE = re.compile(
    r"\s+(?=(?:where|when|whenever|provided(?:\s+that)?|"
    r"for\s+(?:all|any)|if|with)\b)",
    re.I,
)
LEADING_ANSWER_LABEL_RE = re.compile(
    r"^\s*(?:answer|solution)\.?\s*(?:\d{1,4}\s*[.)]\s*)?",
    re.I,
)
TRAILING_EQUATION_NUMBER_RE = re.compile(
    r"\s+([\(\[]\s*(?:[A-Za-z]\.)?\d+(?:\.\d+){1,3}[A-Za-z]?\s*[\)\]])\s*$"
)
LEADING_RELATION_FRAGMENT_RE = re.compile(r"^\s*[=≠≈≤≥]")
TRAILING_RELATION_FRAGMENT_RE = re.compile(r"[=≠≈≤≥+\-−*/^]\s*$")
MATRIX_BOUNDARY_GLYPH_RE = re.compile(
    r"[⎡⎢⎣⎤⎥⎦]"
)


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def stable_id(prefix: str, *parts: object, length: int = 20) -> str:
    raw = "\0".join(str(part) for part in parts).encode("utf-8", "surrogatepass")
    return f"{prefix}_{hashlib.sha256(raw).hexdigest()[:length]}"


def atomic_json(path: Path, value: object) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_suffix(path.suffix + f".tmp.{os.getpid()}")
    temp.write_text(json.dumps(value, ensure_ascii=False, indent=2), encoding="utf-8")
    temp.replace(path)


def render_page(page: fitz.Page, dpi: int) -> Image.Image:
    pix = page.get_pixmap(dpi=dpi, alpha=False)
    return Image.frombytes("RGB", (pix.width, pix.height), pix.samples)


def candidate_score(box: tuple[int, int, int, int], height: int, width: int, density: float) -> float:
    x0, y0, x1, y1 = box
    bw = max(1, x1 - x0)
    bh = max(1, y1 - y0)
    width_ratio = bw / max(1, width)
    height_ratio = bh / max(1, height)
    center = 1.0 - abs(((x0 + x1) / 2.0) - width / 2.0) / max(1, width / 2.0)
    score = center * 2.2
    score += 1.5 if 0.10 <= width_ratio <= 0.88 else -1.0
    score += 1.2 if 0.008 <= height_ratio <= 0.14 else -0.8
    score += 1.2 if 0.018 <= density <= 0.22 else -1.0
    if width_ratio > 0.86 and density > 0.14:
        score -= 3.0
    if bh < 14 or bh > height * 0.25:
        score -= 2.0
    return score


def box_iou(left: tuple[int, int, int, int], right: tuple[int, int, int, int]) -> float:
    lx0, ly0, lx1, ly1 = left
    rx0, ry0, rx1, ry1 = right
    ix0, iy0 = max(lx0, rx0), max(ly0, ry0)
    ix1, iy1 = min(lx1, rx1), min(ly1, ry1)
    if ix1 <= ix0 or iy1 <= iy0:
        return 0.0
    inter = (ix1 - ix0) * (iy1 - iy0)
    la = max(1, (lx1 - lx0) * (ly1 - ly0))
    ra = max(1, (rx1 - rx0) * (ry1 - ry0))
    return inter / float(la + ra - inter)


def raster_candidate_bands(image: Image.Image, min_score: float) -> list[dict[str, Any]]:
    """High-recall fallback for scanned/image-only pages; there is no count cap."""
    gray = np.asarray(image.convert("L"))
    height, width = gray.shape
    ink = gray < 210
    row_density = ink.mean(axis=1)
    threshold = max(0.004, min(0.025, float(row_density.mean()) * 1.45))
    active = row_density > threshold
    raw_bands: list[tuple[int, int]] = []
    start: int | None = None
    gap = 0
    for row_no, is_active in enumerate(active):
        if is_active:
            if start is None:
                start = row_no
            gap = 0
        elif start is not None:
            gap += 1
            if gap > 7:
                raw_bands.append((start, row_no - gap))
                start = None
                gap = 0
    if start is not None:
        raw_bands.append((start, height - 1))

    candidates: list[dict[str, Any]] = []
    for y0, y1 in raw_bands:
        band_height = y1 - y0 + 1
        if band_height < 12 or band_height > height * 0.28:
            continue
        band_ink = ink[y0:y1 + 1, :]
        columns = np.where(band_ink.mean(axis=0) > 0.0015)[0]
        if not len(columns):
            continue
        x0, x1 = int(columns[0]), int(columns[-1])
        band_width = x1 - x0 + 1
        if band_width < width * 0.06:
            continue
        density = float(band_ink.mean())
        pad_y = max(8, int(band_height * 0.45))
        pad_x = max(14, int(band_width * 0.035))
        box = (
            max(0, x0 - pad_x),
            max(0, y0 - pad_y),
            min(width, x1 + pad_x),
            min(height, y1 + pad_y),
        )
        score = candidate_score(box, height, width, density)
        if score >= min_score:
            candidates.append({
                "box": box,
                "detection_method": "raster_high_recall_scanned_page",
                "detection_score": round(score, 4),
                "candidate_text": "",
                "candidate_fonts": "",
                "ink_density": round(density, 6),
            })
    candidates.sort(key=lambda row: (row["box"][1], row["box"][0]))
    kept: list[dict[str, Any]] = []
    for row in candidates:
        if all(box_iou(row["box"], other["box"]) < 0.45 for other in kept):
            kept.append(row)
    return kept


def formula_line_score(text: str, fonts: list[str]) -> float:
    compact = " ".join(text.split())
    if len(compact) < 2:
        return -10.0
    strong = len(STRONG_MATH_RE.findall(compact))
    greek = len(GREEK_RE.findall(compact))
    operators = len(ASCII_OPERATOR_RE.findall(compact))
    functions = len(FUNCTION_RE.findall(compact))
    subscripts = len(SUBSCRIPT_RE.findall(compact))
    math_fonts = sum(bool(MATH_FONT_RE.search(font or "")) for font in fonts)
    words = re.findall(r"\b[A-Za-z]{3,}\b", compact)
    score = strong * 3.0 + greek * 1.5 + min(operators, 4) * 1.2
    score += functions * 2.0 + subscripts * 1.5 + min(math_fonts, 4) * 1.8
    if re.search(r"\b[A-Za-z]\s*\([^)]{1,80}\)", compact):
        score += 1.5
    if re.search(r"\d\s*[A-Za-z]|[A-Za-z]\s*\d", compact):
        score += 0.8
    if re.search(r"https?://|www\.|(?:\.com|\.org|\.edu|\.net)/", compact, re.I):
        score -= 10.0
    if re.fullmatch(r"[\w\s,;:.-]*(?:\d{1,4}/){1,2}\d{1,4}[\w\s,;:.-]*", compact):
        score -= 8.0
    if len(words) >= 8 and strong <= 1:
        score -= 6.0
    elif len(words) >= 5 and strong == 0 and operators < 2 and math_fonts == 0:
        score -= 3.0
    return score


def padded_pixel_box(
    bbox: tuple[float, float, float, float],
    page_rect: fitz.Rect,
    width: int,
    height: int,
    *,
    pad_x_ratio: float = 0.08,
    pad_y_ratio: float = 0.22,
    min_pad_x: int = 18,
    min_pad_y: int = 6,
) -> tuple[int, int, int, int]:
    sx = width / max(page_rect.width, 1)
    sy = height / max(page_rect.height, 1)
    x0, y0, x1, y1 = bbox
    # Padding is applied only after neighbouring fragments have been merged.
    # Text candidates need horizontal safety, but excessive vertical padding
    # was shown by the v2 audit to pull adjacent prose into the OCR crop.
    pad_x = max(min_pad_x, int((x1 - x0) * sx * pad_x_ratio))
    pad_y = max(min_pad_y, int((y1 - y0) * sy * pad_y_ratio))
    return (
        max(0, int(x0 * sx) - pad_x),
        max(0, int(y0 * sy) - pad_y),
        min(width, int(math.ceil(x1 * sx)) + pad_x),
        min(height, int(math.ceil(y1 * sy)) + pad_y),
    )


def sliced_span(
    span: dict[str, Any],
    start: int,
    end: int,
) -> dict[str, Any]:
    """Return an LTR text-span slice with an approximately matching bbox."""
    text = str(span.get("text", ""))
    start = max(0, min(start, len(text)))
    end = max(start, min(end, len(text)))
    clone = dict(span)
    clone["text"] = text[start:end]
    bbox = tuple(float(value) for value in span.get("bbox", (0, 0, 0, 0)))
    if len(text) and bbox[2] > bbox[0]:
        width = bbox[2] - bbox[0]
        clone["bbox"] = (
            bbox[0] + width * start / len(text),
            bbox[1],
            bbox[0] + width * end / len(text),
            bbox[3],
        )
    return clone


def prepared_formula_line(
    spans: list[dict[str, Any]],
) -> tuple[list[dict[str, Any]], str, str, str]:
    """Remove separately positioned equation numbers/prose from an OCR crop.

    The removed material remains in provenance fields, so this is a reversible
    OCR-boundary refinement rather than silent source modification.
    """
    kept = [dict(span) for span in spans if str(span.get("text", "")).strip()]
    equation_number = ""
    context_after = ""

    if kept:
        first_text = str(kept[0].get("text", ""))
        leading = LEADING_ANSWER_LABEL_RE.match(first_text)
        if leading and leading.end() < len(first_text):
            proposed = sliced_span(kept[0], leading.end(), len(first_text))
            proposed_text = str(proposed.get("text", "")).strip()
            proposed_fonts = [str(proposed.get("font", ""))]
            if formula_line_score(proposed_text, proposed_fonts) >= 3.0:
                kept[0] = proposed

    if kept:
        last_text = str(kept[-1].get("text", ""))
        trailing_number = TRAILING_EQUATION_NUMBER_RE.search(last_text)
        if trailing_number and trailing_number.start() > 0:
            prefix = last_text[:trailing_number.start()].rstrip()
            if prefix:
                equation_number = trailing_number.group(1).strip()
                kept[-1] = sliced_span(kept[-1], 0, len(prefix))

    if len(kept) >= 2 and EQUATION_NUMBER_RE.fullmatch(str(kept[-1].get("text", ""))):
        equation_number = str(kept[-1].get("text", "")).strip()
        kept = kept[:-1]
    for index, span in enumerate(kept[1:], 1):
        span_text = str(span.get("text", ""))
        if CONTEXT_CONNECTOR_RE.match(span_text):
            context_after = "".join(
                f" {str(item.get('text', '')).strip()}"
                for item in kept[index:]
            ).strip()
            kept = kept[:index]
            break

    if not context_after:
        for index, span in enumerate(kept):
            span_text = str(span.get("text", ""))
            connector = INLINE_CONTEXT_CONNECTOR_RE.search(span_text)
            if connector is None:
                continue
            prefix_span = sliced_span(span, 0, connector.start())
            proposed = [
                *kept[:index],
                prefix_span,
            ]
            proposed_text = " ".join(
                "".join(str(item.get("text", "")) for item in proposed).split()
            )
            proposed_fonts = [
                str(item.get("font", "")) for item in proposed
            ]
            if formula_line_score(proposed_text, proposed_fonts) >= 3.0:
                context_after = "".join(
                    [
                        span_text[connector.start():],
                        *(
                            f" {str(item.get('text', '')).strip()}"
                            for item in kept[index + 1:]
                        ),
                    ]
                ).strip()
                kept = proposed
                break

    if not context_after and kept:
        last_text = str(kept[-1].get("text", ""))
        for sentence_end in re.finditer(r"\.\s+(?=[A-Z])", last_text):
            prefix = last_text[:sentence_end.start() + 1]
            suffix = last_text[sentence_end.end():]
            if (
                STRONG_MATH_RE.search(prefix)
                and len(re.findall(r"\b[A-Za-z]{3,}\b", suffix)) >= 4
            ):
                context_after = suffix.strip()
                kept[-1] = sliced_span(kept[-1], 0, len(prefix))
                break
    # Preserve word boundaries across PDF spans.  v3.1 concatenated adjacent
    # spans directly, turning ordinary prose into one long token and allowing
    # it to evade the prose filter whenever an inline "=" was present.
    formula_text = " ".join(
        str(span.get("text", "")).strip()
        for span in kept
        if str(span.get("text", "")).strip()
    )
    original_text = " ".join(
        str(span.get("text", "")).strip()
        for span in spans
        if str(span.get("text", "")).strip()
    )
    inferred_context = (
        original_text[len(formula_text):].strip()
        if not equation_number and original_text.startswith(formula_text)
        else ""
    )
    return kept, formula_text, equation_number, context_after or inferred_context


def spans_bbox(spans: list[dict[str, Any]], fallback: tuple[float, ...]) -> tuple[float, float, float, float]:
    boxes = [
        tuple(float(value) for value in span.get("bbox", (0, 0, 0, 0)))
        for span in spans
    ]
    valid = [box for box in boxes if box[2] > box[0] and box[3] > box[1]]
    if not valid:
        return tuple(float(value) for value in fallback)  # type: ignore[return-value]
    return (
        min(box[0] for box in valid),
        min(box[1] for box in valid),
        max(box[2] for box in valid),
        max(box[3] for box in valid),
    )


def bbox_union(boxes: list[tuple[float, float, float, float]]) -> tuple[float, float, float, float]:
    return (
        min(box[0] for box in boxes),
        min(box[1] for box in boxes),
        max(box[2] for box in boxes),
        max(box[3] for box in boxes),
    )


def _interval_overlap(left0: float, left1: float, right0: float, right1: float) -> float:
    return max(0.0, min(left1, right1) - max(left0, right0))


def _interval_gap(left0: float, left1: float, right0: float, right1: float) -> float:
    if left1 < right0:
        return right0 - left1
    if right1 < left0:
        return left0 - right1
    return 0.0


def _line_support_eligible(record: dict[str, Any]) -> bool:
    text = str(record.get("text", ""))
    if not text or re.search(r"https?://|www\.", text, re.I):
        return False
    prose_words = len(re.findall(r"\b[A-Za-z]{3,}\b", text))
    fonts = list(record.get("fonts", []))
    return bool(
        float(record.get("score", -10.0)) >= 0.0
        or any(MATH_FONT_RE.search(font or "") for font in fonts)
        or (
            prose_words <= 2
            and (
                STRONG_MATH_RE.search(text)
                or ASCII_OPERATOR_RE.search(text)
                or SUBSCRIPT_RE.search(text)
            )
        )
    )


def should_merge_text_lines(
    left: dict[str, Any],
    right: dict[str, Any],
    page_rect: fitz.Rect,
) -> bool:
    """Conservatively join PDF text fragments belonging to one formula.

    Same-baseline fragments are joined across a short horizontal gap.  A very
    small vertical gap is also allowed for fraction/superscript fragments.
    Consecutive full-width display equations are deliberately not joined.
    """
    lx0, ly0, lx1, ly1 = left["bbox"]
    rx0, ry0, rx1, ry1 = right["bbox"]
    lw, lh = max(0.1, lx1 - lx0), max(0.1, ly1 - ly0)
    rw, rh = max(0.1, rx1 - rx0), max(0.1, ry1 - ry0)
    vertical_overlap = _interval_overlap(ly0, ly1, ry0, ry1)
    horizontal_overlap = _interval_overlap(lx0, lx1, rx0, rx1)
    horizontal_gap = _interval_gap(lx0, lx1, rx0, rx1)
    vertical_gap = _interval_gap(ly0, ly1, ry0, ry1)
    left_relations = len(STRONG_MATH_RE.findall(str(left.get("text", ""))))
    right_relations = len(STRONG_MATH_RE.findall(str(right.get("text", ""))))
    both_have_relations = left_relations >= 1 and right_relations >= 1
    left_text = str(left.get("text", ""))
    right_text = str(right.get("text", ""))

    same_baseline = (
        vertical_overlap / min(lh, rh) >= 0.42
        and horizontal_gap <= max(16.0, page_rect.width * 0.025)
        # Two self-contained relations on the same printed row are normally
        # separate exercise answers/formulas, not fragments of one formula.
        and not both_have_relations
    )
    # Repair a split formula boundary before classification.  PDF generators
    # frequently store the left side, relation sign and right side in separate
    # spans with a slightly larger gap than ordinary adjacent fragments.  The
    # wider allowance is restricted to an explicit open relation boundary so
    # unrelated exercise answers on the same row are not joined.
    relation_boundary_repair = (
        vertical_overlap / min(lh, rh) >= 0.55
        and horizontal_gap <= max(24.0, page_rect.width * 0.06)
        and (max(lx1, rx1) - min(lx0, rx0)) <= page_rect.width * 0.62
        and (
            TRAILING_RELATION_FRAGMENT_RE.search(left_text)
            or LEADING_RELATION_FRAGMENT_RE.search(right_text)
        )
        and _line_support_eligible(left)
        and _line_support_eligible(right)
    )
    # Some publishers wrap a display equation after the relation sign.  The
    # two rows do not overlap vertically, so the same-baseline repair above
    # cannot join them.  Only an explicitly open relation boundary is allowed
    # to use this narrow vertical continuation rule.
    vertical_relation_continuation = (
        vertical_gap <= max(10.0, max(lh, rh) * 0.85)
        and (
            horizontal_overlap / min(lw, rw) >= 0.20
            or abs(lx0 - rx0) <= max(16.0, page_rect.width * 0.025)
        )
        and (max(lx1, rx1) - min(lx0, rx0)) <= page_rect.width * 0.72
        and (
            TRAILING_RELATION_FRAGMENT_RE.search(left_text)
            or LEADING_RELATION_FRAGMENT_RE.search(right_text)
        )
        and _line_support_eligible(left)
        and _line_support_eligible(right)
    )
    # Matrix bracket glyphs are commonly emitted as narrow PDF spans while
    # the entries are separate neighbouring spans.  Merge only near a known
    # matrix boundary glyph, preserving normal display-equation separation.
    matrix_boundary_repair = (
        bool(MATRIX_BOUNDARY_GLYPH_RE.search(left_text + right_text))
        and horizontal_gap <= max(30.0, page_rect.width * 0.10)
        and vertical_gap <= max(12.0, max(lh, rh) * 0.90)
        and (max(lx1, rx1) - min(lx0, rx0)) <= page_rect.width * 0.68
        and _line_support_eligible(left)
        and _line_support_eligible(right)
    )
    stacked_fragment = (
        horizontal_overlap / min(lw, rw) >= 0.35
        and vertical_gap <= max(2.5, min(5.0, max(lh, rh) * 0.20))
        and max(lw, rw) <= page_rect.width * 0.48
        and not both_have_relations
    )
    compact_stack = (
        horizontal_overlap / min(lw, rw) >= 0.18
        and abs((lx0 + lx1) / 2.0 - (rx0 + rx1) / 2.0)
        <= max(12.0, max(lw, rw) * 0.30)
        and vertical_gap <= max(9.0, max(lh, rh) * 0.72)
        and max(lw, rw) <= page_rect.width * 0.24
        and not both_have_relations
        and len(re.findall(r"\b[A-Za-z]{3,}\b", str(left.get("text", "")))) <= 1
        and len(re.findall(r"\b[A-Za-z]{3,}\b", str(right.get("text", "")))) <= 1
    )
    return bool(
        same_baseline
        or relation_boundary_repair
        or vertical_relation_continuation
        or matrix_boundary_repair
        or stacked_fragment
        or compact_stack
    )


def is_compact_math_stack(
    group: list[dict[str, Any]],
    page_rect: fitz.Rect,
) -> bool:
    if len(group) < 2:
        return False
    boxes = [record["bbox"] for record in group]
    widths = [max(0.1, box[2] - box[0]) for box in boxes]
    math_font_records = sum(
        any(MATH_FONT_RE.search(font or "") for font in record.get("fonts", []))
        for record in group
    )
    relation_records = sum(
        bool(STRONG_MATH_RE.search(str(record.get("text", ""))))
        for record in group
    )
    prose_words = sum(
        len(re.findall(r"\b[A-Za-z]{3,}\b", str(record.get("text", ""))))
        for record in group
    )
    vertical_centers = [
        (box[1] + box[3]) / 2.0
        for box in boxes
    ]
    return bool(
        max(widths) <= page_rect.width * 0.24
        and math_font_records >= 2
        and relation_records <= 1
        and prose_words <= 2
        and max(vertical_centers) - min(vertical_centers) >= 2.0
    )


def merge_text_line_records(
    records: list[dict[str, Any]],
    page_rect: fitz.Rect,
    min_score: float,
) -> list[dict[str, Any]]:
    """Merge eligible neighbouring text fragments, retaining full provenance."""
    if not records:
        return []
    parent = list(range(len(records)))

    def find(index: int) -> int:
        while parent[index] != index:
            parent[index] = parent[parent[index]]
            index = parent[index]
        return index

    def union(left_index: int, right_index: int) -> None:
        left_root, right_root = find(left_index), find(right_index)
        if left_root != right_root:
            parent[right_root] = left_root

    eligible = [
        float(record["score"]) >= min_score or _line_support_eligible(record)
        for record in records
    ]
    ordered = sorted(range(len(records)), key=lambda index: records[index]["bbox"][1])
    vertical_window = max(20.0, page_rect.height * 0.03)
    for ordered_no, left_index in enumerate(ordered):
        if not eligible[left_index]:
            continue
        left = records[left_index]
        for right_index in ordered[ordered_no + 1:]:
            right = records[right_index]
            if right["bbox"][1] - left["bbox"][3] > vertical_window:
                break
            if eligible[right_index] and should_merge_text_lines(left, right, page_rect):
                union(left_index, right_index)

    groups: dict[int, list[dict[str, Any]]] = {}
    for index, record in enumerate(records):
        groups.setdefault(find(index), []).append(record)

    merged: list[dict[str, Any]] = []
    for group in groups.values():
        compact_stack = is_compact_math_stack(group, page_rect)
        if not (
            any(float(record["score"]) >= min_score for record in group)
            or compact_stack
        ):
            continue
        ordered_group = sorted(
            group,
            key=lambda record: (
                round((record["bbox"][1] + record["bbox"][3]) / 8.0),
                record["bbox"][0],
                record["bbox"][1],
            ),
        )
        separator = " / " if compact_stack else " "
        text = separator.join(
            str(record["text"]).strip()
            for record in ordered_group
            if str(record["text"]).strip()
        )
        fonts = sorted({
            str(font)
            for record in ordered_group
            for font in record.get("fonts", [])
            if str(font)
        })
        combined_score = formula_line_score(text, fonts)
        # The presence of an original high-scoring seed protects compact
        # superscript/fraction fragments whose concatenated text order is not
        # semantically perfect.
        detection_score = max(
            combined_score,
            max(float(record["score"]) for record in ordered_group),
            min_score if compact_stack else -10.0,
        )
        merged.append({
            "bbox": bbox_union([record["bbox"] for record in ordered_group]),
            "text": text,
            "original_text": " ".join(
                str(record["original_text"]).strip()
                for record in ordered_group
                if str(record["original_text"]).strip()
            ),
            "fonts": fonts,
            "score": detection_score,
            "equation_number": " ".join(
                str(record.get("equation_number", "")).strip()
                for record in ordered_group
                if str(record.get("equation_number", "")).strip()
            ),
            "context_after": " ".join(
                str(record.get("context_after", "")).strip()
                for record in ordered_group
                if str(record.get("context_after", "")).strip()
            ),
            "source_line_count": len(ordered_group),
            "merge_reason": (
                "compact_vertical_math_stack"
                if compact_stack
                else (
                    "adjacent_text_fragments"
                    if len(ordered_group) > 1
                    else "single_text_line"
                )
            ),
        })
    return sorted(merged, key=lambda record: (record["bbox"][1], record["bbox"][0]))


def nearby_text_context(
    bbox: tuple[float, float, float, float],
    records: list[dict[str, Any]],
    page_rect: fitz.Rect,
) -> str:
    """Return nearby text used only to reject obvious figures/tables."""
    x0, y0, x1, y1 = bbox
    width = max(1.0, x1 - x0)
    matches: list[tuple[float, str]] = []
    for record in records:
        rx0, ry0, rx1, ry1 = record["bbox"]
        vertical_gap = _interval_gap(y0, y1, ry0, ry1)
        horizontal_overlap = _interval_overlap(x0, x1, rx0, rx1)
        if vertical_gap > max(42.0, page_rect.height * 0.055):
            continue
        if horizontal_overlap / min(width, max(1.0, rx1 - rx0)) < 0.12:
            continue
        text = str(record.get("original_text", "")).strip()
        if text:
            matches.append((vertical_gap, text))
    return " ".join(text for _, text in sorted(matches)[:3])[:1000]


def candidate_position(
    box: tuple[int, int, int, int],
    width: int,
    height: int,
) -> dict[str, float]:
    x0, y0, x1, y1 = box
    return {
        "x0_ratio": round(x0 / max(width, 1), 6),
        "y0_ratio": round(y0 / max(height, 1), 6),
        "x1_ratio": round(x1 / max(width, 1), 6),
        "y1_ratio": round(y1 / max(height, 1), 6),
        "center_y_ratio": round(((y0 + y1) / 2.0) / max(height, 1), 6),
        "width_ratio": round((x1 - x0) / max(width, 1), 6),
        "height_ratio": round((y1 - y0) / max(height, 1), 6),
    }


def deduplicate_candidates(candidates: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """Resolve overlapping detector outputs without discarding text evidence."""
    method_priority = {
        "pdf_text_math_layout": 3,
        "embedded_image_region": 2,
        "raster_high_recall_scanned_page": 1,
    }
    kept: list[dict[str, Any]] = []
    for row in sorted(candidates, key=lambda item: (item["box"][1], item["box"][0])):
        overlaps = [
            index
            for index, other in enumerate(kept)
            if box_iou(row["box"], other["box"]) >= 0.55
        ]
        if not overlaps:
            kept.append(row)
            continue
        best_existing = max(
            overlaps,
            key=lambda index: (
                method_priority.get(str(kept[index]["detection_method"]), 0),
                float(kept[index].get("detection_score", 0.0)),
            ),
        )
        row_rank = (
            method_priority.get(str(row["detection_method"]), 0),
            float(row.get("detection_score", 0.0)),
        )
        existing_rank = (
            method_priority.get(str(kept[best_existing]["detection_method"]), 0),
            float(kept[best_existing].get("detection_score", 0.0)),
        )
        if row_rank > existing_rank:
            kept = [
                other
                for index, other in enumerate(kept)
                if index not in set(overlaps)
            ]
            kept.append(row)
    return sorted(kept, key=lambda item: (item["box"][1], item["box"][0]))


def vector_candidates(page: fitz.Page, image: Image.Image, min_score: float) -> tuple[list[dict[str, Any]], int]:
    page_dict = page.get_text("dict")
    text_chars = 0
    candidates: list[dict[str, Any]] = []
    line_records: list[dict[str, Any]] = []
    image_blocks: list[tuple[float, float, float, float]] = []
    for block in page_dict.get("blocks", []):
        if int(block.get("type", 0)) == 1:
            x0, y0, x1, y1 = block.get("bbox", (0, 0, 0, 0))
            bw = x1 - x0
            bh = y1 - y0
            if bw >= page.rect.width * 0.08 and 5 <= bh <= page.rect.height * 0.25:
                image_blocks.append((float(x0), float(y0), float(x1), float(y1)))
            continue
        for line in block.get("lines", []):
            spans = line.get("spans", [])
            original_text = "".join(str(span.get("text", "")) for span in spans)
            text_chars += len(original_text.strip())
            prepared_spans, text, equation_number, context_after = prepared_formula_line(spans)
            fonts = [str(span.get("font", "")) for span in prepared_spans]
            score = formula_line_score(text, fonts)
            if not text:
                continue
            bbox = spans_bbox(prepared_spans, tuple(line.get("bbox", (0, 0, 0, 0))))
            line_records.append({
                "bbox": bbox,
                "text": text,
                "original_text": " ".join(original_text.split())[:1000],
                "fonts": fonts,
                "score": score,
                "equation_number": equation_number,
                "context_after": context_after,
            })

    for record in merge_text_line_records(line_records, page.rect, min_score):
        candidates.append({
                "box": padded_pixel_box(record["bbox"], page.rect, image.width, image.height),
                "detection_method": "pdf_text_math_layout",
                "detection_score": round(float(record["score"]), 4),
                "candidate_text": " ".join(str(record["text"]).split())[:1000],
                "candidate_original_text": " ".join(
                    str(record["original_text"]).split()
                )[:2000],
                "candidate_fonts": ";".join(record["fonts"])[:1000],
                "equation_number": str(record["equation_number"])[:500],
                "context_after_text_layer": str(record["context_after"])[:1000],
                "candidate_context_text": "",
                "source_line_count": int(record["source_line_count"]),
                "merge_reason": str(record["merge_reason"]),
                "ink_density": "",
            })

    for bbox in image_blocks:
        candidates.append({
            "box": padded_pixel_box(
                bbox,
                page.rect,
                image.width,
                image.height,
                pad_x_ratio=0.01,
                pad_y_ratio=0.02,
                min_pad_x=4,
                min_pad_y=4,
            ),
            "detection_method": "embedded_image_region",
            "detection_score": 3.0,
            "candidate_text": "",
            "candidate_original_text": "",
            "candidate_fonts": "",
            "equation_number": "",
            "context_after_text_layer": "",
            "candidate_context_text": nearby_text_context(
                bbox, line_records, page.rect
            ),
            "source_line_count": 0,
            "merge_reason": "embedded_image_exact_boundary",
            "ink_density": "",
        })
    return deduplicate_candidates(candidates), text_chars


def page_marker_valid(path: Path) -> bool:
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
        return (
            value.get("schema") == "ebook-page-record-v3.5"
            and
            value.get("status") == "complete"
            and not value.get("page_error")
            and all(Path(row["image_path"]).is_file() for row in value.get("candidates", []))
            and all(
                Path(row["image_path"]).is_file()
                for row in value.get("rejected_candidates", [])
            )
        )
    except Exception:
        return False


def process_book(task: dict[str, Any]) -> dict[str, Any]:
    pdf_path = Path(task["pdf_path"])
    output_dir = Path(task["output_dir"])
    marker_dir = output_dir / "page_records" / task["book_id"]
    crop_dir = output_dir / "candidate_images" / task["book_id"]
    rejected_crop_dir = output_dir / "rejected_candidate_images" / task["book_id"]
    marker_dir.mkdir(parents=True, exist_ok=True)
    crop_dir.mkdir(parents=True, exist_ok=True)
    rejected_crop_dir.mkdir(parents=True, exist_ok=True)
    document = fitz.open(pdf_path)
    candidate_total = rejected_total = detected_total = page_errors = 0
    started = time.time()
    for page_index in range(document.page_count):
        marker = marker_dir / f"page_{page_index + 1:05d}.json"
        if page_marker_valid(marker):
            previous = json.loads(marker.read_text(encoding="utf-8"))
            candidate_total += len(previous.get("candidates", []))
            rejected_total += len(previous.get("rejected_candidates", []))
            detected_total += int(
                previous.get(
                    "detected_candidate_count",
                    len(previous.get("candidates", []))
                    + len(previous.get("rejected_candidates", [])),
                )
            )
            continue
        try:
            page = document[page_index]
            image = render_page(page, int(task["dpi"]))
            candidates, text_chars = vector_candidates(page, image, float(task["min_vector_score"]))
            if text_chars < int(task["scanned_text_threshold"]):
                candidates.extend(
                    raster_candidate_bands(image, float(task["min_raster_score"]))
                )
            deduped = deduplicate_candidates(candidates)

            page_rows = []
            rejected_rows = []
            for candidate_number, candidate in enumerate(deduped, 1):
                box = tuple(int(value) for value in candidate["box"])
                locator = (
                    f"{task['relative_path']}#page={page_index + 1}"
                    f"&candidate={candidate_number}&bbox={','.join(map(str, box))}"
                )
                candidate_id = stable_id("EBOOKC", locator, length=24)
                crop = image.crop(box)
                filter_result = classify_candidate(
                    text=str(candidate.get("candidate_text", "")),
                    fonts=str(candidate.get("candidate_fonts", "")),
                    image=crop,
                    method=str(candidate["detection_method"]),
                    context_text=str(candidate.get("candidate_context_text", "")),
                    position=candidate_position(box, image.width, image.height),
                    merge_reason=str(candidate.get("merge_reason", "")),
                    source_line_count=int(candidate.get("source_line_count", 1)),
                )
                accepted = filter_result["decision"] != "rejected_pre_ocr"
                formula_id = stable_id("EBOOKF", locator, length=24) if accepted else ""
                image_name = (
                    f"p{page_index + 1:05d}_c{candidate_number:03d}_"
                    f"{candidate_id[-8:]}.png"
                )
                crop_path = (crop_dir if accepted else rejected_crop_dir) / image_name
                crop.save(crop_path)
                common_row = {
                    "candidate_id": candidate_id,
                    "formula_id": formula_id,
                    "source_id": task["book_id"],
                    "book_id": task["book_id"],
                    "book_sha256": task["pdf_sha256"],
                    "image_path": str(crop_path.resolve()),
                    "image_name": image_name,
                    "image_relative_path": locator,
                    "archive_name": "LOCAL_EBOOK_PDF",
                    "archive_member": locator,
                    "source_dir": task["relative_path"],
                    "source_file": task["relative_path"],
                    "source_identifier": task["book_id"],
                    "metadata_json_path": str(pdf_path.resolve()),
                    "metadata_status": "pdf_embedded_metadata",
                    "title": task["title"],
                    "authors": task["authors"],
                    "journal_or_venue": "电子书/教材",
                    "year": task["year"],
                    "doi": task["doi"],
                    "page": page_index + 1,
                    "page_number": page_index + 1,
                    "page_index": page_index,
                    "page_provenance_status": "exact_pdf_page",
                    "candidate_number": candidate_number,
                    "candidate_bbox": list(box),
                    "candidate_text_layer": candidate["candidate_text"],
                    "candidate_original_text_layer": candidate.get(
                        "candidate_original_text", candidate["candidate_text"]
                    ),
                    "candidate_fonts": candidate["candidate_fonts"],
                    "equation_number_text_layer": candidate.get("equation_number", ""),
                    "context_after_text_layer": candidate.get("context_after_text_layer", ""),
                    "candidate_context_text_layer": candidate.get(
                        "candidate_context_text", ""
                    ),
                    "candidate_source_line_count": candidate.get(
                        "source_line_count", 0
                    ),
                    "candidate_merge_reason": candidate.get(
                        "merge_reason", ""
                    ),
                    "candidate_position_json": json.dumps(
                        candidate_position(box, image.width, image.height),
                        ensure_ascii=False,
                        sort_keys=True,
                    ),
                    "candidate_detection_method": candidate["detection_method"],
                    "candidate_detection_score": candidate["detection_score"],
                    "candidate_ink_density": candidate["ink_density"],
                    "pre_ocr_filter_decision": filter_result["decision"],
                    "pre_ocr_filter_reason": filter_result["reason"],
                    "pre_ocr_filter_score": filter_result["score"],
                    "pre_ocr_text_features_json": json.dumps(
                        filter_result.get("text_features", filter_result.get("features", {})),
                        ensure_ascii=False,
                        sort_keys=True,
                    ),
                    "pre_ocr_visual_features_json": json.dumps(
                        filter_result.get("visual_features", filter_result.get("features", {})),
                        ensure_ascii=False,
                        sort_keys=True,
                    ),
                    "page_text_characters": text_chars,
                    "extraction_method": (
                        "ebook_pdf_full_page_boundary_refined_detection_v3_5_prefiltered"
                    ),
                    "provenance_locator": locator,
                }
                (page_rows if accepted else rejected_rows).append(common_row)
            atomic_json(marker, {
                "schema": "ebook-page-record-v3.5",
                "status": "complete",
                "book_id": task["book_id"],
                "page": page_index + 1,
                "page_text_characters": text_chars,
                "detected_candidate_count": len(deduped),
                "candidate_count": len(page_rows),
                "rejected_candidate_count": len(rejected_rows),
                "accepted_high_confidence_count": sum(
                    row["pre_ocr_filter_decision"] == "accepted_high_confidence"
                    for row in page_rows
                ),
                "accepted_review_count": sum(
                    row["pre_ocr_filter_decision"] == "accepted_review"
                    for row in page_rows
                ),
                "candidates": page_rows,
                "rejected_candidates": rejected_rows,
            })
            candidate_total += len(page_rows)
            rejected_total += len(rejected_rows)
            detected_total += len(deduped)
        except Exception as exc:
            page_errors += 1
            atomic_json(marker, {
                "schema": "ebook-page-record-v3.5",
                "status": "complete",
                "book_id": task["book_id"],
                "page": page_index + 1,
                "detected_candidate_count": 0,
                "candidate_count": 0,
                "rejected_candidate_count": 0,
                "candidates": [],
                "rejected_candidates": [],
                "page_error": repr(exc),
            })
        if (page_index + 1) % 50 == 0 or page_index + 1 == document.page_count:
            print(
                f"[extract] book={task['book_no']:02d} page={page_index + 1}/{document.page_count} "
                f"detected={detected_total} accepted={candidate_total} "
                f"rejected={rejected_total} errors={page_errors}",
                flush=True,
            )
    document.close()
    result = {
        "book_id": task["book_id"],
        "pages": task["total_pages"],
        "detected_candidates": detected_total,
        "candidates": candidate_total,
        "rejected_candidates": rejected_total,
        "page_errors": page_errors,
        "seconds": round(time.time() - started, 2),
    }
    atomic_json(output_dir / "book_records" / f"{task['book_id']}.complete.json", result)
    return result


def pdf_catalog(ebook_root: Path) -> list[dict[str, Any]]:
    rows = []
    for book_no, path in enumerate(sorted(ebook_root.rglob("*.pdf")), 1):
        relative = path.relative_to(ebook_root).as_posix()
        with fitz.open(path) as document:
            metadata = document.metadata or {}
            total_pages = document.page_count
        title = str(metadata.get("title") or path.stem).strip()
        authors = str(metadata.get("author") or "").strip()
        date_text = " ".join(str(metadata.get(key) or "") for key in ("creationDate", "modDate", "subject"))
        year_match = re.search(r"(?:19|20)\d{2}", date_text)
        rows.append({
            "book_no": book_no,
            "book_id": stable_id("EBOOK", relative, length=16),
            "relative_path": relative,
            "pdf_path": str(path.resolve()),
            "file_name": path.name,
            "title": title,
            "authors": authors,
            "subject": str(metadata.get("subject") or ""),
            "keywords": str(metadata.get("keywords") or ""),
            "creator": str(metadata.get("creator") or ""),
            "producer": str(metadata.get("producer") or ""),
            "creation_date": str(metadata.get("creationDate") or ""),
            "modification_date": str(metadata.get("modDate") or ""),
            "year": year_match.group(0) if year_match else "",
            "doi": "",
            "total_pages": total_pages,
            "file_bytes": path.stat().st_size,
            "pdf_sha256": sha256_file(path),
        })
    return rows


def write_csv(path: Path, rows: list[dict[str, Any]]) -> None:
    fields = sorted({key for row in rows for key in row}) if rows else []
    temporary = path.with_suffix(path.suffix + ".part")
    with temporary.open("w", encoding="utf-8-sig", newline="") as handle:
        def encoded(value: object) -> str:
            text = "" if value is None else str(value)
            return '"' + text.replace('"', '""') + '"'

        handle.write(",".join(encoded(field) for field in fields) + "\n")
        for row in rows:
            handle.write(",".join(encoded(row.get(field, "")) for field in fields) + "\n")
    os.replace(temporary, path)


def write_jsonl(path: Path, rows: list[dict[str, Any]]) -> str:
    digest = hashlib.sha256()
    with path.open("w", encoding="utf-8", newline="\n") as handle:
        for row in rows:
            line = json.dumps(row, ensure_ascii=False, separators=(",", ":")) + "\n"
            digest.update(line.encode("utf-8"))
            handle.write(line)
    return digest.hexdigest()


def consolidate(output_dir: Path, catalog: list[dict[str, Any]], shard_size: int, seed: int) -> dict:
    page_rows: list[dict[str, Any]] = []
    index_rows: list[dict[str, Any]] = []
    rejected_rows: list[dict[str, Any]] = []
    page_errors: list[dict[str, Any]] = []
    book_number_by_id = {
        str(book["book_id"]): int(book["book_no"]) for book in catalog
    }
    for book in catalog:
        marker_dir = output_dir / "page_records" / book["book_id"]
        markers = sorted(marker_dir.glob("page_*.json"))
        if len(markers) != int(book["total_pages"]):
            raise SystemExit(
                f"Incomplete page extraction for {book['file_name']}: "
                f"{len(markers)}/{book['total_pages']}"
            )
        for marker_path in markers:
            marker = json.loads(marker_path.read_text(encoding="utf-8"))
            if marker.get("page_error"):
                page_errors.append({
                    "book_id": book["book_id"],
                    "file_name": book["file_name"],
                    "page": marker.get("page", ""),
                    "page_error": marker["page_error"],
                })
            page_rows.append({
                "book_no": book["book_no"],
                "book_id": book["book_id"],
                "title": book["title"],
                "page": marker["page"],
                "status": "page_error" if marker.get("page_error") else (
                    "candidate_found" if marker.get("candidate_count", 0) else "no_candidate"
                ),
                "detected_candidate_count": marker.get(
                    "detected_candidate_count",
                    marker.get("candidate_count", 0)
                    + marker.get("rejected_candidate_count", 0),
                ),
                "candidate_count": marker.get("candidate_count", 0),
                "rejected_candidate_count": marker.get("rejected_candidate_count", 0),
                "accepted_high_confidence_count": marker.get(
                    "accepted_high_confidence_count", 0
                ),
                "accepted_review_count": marker.get("accepted_review_count", 0),
                "page_text_characters": marker.get("page_text_characters", ""),
                "page_error": marker.get("page_error", ""),
            })
            index_rows.extend(marker.get("candidates", []))
            rejected_rows.extend(marker.get("rejected_candidates", []))
    if page_errors:
        write_csv(output_dir / "page_extraction_errors.csv", page_errors)
        raise SystemExit(
            f"Page extraction is incomplete: {len(page_errors)} page errors. "
            "Rerun to retry them, then inspect page_extraction_errors.csv if they persist."
        )
    index_rows.sort(key=lambda row: (
        book_number_by_id[str(row["book_id"])],
        int(row["page"]),
        int(row["candidate_number"]),
    ))
    rejected_rows.sort(key=lambda row: (
        book_number_by_id[str(row["book_id"])],
        int(row["page"]),
        int(row["candidate_number"]),
    ))
    for ordinal, row in enumerate(index_rows, 1):
        row["sample_no"] = ordinal
        row["image_index"] = ordinal
    if not index_rows:
        raise SystemExit("No formula candidates were detected; refusing to create an empty run")

    write_csv(output_dir / "ebook_book_catalog.csv", catalog)
    write_csv(output_dir / "ebook_page_candidate_summary.csv", page_rows)
    write_csv(output_dir / "ebook_formula_candidate_catalog.csv", index_rows)
    write_jsonl(output_dir / "candidate_index_all.jsonl", index_rows)
    write_csv(output_dir / "ebook_pre_ocr_rejected_catalog.csv", rejected_rows)
    write_jsonl(output_dir / "ebook_pre_ocr_rejected_catalog.jsonl", rejected_rows)

    detected_count = sum(int(row["detected_candidate_count"]) for row in page_rows)
    if detected_count != len(index_rows) + len(rejected_rows):
        raise SystemExit(
            "Candidate conservation check failed: "
            f"detected={detected_count}, accepted={len(index_rows)}, "
            f"rejected={len(rejected_rows)}"
        )
    decision_counts: dict[str, int] = {}
    reason_counts: dict[str, int] = {}
    for row in [*index_rows, *rejected_rows]:
        decision = str(row.get("pre_ocr_filter_decision", "unknown"))
        reason = str(row.get("pre_ocr_filter_reason", "unknown"))
        decision_counts[decision] = decision_counts.get(decision, 0) + 1
        reason_counts[reason] = reason_counts.get(reason, 0) + 1

    shard_dir = output_dir / "shards"
    shard_dir.mkdir(exist_ok=True)
    shards = []
    for shard_no, start in enumerate(range(0, len(index_rows), shard_size), 1):
        rows = index_rows[start:start + shard_size]
        path = shard_dir / f"ebook_formula_index_shard_{shard_no:06d}.jsonl"
        digest = write_jsonl(path, rows)
        shards.append({
            "path": str(path.resolve()),
            "records": len(rows),
            "sha256": digest,
        })
    manifest = {
        "schema": "ebook-formula-corpus-execution-manifest-v3.5",
        "sampling_unit": "detected_formula_region",
        "selection": (
            "all_pages_fragment_merged_detection_then_auditable_pre_ocr_filter_"
            "no_per_page_or_per_book_count_cap"
        ),
        "scope_note": (
            "Every PDF page is scanned. Candidate completeness is bounded by the documented "
            "layout detector and pre-OCR filter; rejected regions remain in a separate audit "
            "catalog with crops and reason codes. No semantic detector can guarantee recall "
            "of every printed formula."
        ),
        "seed": seed,
        "ebook_root": str(Path(catalog[0]["pdf_path"]).parent if catalog else ""),
        "book_count": len(catalog),
        "page_count": sum(int(row["total_pages"]) for row in catalog),
        "population": detected_count,
        "detected_candidate_count": detected_count,
        "sample_count": len(index_rows),
        "pre_ocr_accepted_count": len(index_rows),
        "pre_ocr_rejected_count": len(rejected_rows),
        "pre_ocr_decision_counts": decision_counts,
        "pre_ocr_rejection_reason_counts": {
            key: value
            for key, value in sorted(reason_counts.items())
            if key and key != "unknown"
        },
        "candidate_conservation_check": {
            "detected": detected_count,
            "accepted_plus_rejected": len(index_rows) + len(rejected_rows),
            "passed": True,
        },
        "shard_size": shard_size,
        "shard_count": len(shards),
        "shards": shards,
        "books": [
            {
                "book_id": row["book_id"],
                "file_name": row["file_name"],
                "title": row["title"],
                "total_pages": row["total_pages"],
                "pdf_sha256": row["pdf_sha256"],
            }
            for row in catalog
        ],
    }
    atomic_json(output_dir / "execution_manifest.json", manifest)
    return manifest


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--ebook-root", required=True)
    parser.add_argument("--output-dir", required=True)
    parser.add_argument("--dpi", type=int, default=200)
    parser.add_argument("--extract-workers", type=int, default=4)
    parser.add_argument("--shard-size", type=int, default=1000)
    parser.add_argument("--min-vector-score", type=float, default=3.0)
    parser.add_argument("--min-raster-score", type=float, default=1.5)
    parser.add_argument("--scanned-text-threshold", type=int, default=40)
    parser.add_argument("--seed", type=int, default=2026080302)
    args = parser.parse_args()

    ebook_root = Path(args.ebook_root).expanduser().resolve()
    output_dir = Path(args.output_dir).expanduser().resolve()
    output_dir.mkdir(parents=True, exist_ok=True)
    if args.extract_workers < 1 or args.shard_size < 1 or args.dpi < 100:
        raise SystemExit("extract-workers/shard-size must be positive and dpi must be >= 100")
    catalog = pdf_catalog(ebook_root)
    if not catalog:
        raise SystemExit(f"No PDF files found under {ebook_root}")

    config = {
        "schema": "ebook-index-build-config-v3.5",
        "ebook_root": str(ebook_root),
        "candidate_policy": (
            "boundary_repaired_detection_then_recall_safe_auditable_pre_ocr_filter_v3_5"
        ),
        "dpi": args.dpi,
        "min_vector_score": args.min_vector_score,
        "min_raster_score": args.min_raster_score,
        "scanned_text_threshold": args.scanned_text_threshold,
        "seed": args.seed,
        "books": [
            {
                "relative_path": row["relative_path"],
                "pdf_sha256": row["pdf_sha256"],
                "total_pages": row["total_pages"],
            }
            for row in catalog
        ],
    }
    config_path = output_dir / "index_build_config.json"
    if config_path.exists():
        previous = json.loads(config_path.read_text(encoding="utf-8"))
        if previous != config:
            raise SystemExit(
                "Existing index configuration/PDF fingerprints differ. "
                "Use a new output directory; do not mix runs."
            )
    else:
        atomic_json(config_path, config)

    tasks = []
    for row in catalog:
        tasks.append({
            **row,
            "output_dir": str(output_dir),
            "dpi": args.dpi,
            "min_vector_score": args.min_vector_score,
            "min_raster_score": args.min_raster_score,
            "scanned_text_threshold": args.scanned_text_threshold,
        })
    print(
        f"index_start books={len(catalog)} pages={sum(row['total_pages'] for row in catalog)} "
        f"extract_workers={args.extract_workers}",
        flush=True,
    )
    with ProcessPoolExecutor(max_workers=min(args.extract_workers, len(tasks))) as executor:
        futures = [executor.submit(process_book, task) for task in tasks]
        for future in as_completed(futures):
            print("book_complete=" + json.dumps(future.result(), ensure_ascii=False), flush=True)
    manifest = consolidate(output_dir, catalog, args.shard_size, args.seed)
    print(json.dumps(manifest, ensure_ascii=False, indent=2), flush=True)
    print(f"index_complete={output_dir / 'execution_manifest.json'}", flush=True)


if __name__ == "__main__":
    main()
