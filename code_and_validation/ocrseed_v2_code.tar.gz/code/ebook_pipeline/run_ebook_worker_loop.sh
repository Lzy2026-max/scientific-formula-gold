#!/usr/bin/env bash
set -euo pipefail

if [[ $# -ne 7 ]]; then
  echo "usage: $0 RUN_ROOT BASE_PACKAGE EXTENSION PYTHON SLOT GPU WORKER_COUNT" >&2
  exit 2
fi
RUN_ROOT=$1
BASE_PACKAGE=$2
EXTENSION=$3
PY=$4
SLOT=$5
GPU=$6
WORKER_COUNT=$7
MANIFEST="$RUN_ROOT/index/execution_manifest.json"
LOG_DIR="$RUN_ROOT/logs"

if [[ ! "$GPU" =~ ^[0-9]+$ ]]; then
  echo "GPU must be a physical GPU index, got: $GPU" >&2
  exit 3
fi
IFS=',' read -r -a FORBIDDEN_GPUS <<< "${FORBIDDEN_GPU_IDS:-}"
for FORBIDDEN in "${FORBIDDEN_GPUS[@]}"; do
  if [[ -n "$FORBIDDEN" && "$GPU" == "$FORBIDDEN" ]]; then
    echo "GPU $GPU is listed in FORBIDDEN_GPU_IDS" >&2
    exit 3
  fi
done
mkdir -p "$LOG_DIR" "$RUN_ROOT/workers/slot_${SLOT}"

mapfile -t SHARDS < <("$PY" - "$MANIFEST" "$SLOT" "$WORKER_COUNT" <<'PY'
import json, sys
d=json.load(open(sys.argv[1], encoding="utf-8"))
slot=int(sys.argv[2]); count=int(sys.argv[3])
for i, shard in enumerate(d["shards"]):
    if i % count == slot:
        print(shard["path"])
PY
)

echo "worker_start slot=$SLOT gpu=$GPU assigned=${#SHARDS[@]} $(date -Is)" > "$LOG_DIR/worker_${SLOT}.log"
for SHARD in "${SHARDS[@]}"; do
  NAME=$(basename "$SHARD" .jsonl)
  WS="$RUN_ROOT/workers/slot_${SLOT}/$NAME"
  if [[ -f "$WS/SHARD_COMPLETE.json" ]]; then
    echo "resume_skip_complete shard=$NAME" >> "$LOG_DIR/worker_${SLOT}.log"
    continue
  fi
  mkdir -p "$WS"
  echo "shard_start=$NAME $(date -Is)" >> "$LOG_DIR/worker_${SLOT}.log"
  CUDA_VISIBLE_DEVICES="$GPU" "$PY" "$EXTENSION/run_ebook_local_shard.py" \
    --shard-index "$SHARD" \
    --workspace "$WS" \
    --package-dir "$BASE_PACKAGE" \
    --device cuda:0 \
    >> "$LOG_DIR/worker_${SLOT}.log" 2>&1
  test -f "$WS/SHARD_COMPLETE.json"
  echo "shard_complete=$NAME $(date -Is)" >> "$LOG_DIR/worker_${SLOT}.log"
done
echo "worker_complete slot=$SLOT gpu=$GPU $(date -Is)" >> "$LOG_DIR/worker_${SLOT}.log"
touch "$RUN_ROOT/worker_${SLOT}.complete"
