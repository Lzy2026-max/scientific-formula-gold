#!/usr/bin/env bash
set -euo pipefail

RUN_ROOT=${1:?provide RUN_ROOT}
MANIFEST="$RUN_ROOT/index/execution_manifest.json"

echo "time=$(date -Is)"
echo "run_root=$RUN_ROOT"
if [[ ! -f "$MANIFEST" ]]; then
  CONFIG="$RUN_ROOT/index/index_build_config.json"
  if [[ -f "$CONFIG" ]]; then
    read -r PAGES BOOKS < <(python3 - "$CONFIG" <<'PY'
import json,sys
d=json.load(open(sys.argv[1],encoding="utf-8"))
print(sum(int(x["total_pages"]) for x in d["books"]),len(d["books"]))
PY
)
    DONE_PAGES=$(find "$RUN_ROOT/index/page_records" -name 'page_*.json' 2>/dev/null | wc -l)
    DONE_BOOKS=$(find "$RUN_ROOT/index/book_records" -name '*.complete.json' 2>/dev/null | wc -l)
    echo "stage=index_build pages=$DONE_PAGES/$PAGES books=$DONE_BOOKS/$BOOKS"
  else
    echo "stage=waiting_for_index_config"
  fi
  pgrep -af "build_ebook_full_index.py.*$RUN_ROOT" || true
  tail -n 20 "$RUN_ROOT/logs/index.log" 2>/dev/null || true
  exit 0
fi

read -r EXPECTED DETECTED ACCEPTED REJECTED BOOKS PAGES < <(python3 - "$MANIFEST" <<'PY'
import json,sys
d=json.load(open(sys.argv[1],encoding="utf-8"))
print(
    d["shard_count"],
    d["detected_candidate_count"],
    d["pre_ocr_accepted_count"],
    d["pre_ocr_rejected_count"],
    d["book_count"],
    d["page_count"],
)
PY
)
EXPECTED_WORKERS=$(python3 - "$RUN_ROOT/run_manifest.json" <<'PY'
import json,sys
try:
    data=json.load(open(sys.argv[1],encoding="utf-8"))
    print(int(data.get("worker_count", 1)))
except FileNotFoundError:
    print(1)
PY
)
DONE=$(find "$RUN_ROOT/workers" -name SHARD_COMPLETE.json 2>/dev/null | wc -l)
WORKERS=$(find "$RUN_ROOT" -maxdepth 1 -name 'worker_*.complete' 2>/dev/null | wc -l)
ACTIVE=$(pgrep -af "run_ebook_local_shard.py.*$RUN_ROOT|server_pipeline.py.*$RUN_ROOT" | wc -l || true)
AUDIT_FINGERPRINT="$RUN_ROOT/index/prefilter_audit/prefilter_audit_fingerprint.sha256"
APPROVAL_FINGERPRINT="$RUN_ROOT/GPU_AUDIT_APPROVED.sha256"
if [[ -f "$AUDIT_FINGERPRINT" ]] \
  && [[ -f "$APPROVAL_FINGERPRINT" ]] \
  && cmp -s "$AUDIT_FINGERPRINT" "$APPROVAL_FINGERPRINT"
then
  AUDIT_APPROVED=1
else
  AUDIT_APPROVED=0
fi
if [[ "$AUDIT_APPROVED" == "0" && "$DONE" -eq 0 && "$ACTIVE" -eq 0 ]]; then
  echo "stage=awaiting_prefilter_review books=$BOOKS pages=$PAGES"
else
  echo "stage=gpu_pipeline books=$BOOKS pages=$PAGES"
fi
echo "pre_ocr_detected=$DETECTED accepted=$ACCEPTED rejected=$REJECTED"
echo "audit_approved=$AUDIT_APPROVED"
echo "audit_samples=$RUN_ROOT/index/prefilter_audit/samples"
echo "completed_shards=$DONE/$EXPECTED completed_workers=$WORKERS/$EXPECTED_WORKERS active_processes=$ACTIVE"

for LOG in "$RUN_ROOT"/logs/worker_*.log; do
  [[ -f "$LOG" ]] || continue
  printf '%s: ' "$(basename "$LOG")"
  grep -E 'pix2tex_actual_device|\[ocr\].*processed=|shard_complete=|worker_complete|Traceback|Error|CUDA out of memory' "$LOG" \
    | tail -n 1 || true
done
echo "recent_errors:"
grep -nE 'Traceback|Error|No space left|Killed|CUDA out of memory' \
  "$RUN_ROOT"/logs/*.log 2>/dev/null | tail -n 20 || true
echo "gpu_status:"
nvidia-smi \
  --query-gpu=index,name,utilization.gpu,memory.used,memory.total,temperature.gpu \
  --format=csv,noheader
echo "disk_status:"
du -sh \
  "$RUN_ROOT" \
  "$RUN_ROOT/index/candidate_images" \
  "$RUN_ROOT/index/rejected_candidate_images" \
  2>/dev/null || true
