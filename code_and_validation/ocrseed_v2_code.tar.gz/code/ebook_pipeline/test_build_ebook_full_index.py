from __future__ import annotations

import csv
import json
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

import fitz

from build_ebook_full_index import (
    consolidate,
    deduplicate_candidates,
    merge_text_line_records,
    padded_pixel_box,
    pdf_catalog,
    prepared_formula_line,
    process_book,
    write_csv,
)


class FormulaBoundaryTests(unittest.TestCase):
    def test_equation_number_and_context_are_removed_from_ocr_boundary(self) -> None:
        spans = [
            {"text": "f(x)=x^2+1", "bbox": (10, 20, 110, 35), "font": "STIX"},
            {"text": " (2.31)", "bbox": (180, 20, 220, 35), "font": "Times"},
        ]
        kept, text, equation_number, context = prepared_formula_line(spans)
        self.assertEqual(text, "f(x)=x^2+1")
        self.assertEqual(equation_number, "(2.31)")
        self.assertEqual(context, "")
        self.assertEqual(len(kept), 1)

    def test_separate_where_clause_is_removed_but_retained_as_context(self) -> None:
        spans = [
            {"text": "z=x+y", "bbox": (10, 20, 80, 35), "font": "STIX"},
            {"text": " where x>0", "bbox": (82, 20, 170, 35), "font": "Times"},
        ]
        kept, text, equation_number, context = prepared_formula_line(spans)
        self.assertEqual(text, "z=x+y")
        self.assertEqual(equation_number, "")
        self.assertEqual(context, "where x>0")
        self.assertEqual(len(kept), 1)

    def test_inline_where_clause_in_one_span_is_removed_from_bbox(self) -> None:
        spans = [{
            "text": "z=x+y where x>0",
            "bbox": (10, 20, 180, 35),
            "font": "STIX",
        }]
        kept, text, equation_number, context = prepared_formula_line(spans)
        self.assertEqual(text, "z=x+y")
        self.assertEqual(equation_number, "")
        self.assertEqual(context, "where x>0")
        self.assertLess(kept[0]["bbox"][2], 100)

    def test_inline_equation_number_in_one_span_is_removed(self) -> None:
        spans = [{
            "text": "f(x)=x^2+1 (2.31)",
            "bbox": (10, 20, 210, 35),
            "font": "STIX",
        }]
        kept, text, equation_number, context = prepared_formula_line(spans)
        self.assertEqual(text, "f(x)=x^2+1")
        self.assertEqual(equation_number, "(2.31)")
        self.assertEqual(context, "")
        self.assertLess(kept[0]["bbox"][2], 160)

    def test_leading_answer_label_is_removed_when_formula_follows(self) -> None:
        spans = [{
            "text": "Answer. 5. f(x)=x^2+1",
            "bbox": (10, 20, 240, 35),
            "font": "STIX",
        }]
        kept, text, equation_number, context = prepared_formula_line(spans)
        self.assertEqual(text, "f(x)=x^2+1")
        self.assertGreater(kept[0]["bbox"][0], 80)

    def test_explanatory_sentence_tail_is_removed(self) -> None:
        spans = [{
            "text": "f(x)=4: -1 or 3. This means the output equals four at two inputs.",
            "bbox": (10, 20, 500, 35),
            "font": "STIX",
        }]
        kept, text, equation_number, context = prepared_formula_line(spans)
        self.assertEqual(text, "f(x)=4: -1 or 3.")
        self.assertTrue(context.startswith("This means"), context)
        self.assertLess(kept[0]["bbox"][2], 200)

    def test_same_baseline_formula_fragments_are_merged(self) -> None:
        records = [
            {
                "bbox": (100.0, 200.0, 175.0, 216.0),
                "text": "f(x) =",
                "original_text": "f(x) =",
                "fonts": ["STIXTwoMath"],
                "score": 5.0,
                "equation_number": "",
                "context_after": "",
            },
            {
                "bbox": (180.0, 201.0, 250.0, 216.0),
                "text": "x^2 + 1",
                "original_text": "x^2 + 1",
                "fonts": ["STIXTwoMath"],
                "score": 1.0,
                "equation_number": "",
                "context_after": "",
            },
        ]
        merged = merge_text_line_records(records, fitz.Rect(0, 0, 595, 842), 3.0)
        self.assertEqual(len(merged), 1, merged)
        self.assertEqual(merged[0]["source_line_count"], 2)
        self.assertIn("f(x)", merged[0]["text"])
        self.assertIn("x^2", merged[0]["text"])

    def test_split_relation_boundary_gets_wider_targeted_merge(self) -> None:
        records = [
            {
                "bbox": (100.0, 200.0, 155.0, 216.0),
                "text": "T(A)",
                "original_text": "T(A)",
                "fonts": ["STIXTwoMath"],
                "score": 3.2,
                "equation_number": "",
                "context_after": "",
            },
            {
                "bbox": (180.0, 201.0, 235.0, 216.0),
                "text": "= Bb",
                "original_text": "= Bb",
                "fonts": ["STIXTwoMath"],
                "score": 3.5,
                "equation_number": "",
                "context_after": "",
            },
        ]
        merged = merge_text_line_records(records, fitz.Rect(0, 0, 595, 842), 3.0)
        self.assertEqual(len(merged), 1, merged)
        self.assertIn("T(A)", merged[0]["text"])
        self.assertIn("= Bb", merged[0]["text"])

    def test_wrapped_relation_continuation_is_merged_vertically(self) -> None:
        records = [
            {
                "bbox": (100.0, 200.0, 210.0, 216.0),
                "text": "f(x, y) =",
                "original_text": "f(x, y) =",
                "fonts": ["STIXTwoMath"],
                "score": 5.0,
                "equation_number": "",
                "context_after": "",
            },
            {
                "bbox": (100.0, 220.0, 245.0, 236.0),
                "text": "x^2 + y^2",
                "original_text": "x^2 + y^2",
                "fonts": ["STIXTwoMath"],
                "score": 3.0,
                "equation_number": "",
                "context_after": "",
            },
        ]
        merged = merge_text_line_records(records, fitz.Rect(0, 0, 595, 842), 3.0)
        self.assertEqual(len(merged), 1, merged)
        self.assertIn("f(x, y) =", merged[0]["text"])
        self.assertIn("x^2 + y^2", merged[0]["text"])

    def test_matrix_boundary_glyphs_merge_with_nearby_entries(self) -> None:
        records = [
            {
                "bbox": (100.0, 200.0, 120.0, 250.0),
                "text": "A =   ",
                "original_text": "A =   ",
                "fonts": ["STIXTwoMath"],
                "score": 4.0,
                "equation_number": "",
                "context_after": "",
            },
            {
                "bbox": (130.0, 205.0, 190.0, 245.0),
                "text": "1 2 / 3 4",
                "original_text": "1 2 / 3 4",
                "fonts": ["STIXTwoMath"],
                "score": 2.0,
                "equation_number": "",
                "context_after": "",
            },
            {
                "bbox": (200.0, 200.0, 220.0, 250.0),
                "text": "  ",
                "original_text": "  ",
                "fonts": ["STIXTwoMath"],
                "score": 1.5,
                "equation_number": "",
                "context_after": "",
            },
        ]
        merged = merge_text_line_records(records, fitz.Rect(0, 0, 595, 842), 3.0)
        self.assertEqual(len(merged), 1, merged)
        self.assertIn("1 2", merged[0]["text"])
        self.assertIn("3 4", merged[0]["text"])

    def test_separate_display_equations_are_not_merged(self) -> None:
        records = [
            {
                "bbox": (100.0, 200.0, 250.0, 216.0),
                "text": "f(x)=x^2",
                "original_text": "f(x)=x^2",
                "fonts": ["STIXTwoMath"],
                "score": 5.0,
                "equation_number": "",
                "context_after": "",
            },
            {
                "bbox": (100.0, 230.0, 250.0, 246.0),
                "text": "g(x)=x^3",
                "original_text": "g(x)=x^3",
                "fonts": ["STIXTwoMath"],
                "score": 5.0,
                "equation_number": "",
                "context_after": "",
            },
        ]
        merged = merge_text_line_records(records, fitz.Rect(0, 0, 595, 842), 3.0)
        self.assertEqual(len(merged), 2, merged)

    def test_close_separate_relations_are_not_vertically_merged(self) -> None:
        records = [
            {
                "bbox": (100.0, 200.0, 150.0, 216.0),
                "text": "x=1",
                "original_text": "x=1",
                "fonts": ["STIXTwoMath"],
                "score": 5.0,
                "equation_number": "",
                "context_after": "",
            },
            {
                "bbox": (100.0, 220.0, 150.0, 236.0),
                "text": "y=2",
                "original_text": "y=2",
                "fonts": ["STIXTwoMath"],
                "score": 5.0,
                "equation_number": "",
                "context_after": "",
            },
        ]
        merged = merge_text_line_records(records, fitz.Rect(0, 0, 595, 842), 3.0)
        self.assertEqual(len(merged), 2, merged)

    def test_compact_fraction_components_are_merged_without_seed(self) -> None:
        records = [
            {
                "bbox": (100.0, 200.0, 112.0, 214.0),
                "text": "E",
                "original_text": "E",
                "fonts": ["STIXTwoMath"],
                "score": 1.8,
                "equation_number": "",
                "context_after": "",
            },
            {
                "bbox": (100.0, 220.0, 112.0, 234.0),
                "text": "J",
                "original_text": "J",
                "fonts": ["STIXTwoMath"],
                "score": 1.8,
                "equation_number": "",
                "context_after": "",
            },
        ]
        merged = merge_text_line_records(records, fitz.Rect(0, 0, 595, 842), 3.0)
        self.assertEqual(len(merged), 1, merged)
        self.assertEqual(merged[0]["merge_reason"], "compact_vertical_math_stack")
        self.assertEqual(merged[0]["text"], "E / J")
        self.assertGreaterEqual(merged[0]["score"], 3.0)

    def test_text_padding_is_smaller_vertically_than_v3(self) -> None:
        box = padded_pixel_box(
            (100.0, 200.0, 200.0, 220.0),
            fitz.Rect(0, 0, 600, 800),
            1200,
            1600,
        )
        raw_height = 40
        self.assertLess(box[3] - box[1], raw_height * 1.6)

    def test_text_candidate_wins_over_overlapping_raster_candidate(self) -> None:
        common_box = (100, 100, 300, 160)
        kept = deduplicate_candidates([
            {
                "box": common_box,
                "detection_method": "raster_high_recall_scanned_page",
                "detection_score": 9.0,
            },
            {
                "box": common_box,
                "detection_method": "pdf_text_math_layout",
                "detection_score": 3.0,
            },
        ])
        self.assertEqual(len(kept), 1)
        self.assertEqual(kept[0]["detection_method"], "pdf_text_math_layout")

    def test_text_candidate_removes_all_overlapping_fallback_duplicates(self) -> None:
        kept = deduplicate_candidates([
            {
                "box": (90, 100, 250, 160),
                "detection_method": "raster_high_recall_scanned_page",
                "detection_score": 9.0,
            },
            {
                "box": (150, 100, 310, 160),
                "detection_method": "embedded_image_region",
                "detection_score": 9.0,
            },
            {
                "box": (100, 100, 300, 160),
                "detection_method": "pdf_text_math_layout",
                "detection_score": 3.0,
            },
        ])
        self.assertEqual(len(kept), 1, kept)
        self.assertEqual(kept[0]["detection_method"], "pdf_text_math_layout")


    def test_pdf_span_join_preserves_word_boundaries(self) -> None:
        spans = [
            {"text": "The random", "bbox": (10, 20, 90, 35), "font": "Times"},
            {"text": "variable has", "bbox": (92, 20, 180, 35), "font": "Times"},
            {"text": "value x = 4", "bbox": (182, 20, 260, 35), "font": "Times"},
        ]
        _, text, _, _ = prepared_formula_line(spans)
        self.assertEqual(
            text,
            "The random variable has value x = 4",
        )

    def test_same_baseline_complete_relations_are_not_merged(self) -> None:
        records = [
            {
                "bbox": (100.0, 200.0, 150.0, 216.0),
                "text": "x=1",
                "original_text": "x=1",
                "fonts": ["STIXTwoMath"],
                "score": 5.0,
                "equation_number": "",
                "context_after": "",
            },
            {
                "bbox": (155.0, 200.0, 205.0, 216.0),
                "text": "y=2",
                "original_text": "y=2",
                "fonts": ["STIXTwoMath"],
                "score": 5.0,
                "equation_number": "",
                "context_after": "",
            },
        ]
        merged = merge_text_line_records(
            records,
            fitz.Rect(0, 0, 595, 842),
            3.0,
        )
        self.assertEqual(len(merged), 2, merged)


class PersistenceTests(unittest.TestCase):
    def test_csv_quotes_commas_quotes_and_newlines(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            path = Path(temporary) / "quoted.csv"
            source = [{"text": 'a,"b"\nline2', "formula": r"x=\frac{a}{b}"}]
            write_csv(path, source)
            with path.open(encoding="utf-8-sig", newline="") as handle:
                loaded = list(csv.DictReader(handle))
            self.assertEqual(loaded, source)

    def test_small_pdf_runs_through_index_and_consolidation(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            ebook_root = root / "ebooks"
            output = root / "index"
            ebook_root.mkdir()
            document = fitz.open()
            page = document.new_page(width=595, height=842)
            page.insert_text((120, 300), "f(x) = x^2 + 1", fontsize=16)
            pdf_path = ebook_root / "test_book.pdf"
            document.save(pdf_path)
            document.close()

            catalog = pdf_catalog(ebook_root)
            self.assertEqual(len(catalog), 1)
            result = process_book({
                **catalog[0],
                "output_dir": str(output),
                "dpi": 160,
                "min_vector_score": 3.0,
                "min_raster_score": 1.5,
                "scanned_text_threshold": 0,
            })
            self.assertEqual(result["page_errors"], 0)
            self.assertGreaterEqual(result["detected_candidates"], 1)
            manifest = consolidate(output, catalog, shard_size=1000, seed=2026080301)
            self.assertEqual(
                manifest["detected_candidate_count"],
                manifest["pre_ocr_accepted_count"]
                + manifest["pre_ocr_rejected_count"],
            )
            self.assertTrue(manifest["candidate_conservation_check"]["passed"])
            stored = json.loads(
                (output / "execution_manifest.json").read_text(encoding="utf-8")
            )
            self.assertEqual(stored["schema"], "ebook-formula-corpus-execution-manifest-v3.5")
            subprocess.run(
                [
                    sys.executable,
                    str(Path(__file__).with_name("audit_ebook_prefilter.py")),
                    "--index-dir",
                    str(output),
                    "--samples-per-group",
                    "2",
                ],
                check=True,
                capture_output=True,
                text=True,
            )
            audit = json.loads(
                (output / "prefilter_audit" / "prefilter_audit_summary.json").read_text(
                    encoding="utf-8"
                )
            )
            self.assertTrue(audit["candidate_conservation_passed"])
            self.assertEqual(audit["schema"], "ebook-prefilter-audit-v3.5")
            fingerprint = (
                output
                / "prefilter_audit"
                / "prefilter_audit_fingerprint.sha256"
            ).read_text(encoding="ascii").strip()
            self.assertEqual(len(fingerprint), 64)
            self.assertTrue(
                (output / "prefilter_audit" / "GPU_REVIEW_REQUIRED.txt").is_file()
            )
            subprocess.run(
                [
                    sys.executable,
                    str(Path(__file__).with_name("audit_ebook_prefilter.py")),
                    "--index-dir",
                    str(output),
                    "--samples-per-group",
                    "2",
                ],
                check=True,
                capture_output=True,
                text=True,
            )
            rerun_fingerprint = (
                output
                / "prefilter_audit"
                / "prefilter_audit_fingerprint.sha256"
            ).read_text(encoding="ascii").strip()
            self.assertEqual(rerun_fingerprint, fingerprint)


if __name__ == "__main__":
    unittest.main()
