#!/usr/bin/env python3
"""Create Chinese per-book summaries and representative evidence for the e-book run."""

from __future__ import annotations

import argparse
import csv
import json
import os
import shutil
from collections import Counter, defaultdict
from pathlib import Path


M_TAGS = [
    "M01_basic_additive_separable_no_overlap",
    "M02_basic_multiplicative_separable_no_overlap",
    "M03_overlapping_additive",
    "M04_overlapping_multiplicative",
    "M05_product_with_constant",
    "M06_compositionality",
    "M07_log_exp_nested",
    "M08_sin_nested",
    "M09_universal_additive_generalized_additivity",
    "M10_universal_multiplicative",
    "M11_generalized_symmetry",
    "M12_simple_symmetry",
]


def read_jsonl(path: Path):
    with path.open(encoding="utf-8-sig", errors="replace") as handle:
        for line in handle:
            if line.strip():
                yield json.loads(line)


def read_csv(path: Path) -> list[dict]:
    with path.open(encoding="utf-8-sig", newline="") as handle:
        return list(csv.DictReader(handle))


def write_csv(path: Path, rows: list[dict]) -> None:
    fields = list(rows[0]) if rows else []
    temporary = path.with_suffix(path.suffix + ".part")
    with temporary.open("w", encoding="utf-8-sig", newline="") as handle:
        def encoded(value: object) -> str:
            text = "" if value is None else str(value)
            return '"' + text.replace('"', '""') + '"'

        handle.write(",".join(encoded(field) for field in fields) + "\n")
        for row in rows:
            handle.write(",".join(encoded(row.get(field, "")) for field in fields) + "\n")
    os.replace(temporary, path)


def tags_from(row: dict) -> list[str]:
    value = row.get("tags", row.get("formula_level_tags", []))
    if isinstance(value, str):
        return [item for item in value.replace(",", ";").split(";") if item]
    return list(value or [])


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--index-dir", required=True)
    parser.add_argument("--official-dir", required=True)
    args = parser.parse_args()
    index_dir = Path(args.index_dir).resolve()
    official = Path(args.official_dir).resolve()
    catalog = read_csv(index_dir / "ebook_book_catalog.csv")
    candidates = list(read_jsonl(index_dir / "candidate_index_all.jsonl"))
    rejected = list(read_jsonl(index_dir / "ebook_pre_ocr_rejected_catalog.jsonl"))
    ocr_rows = list(read_jsonl(official / "formula_records.jsonl"))
    tree_rows = list(read_jsonl(official / "formula_trees.jsonl"))

    candidate_counts = Counter(str(row.get("book_id", row.get("source_id", ""))) for row in candidates)
    rejected_counts = Counter(str(row.get("book_id", row.get("source_id", ""))) for row in rejected)
    candidate_pages: dict[str, set[int]] = defaultdict(set)
    rejected_pages: dict[str, set[int]] = defaultdict(set)
    for row in candidates:
        candidate_pages[str(row.get("book_id", row.get("source_id", "")))].add(int(row.get("page", 0) or 0))
    for row in rejected:
        rejected_pages[str(row.get("book_id", row.get("source_id", "")))].add(
            int(row.get("page", 0) or 0)
        )
    ocr_status: dict[str, Counter] = defaultdict(Counter)
    ocr_quality: dict[str, Counter] = defaultdict(Counter)
    ocr_by_id = {}
    for row in ocr_rows:
        book_id = str(row.get("book_id", row.get("source_id", "")))
        ocr_status[book_id][str(row.get("ocr_status", "unknown"))] += 1
        ocr_quality[book_id][str(row.get("ocr_quality_status", "unknown"))] += 1
        ocr_by_id[str(row.get("formula_id", ""))] = row
    tree_status: dict[str, Counter] = defaultdict(Counter)
    tag_counts: dict[str, Counter] = defaultdict(Counter)
    core_counts = Counter()
    tree_counts = Counter()
    for row in tree_rows:
        book_id = str(row.get("book_id", row.get("source_id", "")))
        tree_counts[book_id] += 1
        tree_status[book_id][str(row.get("record_status", "unknown"))] += 1
        tags = tags_from(row)
        if row.get("validity_status") == "valid_for_core_stats":
            core_counts[book_id] += 1
            tag_counts[book_id].update(tags)

    summary_rows = []
    for book in sorted(catalog, key=lambda row: int(row["book_no"])):
        book_id = book["book_id"]
        total_pages = int(book["total_pages"])
        row = {
            "序号": book["book_no"],
            "书名": book["title"],
            "作者": book["authors"],
            "PDF文件": book["file_name"],
            "来源ID": book_id,
            "PDF_SHA256": book["pdf_sha256"],
            "总页数": total_pages,
            "初检候选页数": len((candidate_pages[book_id] | rejected_pages[book_id]) - {0}),
            "初检候选区域数": candidate_counts[book_id] + rejected_counts[book_id],
            "OCR前接受候选页数": len(candidate_pages[book_id] - {0}),
            "OCR前接受候选区域数": candidate_counts[book_id],
            "OCR前拒绝候选区域数": rejected_counts[book_id],
            "OCR成功": ocr_status[book_id]["ok"],
            "OCR空结果": ocr_status[book_id]["empty"],
            "OCR异常": ocr_status[book_id]["error"],
            "门控跳过非公式": ocr_status[book_id]["skipped_non_formula"],
            "公式树记录数": tree_counts[book_id],
            "进入核心统计数": core_counts[book_id],
            "OCR质量通过数": ocr_quality[book_id]["passed"],
            "OCR质量可疑数": ocr_quality[book_id]["suspicious"],
            "OCR质量排除数": ocr_quality[book_id]["rejected"],
        }
        for index, tag in enumerate(M_TAGS, 1):
            row[f"M{index:02d}命中数"] = tag_counts[book_id][tag]
        summary_rows.append(row)

    output_csv = official / "电子书30本逐书结果汇总.csv"
    write_csv(output_csv, summary_rows)
    shutil.copy2(index_dir / "ebook_book_catalog.csv", official / "电子书30本来源目录.csv")
    shutil.copy2(index_dir / "ebook_page_candidate_summary.csv", official / "电子书30本逐页候选统计.csv")
    shutil.copy2(
        index_dir / "ebook_pre_ocr_rejected_catalog.csv",
        official / "电子书30本OCR前拒绝候选审计清单.csv",
    )

    representative_csv = official / "representative_examples.csv"
    representative_dir = official / "representative_images"
    representative_dir.mkdir(exist_ok=True)
    copied = []
    if representative_csv.exists():
        for row in read_csv(representative_csv):
            formula_id = str(row.get("formula_id", ""))
            ocr = ocr_by_id.get(formula_id, {})
            source = Path(str(ocr.get("image_path", "")))
            if source.is_file():
                destination = representative_dir / f"{row.get('m12_tag', 'MXX')}_{formula_id}{source.suffix}"
                shutil.copy2(source, destination)
                copied.append({
                    "formula_id": formula_id,
                    "m12_tag": row.get("m12_tag", ""),
                    "source_title": row.get("source_title", ""),
                    "page": row.get("page", ""),
                    "image_file": destination.name,
                })
    write_csv(official / "代表案例图片清单.csv", copied)

    total_pages = sum(int(row["total_pages"]) for row in catalog)
    total_candidates = len(candidates)
    total_rejected = len(rejected)
    total_detected = total_candidates + total_rejected
    total_core = sum(core_counts.values())
    markdown = [
        "# 30 本电子书实验结果说明",
        "",
        "## 一、实验范围",
        "",
        f"- 电子书：{len(catalog)} 本。",
        f"- PDF 总页数：{total_pages:,} 页。",
        "- 页面范围：逐本逐页扫描，无前 120 页限制。",
        "- 候选范围：先合并 PDF 文本层中的相邻公式片段，再执行可审计的 OCR 前过滤；"
        "无“每页最多 3 条”或“每本最多若干条”限制。",
        f"- 初检候选区域：{total_detected:,} 个；OCR 前接受：{total_candidates:,} 个；"
        f"OCR 前拒绝：{total_rejected:,} 个。",
        f"- 形成公式树记录：{len(tree_rows):,} 条；进入核心统计：{total_core:,} 条。",
        "",
        "“全量”表示所有 PDF 页面均被处理且候选区域不设条数上限；公式召回率仍受版面检测和 OCR 能力边界影响，"
        "因此不将结果表述为对印刷公式的绝对无遗漏识别。",
        "",
        "## 二、逐书结果",
        "",
        "|序号|书名|页数|初检区域|OCR前接受|OCR前拒绝|公式树|核心统计|",
        "|---:|---|---:|---:|---:|---:|---:|---:|",
    ]
    for row in summary_rows:
        markdown.append(
            f"|{row['序号']}|{row['书名']}|{int(row['总页数']):,}|"
            f"{int(row['初检候选区域数']):,}|"
            f"{int(row['OCR前接受候选区域数']):,}|"
            f"{int(row['OCR前拒绝候选区域数']):,}|"
            f"{int(row['公式树记录数']):,}|"
            f"{int(row['进入核心统计数']):,}|"
        )
    markdown.extend([
        "",
        "## 三、可追溯性",
        "",
        "公式级结果保留电子书来源 ID、PDF 文件名与 SHA-256、页码、候选编号、页面坐标框、"
        "片段合并数量、邻近上下文与页面相对位置、"
        "候选截图路径、OCR 前过滤判定及理由、OCR LaTeX、公式树、质量状态和 M01–M12 标签。"
        "被 OCR 前过滤拒绝的区域另存图片和明细清单，不进入 GPU OCR。逐书汇总、逐页候选统计、"
        "拒绝候选清单及代表案例与公式级明细共同构成审计链路。",
        "",
    ])
    (official / "电子书30本实验结果说明.md").write_text(
        "\n".join(markdown), encoding="utf-8"
    )
    summary = {
        "book_count": len(catalog),
        "page_count": total_pages,
        "detected_candidate_regions": total_detected,
        "pre_ocr_accepted_regions": total_candidates,
        "pre_ocr_rejected_regions": total_rejected,
        "ocr_records": len(ocr_rows),
        "formula_tree_records": len(tree_rows),
        "core_records": total_core,
        "representative_images_copied": len(copied),
        "per_book_csv": str(output_csv),
    }
    (official / "电子书30本实验摘要.json").write_text(
        json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    print(json.dumps(summary, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
