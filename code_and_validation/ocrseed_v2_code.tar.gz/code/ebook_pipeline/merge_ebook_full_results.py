#!/usr/bin/env python3
"""Validate e-book schema-v3 shard markers, then run the frozen merger."""

from __future__ import annotations

import hashlib
import importlib.util
import json
import sys
from pathlib import Path


BASE_FINGERPRINT_KEYS = (
    "package_version",
    "formula_engine_sha256",
    "server_pipeline_sha256",
    "latex_registry_sha256",
    "semantic_registry_sha256",
    "parser_rule_library_sha256",
    "quality_config_sha256",
)


def read_jsonl(path: Path):
    with path.open(encoding="utf-8-sig", errors="replace") as handle:
        for line in handle:
            if line.strip():
                yield json.loads(line)


def formula_id_digest(path: Path) -> tuple[str, int]:
    ids = [str(row.get("formula_id", "")) for row in read_jsonl(path)]
    if not ids or "" in ids or len(ids) != len(set(ids)):
        raise ValueError("empty_or_duplicate_formula_id")
    value = "\n".join(sorted(ids))
    return hashlib.sha256(value.encode("utf-8")).hexdigest(), len(ids)


def load_frozen_merger(package_dir: Path):
    merger_path = package_dir / "merge_full_formula_results.py"
    if not merger_path.is_file():
        raise SystemExit(f"missing_frozen_merger={merger_path}")
    sys.path.insert(0, str(package_dir))
    spec = importlib.util.spec_from_file_location("frozen_formula_result_merger", merger_path)
    if spec is None or spec.loader is None:
        raise SystemExit(f"cannot_load_frozen_merger={merger_path}")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def make_schema_v3_validator(merger):
    def validate_marker(marker_path: Path, expected: dict, current: dict) -> tuple[bool, str]:
        try:
            marker = json.loads(marker_path.read_text(encoding="utf-8"))
        except Exception as exc:
            return False, f"invalid_json:{exc!r}"

        if marker.get("status") != "complete" or marker.get("schema_version") != 3:
            return False, "not_complete_ebook_schema_v3"
        expected_records = int(expected.get("records", -1))
        if marker.get("input_records") != expected_records:
            return False, "input_record_count_mismatch"
        if marker.get("accounted_records") != marker.get("input_records"):
            return False, "worker_count_conservation_failed"

        shard_path = Path(str(marker.get("shard_index", "")))
        if shard_path.name != Path(str(expected["path"])).name or not shard_path.is_file():
            return False, "shard_index_path_mismatch_or_missing"
        fingerprint = marker.get("fingerprint")
        if not isinstance(fingerprint, dict):
            return False, "missing_fingerprint"
        if fingerprint.get("shard_index_sha256") != merger.sha256_file(shard_path):
            return False, "shard_index_sha256_mismatch"
        for key in BASE_FINGERPRINT_KEYS:
            if fingerprint.get(key) != current.get(key):
                return False, f"fingerprint_mismatch:{key}"
        checkpoint_hash = fingerprint.get("ocr_checkpoint_sha256")
        if not checkpoint_hash or checkpoint_hash == "missing":
            return False, "missing_ocr_checkpoint_fingerprint"

        try:
            digest, record_count = formula_id_digest(shard_path)
        except Exception as exc:
            return False, f"invalid_shard_formula_ids:{exc!r}"
        if record_count != expected_records:
            return False, "shard_formula_id_count_mismatch"
        if marker.get("input_formula_ids_sha256") != digest:
            return False, "input_formula_ids_sha256_mismatch"

        extension_dir = Path(str(marker.get("extension_dir", "")))
        runner_path = extension_dir / "run_ebook_local_shard.py"
        if not runner_path.is_file():
            return False, "ebook_extension_runner_missing"
        if fingerprint.get("ebook_extension_runner_sha256") != merger.sha256_file(runner_path):
            return False, "ebook_extension_runner_sha256_mismatch"
        if not isinstance(marker.get("runtime_versions"), dict):
            return False, "missing_runtime_versions"
        if not isinstance(marker.get("analysis_summary"), dict):
            return False, "missing_analysis_summary"
        return True, "ok"

    return validate_marker


def main() -> None:
    try:
        package_index = sys.argv.index("--package-dir") + 1
        package_dir = Path(sys.argv[package_index]).expanduser().resolve()
    except (ValueError, IndexError):
        raise SystemExit("--package-dir is required") from None

    merger = load_frozen_merger(package_dir)
    merger.validate_marker = make_schema_v3_validator(merger)
    merger.main()


if __name__ == "__main__":
    main()
