#!/usr/bin/env python3
"""Run the same accepted candidate images twice with the isolated OCR mode."""

from __future__ import annotations

import argparse
import hashlib
import json
import subprocess
import sys
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path


COMPARE_FIELDS = (
    "formula_latex",
    "ocr_variant_latex",
    "ocr_status",
    "ocr_generated_status",
    "ocr_quality_status",
    "ocr_quality_reasons",
    "ocr_variant_similarity",
)


def read_jsonl(path: Path):
    with path.open(encoding="utf-8-sig") as handle:
        for line in handle:
            if line.strip():
                yield json.loads(line)


def stable_order(row: dict) -> bytes:
    return hashlib.sha256(str(row["formula_id"]).encode("utf-8")).digest()


def select_rows(rows: list[dict], count: int) -> list[dict]:
    strict = sorted((r for r in rows if r.get("image_screen_status") == "formula_candidate_strict"), key=stable_order)
    other = sorted((r for r in rows if r.get("image_screen_status") != "formula_candidate_strict"), key=stable_order)
    chosen = strict[: count // 2] + other[: count - count // 2]
    if len(chosen) < count:
        chosen_ids = {r["formula_id"] for r in chosen}
        remainder = sorted((r for r in rows if r["formula_id"] not in chosen_ids), key=stable_order)
        chosen.extend(remainder[: count - len(chosen)])
    return sorted(chosen, key=lambda r: str(r["formula_id"]))


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--index", type=Path, required=True, help="accepted candidate_index_all.jsonl")
    parser.add_argument("--output-parent", type=Path, required=True)
    parser.add_argument("--sample-size", type=int, default=80)
    parser.add_argument("--device", default="cuda:0")
    args = parser.parse_args()
    if args.sample_size < 2:
        parser.error("--sample-size must be at least 2")

    index_path = args.index.expanduser().resolve()
    parent = args.output_parent.expanduser().resolve()
    rows = list(read_jsonl(index_path))
    if len({str(r.get("formula_id", "")) for r in rows}) != len(rows) or any(not r.get("formula_id") for r in rows):
        raise SystemExit("input index contains empty or duplicate formula_id")
    selected = select_rows(rows, min(args.sample_size, len(rows)))
    missing = [str(r["formula_id"]) for r in selected if not Path(str(r.get("image_path", ""))).is_file()]
    if missing:
        raise SystemExit("sample images are missing; first IDs: " + ", ".join(missing[:5]))

    timestamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    work = parent / ("ocr_repeatability_pilot_" + timestamp)
    work.mkdir(parents=True, exist_ok=False)
    sample_index = work / "pilot_index.jsonl"
    with sample_index.open("w", encoding="utf-8", newline="\n") as handle:
        for row in selected:
            handle.write(json.dumps(row, ensure_ascii=False) + "\n")

    code = Path(__file__).resolve().parents[1] / "common" / "formula_kb_production" / "server_pipeline.py"
    for label in ("a", "b"):
        command = [
            sys.executable, str(code), "ocr", "--index", str(sample_index),
            "--out", str(work / ("ocr_" + label + ".jsonl")),
            "--device", args.device, "--ocr-seed-mode", "per_formula_v1",
            "--log-every", "20",
        ]
        subprocess.run(command, check=True)

    first = {r["formula_id"]: r for r in read_jsonl(work / "ocr_a.jsonl")}
    second = {r["formula_id"]: r for r in read_jsonl(work / "ocr_b.jsonl")}
    expected = {r["formula_id"] for r in selected}
    if set(first) != expected or set(second) != expected:
        raise SystemExit("OCR outputs do not have the expected formula IDs")
    changes = Counter()
    changed_ids = []
    for formula_id in sorted(expected):
        differing = [field for field in COMPARE_FIELDS if first[formula_id].get(field) != second[formula_id].get(field)]
        if differing:
            changed_ids.append(formula_id)
            changes.update(differing)
    report = {
        "sample_size": len(selected),
        "strict_candidate_count": sum(r.get("image_screen_status") == "formula_candidate_strict" for r in selected),
        "different_record_count": len(changed_ids),
        "different_fields": dict(changes),
        "different_formula_ids": changed_ids,
        "pass": not changed_ids,
    }
    (work / "repeatability_report.json").write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"report": str(work / "repeatability_report.json"), **report}, ensure_ascii=False))
    return 0 if not changed_ids else 1


if __name__ == "__main__":
    raise SystemExit(main())
