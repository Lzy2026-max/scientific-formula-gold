#!/usr/bin/env python3
"""Summarize and sample the v3.5 PDF pre-OCR filter before GPU work starts."""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import shutil
from collections import Counter
from pathlib import Path


def read_jsonl(path: Path):
    with path.open(encoding="utf-8-sig", errors="replace") as handle:
        for line in handle:
            if line.strip():
                yield json.loads(line)


def write_csv(path: Path, rows: list[dict]) -> None:
    fields = sorted({key for row in rows for key in row}) if rows else []
    temporary = path.with_suffix(path.suffix + ".part")
    with temporary.open("w", encoding="utf-8-sig", newline="") as handle:
        def encoded(value: object) -> str:
            text = "" if value is None else str(value)
            return '"' + text.replace('"', '""') + '"'

        handle.write(",".join(encoded(field) for field in fields) + "\n")
        for row in rows:
            handle.write(",".join(encoded(row.get(field, "")) for field in fields) + "\n")
    os.replace(temporary, path)


def stable_order(row: dict, seed: int) -> str:
    value = f"{seed}\0{row.get('candidate_id', '')}".encode("utf-8")
    return hashlib.sha256(value).hexdigest()


def safe_group_name(value: str) -> str:
    cleaned = "".join(char if char.isalnum() or char in "._-" else "_" for char in value)
    return cleaned[:100] or "unknown"


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--index-dir", required=True)
    parser.add_argument("--output-dir")
    parser.add_argument("--samples-per-group", type=int, default=20)
    parser.add_argument("--seed", type=int, default=2026080302)
    args = parser.parse_args()

    index_dir = Path(args.index_dir).resolve()
    output_dir = (
        Path(args.output_dir).resolve()
        if args.output_dir
        else index_dir / "prefilter_audit"
    )
    output_dir.mkdir(parents=True, exist_ok=True)
    accepted = list(read_jsonl(index_dir / "candidate_index_all.jsonl"))
    rejected = list(read_jsonl(index_dir / "ebook_pre_ocr_rejected_catalog.jsonl"))
    all_rows = [*accepted, *rejected]

    decision_counts = Counter(str(row.get("pre_ocr_filter_decision", "unknown")) for row in all_rows)
    reason_counts = Counter(str(row.get("pre_ocr_filter_reason", "unknown")) for row in all_rows)
    method_counts = Counter(str(row.get("candidate_detection_method", "unknown")) for row in all_rows)
    method_decisions = Counter(
        (
            str(row.get("candidate_detection_method", "unknown")),
            str(row.get("pre_ocr_filter_decision", "unknown")),
        )
        for row in all_rows
    )
    per_book = Counter(
        (
            str(row.get("book_id", "")),
            str(row.get("title", "")),
            str(row.get("pre_ocr_filter_decision", "unknown")),
        )
        for row in all_rows
    )
    detected = len(all_rows)
    accepted_count = len(accepted)
    rejected_count = len(rejected)
    if detected != accepted_count + rejected_count:
        raise SystemExit("Candidate conservation failed during prefilter audit")

    summary = {
        "schema": "ebook-prefilter-audit-v3.5",
        "seed": args.seed,
        "detected": detected,
        "accepted": accepted_count,
        "rejected": rejected_count,
        "accepted_rate": round(accepted_count / max(detected, 1), 6),
        "rejected_rate": round(rejected_count / max(detected, 1), 6),
        "decision_counts": dict(sorted(decision_counts.items())),
        "reason_counts": dict(sorted(reason_counts.items())),
        "detection_method_counts": dict(sorted(method_counts.items())),
        "candidate_conservation_passed": True,
        "gpu_release_status": "requires_human_sample_review",
    }
    (output_dir / "prefilter_audit_summary.json").write_text(
        json.dumps(summary, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )
    write_csv(
        output_dir / "prefilter_audit_per_book.csv",
        [
            {
                "book_id": book_id,
                "title": title,
                "decision": decision,
                "count": count,
            }
            for (book_id, title, decision), count in sorted(per_book.items())
        ],
    )
    write_csv(
        output_dir / "prefilter_audit_reason_counts.csv",
        [
            {"reason": reason, "count": count}
            for reason, count in reason_counts.most_common()
        ],
    )
    write_csv(
        output_dir / "prefilter_audit_method_decisions.csv",
        [
            {"detection_method": method, "decision": decision, "count": count}
            for (method, decision), count in sorted(method_decisions.items())
        ],
    )

    sample_manifest = []
    grouped: dict[tuple[str, str], list[dict]] = {}
    for row in all_rows:
        key = (
            str(row.get("pre_ocr_filter_decision", "unknown")),
            str(row.get("pre_ocr_filter_reason", "unknown")),
        )
        grouped.setdefault(key, []).append(row)
    sample_root = (output_dir / "samples").resolve()
    if sample_root.parent != output_dir.resolve():
        raise SystemExit(f"Unsafe audit sample path: {sample_root}")
    if sample_root.exists():
        shutil.rmtree(sample_root)
    for (decision, reason), rows in sorted(grouped.items()):
        sample_dir = (
            sample_root
            / safe_group_name(decision)
            / safe_group_name(reason)
        )
        sample_dir.mkdir(parents=True, exist_ok=True)
        for row in sorted(rows, key=lambda item: stable_order(item, args.seed))[
            : args.samples_per_group
        ]:
            source = Path(str(row.get("image_path", "")))
            destination = sample_dir / (
                f"{row.get('book_id', 'book')}_p{int(row.get('page', 0)):05d}_"
                f"c{int(row.get('candidate_number', 0)):03d}{source.suffix or '.png'}"
            )
            if source.is_file():
                shutil.copy2(source, destination)
            sample_manifest.append({
                "decision": decision,
                "reason": reason,
                "candidate_id": row.get("candidate_id", ""),
                "formula_id": row.get("formula_id", ""),
                "book_id": row.get("book_id", ""),
                "title": row.get("title", ""),
                "page": row.get("page", ""),
                "candidate_number": row.get("candidate_number", ""),
                "candidate_bbox": row.get("candidate_bbox", ""),
                "candidate_text_layer": row.get("candidate_text_layer", ""),
                "candidate_original_text_layer": row.get(
                    "candidate_original_text_layer", ""
                ),
                "candidate_context_text_layer": row.get(
                    "candidate_context_text_layer", ""
                ),
                "equation_number_text_layer": row.get("equation_number_text_layer", ""),
                "context_after_text_layer": row.get(
                    "context_after_text_layer", ""
                ),
                "candidate_source_line_count": row.get(
                    "candidate_source_line_count", ""
                ),
                "candidate_merge_reason": row.get(
                    "candidate_merge_reason", ""
                ),
                "candidate_detection_method": row.get(
                    "candidate_detection_method", ""
                ),
                "candidate_detection_score": row.get(
                    "candidate_detection_score", ""
                ),
                "candidate_position_json": row.get(
                    "candidate_position_json", ""
                ),
                "pre_ocr_filter_score": row.get("pre_ocr_filter_score", ""),
                "pre_ocr_text_features_json": row.get(
                    "pre_ocr_text_features_json", ""
                ),
                "pre_ocr_visual_features_json": row.get(
                    "pre_ocr_visual_features_json", ""
                ),
                "provenance_locator": row.get("provenance_locator", ""),
                "source_image_path": str(source),
                "sample_image_path": str(destination) if destination.is_file() else "",
            })
    sample_manifest_path = output_dir / "prefilter_audit_sample_manifest.csv"
    write_csv(sample_manifest_path, sample_manifest)

    fingerprint = hashlib.sha256()
    for path in (
        index_dir / "execution_manifest.json",
        output_dir / "prefilter_audit_summary.json",
        sample_manifest_path,
    ):
        fingerprint.update(path.name.encode("utf-8"))
        fingerprint.update(path.read_bytes())
    audit_fingerprint = fingerprint.hexdigest()
    (output_dir / "prefilter_audit_fingerprint.sha256").write_text(
        audit_fingerprint + "\n",
        encoding="ascii",
    )
    (output_dir / "GPU_REVIEW_REQUIRED.txt").write_text(
        "GPU OCR has not been approved.\n"
        "Review the samples and prefilter_audit_sample_manifest.csv first.\n"
        "If the audit is accepted, copy prefilter_audit_fingerprint.sha256 to\n"
        "../../GPU_AUDIT_APPROVED.sha256 and start with GPU_APPROVED=1.\n",
        encoding="utf-8",
    )
    print(json.dumps(summary, ensure_ascii=False, indent=2))
    print(f"audit_dir={output_dir}")
    print(f"audit_fingerprint={audit_fingerprint}")


if __name__ == "__main__":
    main()
