from __future__ import annotations

import hashlib
import json
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace

from merge_ebook_full_results import BASE_FINGERPRINT_KEYS, make_schema_v3_validator


def sha256_file(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


class SchemaV3MarkerValidationTests(unittest.TestCase):
    def setUp(self) -> None:
        self.tempdir = tempfile.TemporaryDirectory()
        self.root = Path(self.tempdir.name)
        self.shard = self.root / "ebook_formula_index_shard_000001.jsonl"
        rows = [{"formula_id": "F002"}, {"formula_id": "F001"}]
        self.shard.write_text(
            "".join(json.dumps(row) + "\n" for row in rows), encoding="utf-8"
        )
        self.extension = self.root / "extension"
        self.extension.mkdir()
        self.runner = self.extension / "run_ebook_local_shard.py"
        self.runner.write_text("# immutable worker\n", encoding="utf-8")
        self.current = {key: f"value:{key}" for key in BASE_FINGERPRINT_KEYS}
        fingerprint = dict(self.current)
        fingerprint.update(
            {
                "shard_index_sha256": sha256_file(self.shard),
                "ocr_checkpoint_sha256": "checkpoint-hash",
                "ebook_extension_runner_sha256": sha256_file(self.runner),
            }
        )
        formula_digest = hashlib.sha256("F001\nF002".encode("utf-8")).hexdigest()
        self.marker = {
            "schema_version": 3,
            "status": "complete",
            "shard_index": str(self.shard),
            "input_records": 2,
            "input_formula_ids_sha256": formula_digest,
            "accounted_records": 2,
            "fingerprint": fingerprint,
            "runtime_versions": {"python": "test"},
            "analysis_summary": {"records": 2},
            "extension_dir": str(self.extension),
        }
        self.marker_path = self.root / "SHARD_COMPLETE.json"
        self.expected = {"path": str(self.shard), "records": 2}
        self.validator = make_schema_v3_validator(SimpleNamespace(sha256_file=sha256_file))

    def tearDown(self) -> None:
        self.tempdir.cleanup()

    def write_marker(self) -> None:
        self.marker_path.write_text(json.dumps(self.marker), encoding="utf-8")

    def test_valid_schema_v3_marker_is_accepted(self) -> None:
        self.write_marker()
        self.assertEqual(
            self.validator(self.marker_path, self.expected, self.current), (True, "ok")
        )

    def test_formula_id_digest_mismatch_is_rejected(self) -> None:
        self.marker["input_formula_ids_sha256"] = "corrupt"
        self.write_marker()
        valid, reason = self.validator(self.marker_path, self.expected, self.current)
        self.assertFalse(valid)
        self.assertEqual(reason, "input_formula_ids_sha256_mismatch")

    def test_extension_runner_mismatch_is_rejected(self) -> None:
        self.marker["fingerprint"]["ebook_extension_runner_sha256"] = "corrupt"
        self.write_marker()
        valid, reason = self.validator(self.marker_path, self.expected, self.current)
        self.assertFalse(valid)
        self.assertEqual(reason, "ebook_extension_runner_sha256_mismatch")


if __name__ == "__main__":
    unittest.main()
