#!/usr/bin/env python3
"""Auditable CPU pre-filter for PDF formula candidates before GPU OCR.

The filter is deliberately source-aware:
* PDF text-layer lines are judged primarily by mathematical text evidence.
* Embedded images and raster-only page bands are judged by conservative
  image morphology, because no reliable text is available before OCR.

Every decision returns a score, signals and a stable reason. Rejected
candidates are retained by the caller as provenance/evidence; this module
does not delete files.
"""

from __future__ import annotations

import re
from typing import Any

import numpy as np
from PIL import Image


MATH_FONT_RE = re.compile(
    r"(?:math|symbol|stix|cambria|cmmi|cmsy|cmex|msam|msbm|euclid|mt extra|"
    r"latinmodernmath|asana|xits|libertinusmath|texgyre)",
    re.I,
)
STRONG_MATH_RE = re.compile(
    r"[=≠≈≃≅≤≥∑∏∫√∞∂∇±×÷∈∉⊂⊃⊆⊇∪∩→↔⇒⇔]"
    r"|\\(?:sum|prod|int|sqrt|frac|partial|nabla|infty|leq|geq|approx|"
    r"to|rightarrow|leftarrow|leftrightarrow|Rightarrow|Leftrightarrow)(?![A-Za-z])"
)
GREEK_RE = re.compile(
    r"[Α-Ωα-ω]"
    r"|\\(?:alpha|beta|gamma|delta|epsilon|varepsilon|theta|vartheta|lambda|"
    r"mu|nu|xi|pi|rho|sigma|tau|phi|varphi|chi|psi|omega|Gamma|Delta|Theta|"
    r"Lambda|Xi|Pi|Sigma|Phi|Psi|Omega)(?![A-Za-z])"
)
ASCII_OPERATOR_RE = re.compile(
    r"(?<!\w)[+\-−*/^<>](?!\w)"
    r"|[A-Za-z0-9)\]}]\s*[+\-−*/^<>]\s*[A-Za-z0-9(\[{]"
)
FUNCTION_RE = re.compile(
    r"(?:\\operatorname\s*\{)?\b(?:sin|cos|tan|cot|sec|csc|log|ln|exp|lim|"
    r"max|min|det|rank|Pr|Var|Cov|E)\b"
    r"|\\(?:sin|cos|tan|cot|sec|csc|log|ln|exp|lim|max|min|det)\b",
    re.I,
)
FUNCTION_SYNTAX_RE = re.compile(
    r"(?<![A-Za-z])(?:sin|cos|tan|cot|sec|csc|log|ln|exp|lim|max|min|det|rank|Pr|Var|Cov|E)"
    r"(?![A-Za-z])"
    r"\s*(?:\^?\s*[+\-−]?\s*\d+\s*)?(?:\(|\[|[A-Za-zΑ-Ωα-ω])",
    re.I,
)
GENERIC_FUNCTION_CALL_RE = re.compile(
    r"(?<![A-Za-z])(?:[A-Za-zΑ-Ωα-ω]|[A-Za-zΑ-Ωα-ω][₀-₉ₐ-ₜ])\s*"
    r"[\(\[]\s*[^)\]]{1,70}[\)\]]"
)
DIFFERENTIAL_RE = re.compile(
    r"(?:\bd\s*[A-Za-zΑ-Ωα-ω]\b|[∂∇]\s*[A-Za-zΑ-Ωα-ω]|"
    r"\b(?:dx|dy|dz|dt|dA|dV)\b)"
)
SUBSCRIPT_RE = re.compile(
    r"[A-Za-zΑ-Ωα-ω][₀-₉ₐ-ₜ]"
    r"|[A-Za-zΑ-Ωα-ω\\}]\s*[_^]\s*(?:\{|[A-Za-z0-9\\])"
)
URL_RE = re.compile(
    r"https?://|www\.|(?:\.com|\.org|\.edu|\.net)(?:/|\b)|"
    r"\b(?:com|org|edu|net)/(?:details|wiki|books?|articles?)(?:/|\b)[^\s]*|"
    r"(?:^|[/\s])wiki(?:pedia)?[/\s]|"
    r"\bsource\s*:|_[A-Za-z]{3,}_[A-Za-z]{3,}",
    re.I,
)
DATE_RE = re.compile(
    r"^\s*(?:"
    r"(?:19|20)\d{2}[-/.]\d{1,2}[-/.]\d{1,2}"
    r"|\d{1,2}[-/.]\d{1,2}[-/.](?:\d{2}|(?:19|20)\d{2})"
    r")(?:\s+\d{1,2}:\d{2}(?::\d{2})?)?\s*$"
)
ONLY_PAGE_NUMBER_RE = re.compile(r"^\s*(?:page\s*)?\d{1,5}\s*$", re.I)
BOILERPLATE_RE = re.compile(
    r"openstax|available\s+for\s+free|creative\s+commons|all\s+rights\s+reserved|"
    r"download(?:ed)?\s+from|solution\s+manual|powerpoint\s+slides",
    re.I,
)
SHORT_BOOK_HEADING_RE = re.compile(
    r"^\s*(?:chapter|section)\s+\d+(?:[.:]\d+){0,3}"
    r"(?:\s*[-–—:|]\s*[A-Za-z][A-Za-z0-9 ,:'()/-]{0,80})?\s*$"
    r"|^\s*(?:chapter\s+)?\d+(?:[.:]\d+)*\s*[|:–—-]?\s*"
    r"(?:contents|index|answer\s+key|learning\s+objectives)\s*$",
    re.I,
)
VISUAL_CONTEXT_RE = re.compile(
    r"\b(?:figure|fig\.|table|photo|diagram|graph\s+of|chapter|contents|"
    r"index|answer\s+key|learning\s+objectives)\b",
    re.I,
)
PROSE_WORD_RE = re.compile(r"\b[A-Za-z]{3,}\b")
SINGLE_SYMBOL_RE = re.compile(r"(?<![A-Za-z])[A-Za-z](?![A-Za-z])")

PROSE_STOPWORDS = {
    "the", "and", "that", "this", "with", "from", "where", "which", "when",
    "then", "there", "these", "those", "into", "using", "used", "given",
    "consider", "example", "exercise", "solution", "chapter", "section",
    "figure", "table", "defined", "denote", "represents", "represent",
    "available", "copyright", "book", "page", "following", "therefore",
}

SOURCE_CODE_RE = re.compile(
    r"^\s*(?:>>>|In\s*\[\d*\]:|>\s*[A-Za-z_.])"
    r"|\b(?:def|return|print|import|from|class|lambda)\s+[A-Za-z_]"
    r"|\b(?:np|pd|plt|thinkplot|numpy|pandas|torch)\.[A-Za-z_]\w*\s*\("
    r"|\b[A-Za-z_]\w*\.(?:Show|MakeFrames|corr|plot|scatter)\s*\("
    r"|\b[A-Za-z_]\w*\.[A-Za-z_]\w*\s*=\s*[A-Za-z0-9_'\"\[{(]"
    r"|\bself\.[A-Za-z_]\w*(?:\.[A-Za-z_]\w*)*"
    r"|^\s*[A-Za-z_]\w*\s*=\s*\{[^{}]*:[^{}]*\}\s*;?\s*$",
    re.I,
)
CODE_ASSIGNMENT_RE = re.compile(
    r"^\s*(?:"
    r"[A-Za-z_]\w{1,}\s*=\s*(?:"
    r"len\s*\(|[\"']|\[\s*\]|\{\s*\}|True\b|False\b|None\b|"
    r"[A-Za-z_]\w{1,}\s*$"
    r")"
    r"|[A-Za-z_]\w*\s*=\s*[A-Za-z_]\w*\s*\([^=]{0,80}\)\s*$"
    r")",
    re.I,
)
FILL_BLANK_RE = re.compile(r"(?:_{3,}|\.{4,}|—{3,})")
CLIPPED_PROSE_PREFIX_RE = re.compile(r"^[a-z]{4,}\b")
MATRIX_DELIMITER_RE = re.compile(r"[\[\]⎡⎢⎣⎤⎥⎦]")
ORPHAN_DELIMITER_RE = re.compile(r"^[\s/|()[\]{}⎡⎢⎣⎤⎥⎦._-]+$")
LEADING_FORMULA_RELATION_RE = re.compile(
    r"[=≠≈≤≥]"
)
PLAIN_NUMBER_PART_RE = re.compile(
    r"^\s*(?:[A-Za-z]['′]?|[abcdrstxyz]\.?|"
    r"[-−–—]?\s*\d+(?:\.\d+)?|"
    r"\(\s*[-−–—]?\d+(?:\.\d+)?\s*,\s*[-−–—]?\d+(?:\.\d+)?\s*\))\s*$",
    re.I,
)
COLLAPSED_PROSE_RUN_RE = re.compile(r"[A-Za-z]{24,}")
ISOLATED_SYMBOL_RE = re.compile(r"^[A-Za-zΑ-Ωα-ω](?:[.'′])?$")
ISOLATED_SCALAR_RE = re.compile(r"^[+\-−–]?\s*\d+(?:\.\d+)?[.]?$")
LEADING_RELATION_RE = re.compile(r"^\s*[=≠≈≤≥]")
TRAILING_INCOMPLETE_RE = re.compile(r"(?:[=+\-−–*/^]\s*|[\[{(]\s*)$")
GLYPH_MATRIX_LHS_RE = re.compile(
    r"(?:^|[/\s])(?:[A-Za-zΑ-Ωα-ω](?:\s*[_^]\s*\w+)?)\s*="
)
SIMPLE_BLANK_ANSWER_RE = re.compile(
    r"^\s*(?:[ivxlcdm]+[.)]\s*)?[A-Za-zΑ-Ωα-ω]"
    r"(?:\s*[_^]\s*(?:\w+|\{[^}]+\}))?\s*=\s*"
    r"(?:_{3,}|\.{4,}|—{3,})[.\s]*$",
    re.I,
)
COORDINATE_LIST_RE = re.compile(
    r"^\s*(?:\d+[.)]\s*)?"
    r"\(\s*[-−–]?\s*\d+(?:\.\d+)?\s*,\s*[-−–]?\s*\d+(?:\.\d+)?\s*\)"
    r"(?:\s*(?:,|and|or)\s*"
    r"\(\s*[-−–]?\s*\d+(?:\.\d+)?\s*,\s*[-−–]?\s*\d+(?:\.\d+)?\s*\))*"
    r"[.\s]*$",
    re.I,
)
SIMPLE_SCALAR_RELATION_RE = re.compile(
    r"^\s*(?:\d+[.)]\s*)?[A-Za-zΑ-Ωα-ω]"
    r"(?:\s*[_^]\s*\w+)?\s*(?:<|>|≤|≥|=|≈|≠)\s*"
    r"[-−–]?\s*\d+(?:\.\d+)?[.\s]*$"
)
INSTRUCTION_OR_ANSWER_PROSE_RE = re.compile(
    r"^\s*(?:press|substitute)\b|\banswers?\s+may\s+vary\b",
    re.I,
)


def _compact_text(text: str) -> str:
    return " ".join(str(text or "").replace("\x00", " ").split())


def _axis_like_numeric_stack(text: str, source_line_count: int) -> bool:
    """Detect graph ticks/answer lists accidentally joined as a formula stack."""
    if source_line_count < 3 or MATRIX_DELIMITER_RE.search(text):
        return False
    parts = [part.strip() for part in text.split("/") if part.strip()]
    if len(parts) < 3:
        return False
    numeric_parts = sum(
        bool(
            PLAIN_NUMBER_PART_RE.fullmatch(part)
            or re.fullmatch(r"[+\-−–—]+", part)
        )
        for part in parts
    )
    return numeric_parts / len(parts) >= 0.58


def _graph_like_text_crop(
    features: dict[str, Any],
    visual: dict[str, Any] | None,
    merge_reason: str,
    source_line_count: int,
) -> bool:
    """Use crop morphology to veto graph axes that resemble math text."""
    if not visual or features["has_matrix_delimiter"]:
        return False
    horizontal = int(visual.get("long_horizontal_line_count", 0))
    vertical = int(visual.get("long_vertical_line_count", 0))
    lines = horizontal + vertical
    color_ratio = float(visual.get("color_ratio", 0.0))
    edge_ink = float(visual.get("edge_ink_ratio", 0.0))
    aspect = float(visual.get("aspect_ratio", 99.0))
    row_bands = int(visual.get("row_bands", 0))
    lacks_structure = (
        features["strong_math"] == 0
        and features["functions"] == 0
        and features["generic_functions"] == 0
        and features["subscripts"] == 0
    )
    # v3.3 still admitted colored graph callouts such as coordinate labels,
    # directrix labels and isolated derivatives.  Formula crops in the source
    # books are overwhelmingly monochrome; color plus a compact/callout shape
    # is therefore a stronger graph signal than mathematical-looking text.
    colored_graph_callout = (
        color_ratio >= 0.025
        and (
            aspect <= 4.0
            or source_line_count >= 2
            or lines >= 1
            or edge_ink >= 0.12
        )
    )
    ruled_graph_callout = (
        lines >= 3
        and edge_ink >= 0.12
        and aspect <= 3.2
        and not features["has_matrix_delimiter"]
    )
    compact_colored_label_stack = (
        merge_reason == "compact_vertical_math_stack"
        and source_line_count >= 3
        and color_ratio >= 0.008
        and aspect <= 1.15
        and row_bands >= 3
    )
    compact_axis = (
        source_line_count >= 2
        and lacks_structure
        and aspect <= 1.25
        and (
            (lines >= 2 and (color_ratio >= 0.006 or edge_ink >= 0.025))
            or row_bands >= 8
            or (source_line_count >= 3 and color_ratio >= 0.008)
        )
    )
    colored_axis = (
        merge_reason == "compact_vertical_math_stack"
        and lacks_structure
        and color_ratio >= 0.025
        and lines >= 2
    )
    incomplete_ruled_fragment = (
        source_line_count == 1
        and features["functions"] >= 1
        and features["operators"] == 0
        and features["digits"] == 0
        and horizontal >= 2
        and edge_ink >= 0.20
    )
    return bool(
        colored_graph_callout
        or ruled_graph_callout
        or compact_colored_label_stack
        or compact_axis
        or colored_axis
        or incomplete_ruled_fragment
    )


def _clean_compact_formula_crop(
    features: dict[str, Any],
    visual: dict[str, Any] | None,
    source_line_count: int,
) -> bool:
    """Rescue only clean, self-contained short formulas from the review branch.

    The v3.2 audit contained both genuine short expressions and graph labels in
    the same text-evidence class.  Text alone cannot separate them reliably.
    This narrow branch therefore requires a clean monochrome crop without the
    long lines normally contributed by graph axes, grids, or callouts.
    """
    if not visual or source_line_count > 2:
        return False
    color_ratio = float(visual.get("color_ratio", 0.0))
    edge_ink = float(visual.get("edge_ink_ratio", 0.0))
    horizontal = int(visual.get("long_horizontal_line_count", 0))
    vertical = int(visual.get("long_vertical_line_count", 0))
    if (
        color_ratio > 0.012
        or edge_ink > 0.20
        or horizontal > 1
        or vertical > 1
    ):
        return False

    text = features["text"]
    numbered_parenthesized_power = bool(
        re.fullmatch(
            r"\s*\d+[.]\s*\([^)]*[+\-−*/][^)]*\)\s*\d+\s*[.]?\s*",
            text,
        )
    )
    simple_stacked_fraction = bool(
        source_line_count == 2
        and re.fullmatch(
            r"\s*[+\-−]?\s*(?:\d+|[A-Za-z])\s*/\s*"
            r"[+\-−]?\s*(?:\d+|[A-Za-z])\s*",
            text,
        )
    )
    compact_greek_scalar = bool(
        features["greek"] >= 1
        and features["digits"] >= 1
        and features["length"] <= 12
        and features["prose_words"] == 0
    )
    compact_numeric_interval = bool(
        features["has_matrix_delimiter"]
        and features["digits"] >= 2
        and features["length"] <= 32
        and features["prose_words"] == 0
        and re.search(r"[\[\(].*[,;].*[\]\)]", text)
    )
    glyph_encoded_compact_stack = bool(
        source_line_count == 2
        and features["digits"] >= 2
        and features["operators"] >= 1
        and features["prose_words"] == 0
        and features["length"] <= 28
        and re.search(r"[\ue000-\uf8ff]", text)
    )
    return bool(
        numbered_parenthesized_power
        or simple_stacked_fraction
        or compact_greek_scalar
        or compact_numeric_interval
        or glyph_encoded_compact_stack
    )


def _has_leading_formula_relation(text: str) -> bool:
    """Return true when a relation follows a compact formula-like left side."""
    relation = LEADING_FORMULA_RELATION_RE.search(text)
    if relation is None or relation.start() > 50:
        return False
    left = text[:relation.start()].strip()
    if not left or not re.match(r"^[A-Za-zΑ-Ωα-ω([{]", left):
        return False
    # A genuine left-hand expression may contain one function/variable name;
    # two or more prose words indicate that the relation is embedded in prose.
    return len(PROSE_WORD_RE.findall(left)) <= 1


def _recall_safe_formula_review(
    features: dict[str, Any],
    source_line_count: int,
) -> bool:
    """Identify structured candidates that must not be irreversibly dropped.

    This is intentionally a review-only recall guard.  It does not call a
    candidate high confidence and it does not bypass the frozen downstream
    image, OCR-quality or parser gates.  The v3.4 audit showed that PDF fraction
    bars, coloured textbook callouts and joined vertical spans can make real
    equations look like blanks, graph axes or boundary fragments.
    """
    text = features["text"]
    relation_count = len(re.findall(r"[=≠≈≤≥]|(?:<|>)(?!=)", text))
    structured_tokens = (
        features["operators"]
        + features["functions"]
        + features["function_syntax"]
        + features["generic_functions"]
        + features["differentials"]
        + features["subscripts"]
        + features["greek"]
    )
    formula_block = bool(
        relation_count >= 2
        and source_line_count <= 60
        and features["prose_words"] <= 16
    )
    compact_relation = bool(
        relation_count >= 1
        and source_line_count <= 12
        and features["prose_words"] <= features["functions"]
        and (
            structured_tokens >= 1
            or features["digits"] >= 1
            or features["strong_math"] >= 2
        )
    )
    matrix_or_system = bool(
        source_line_count >= 2
        and source_line_count <= 40
        and (
            features["has_matrix_delimiter"]
            or relation_count >= 2
        )
        and features["digits"] + features["letters"] >= 3
    )
    compact_function = bool(
        source_line_count <= 4
        and features["length"] <= 100
        and features["prose_words"] <= features["functions"]
        and (
            features["generic_functions"] >= 1
            or (
                features["function_syntax"] >= 1
                and features["functions"] >= 1
            )
        )
    )
    compact_symbolic_expression = bool(
        source_line_count <= 3
        and features["length"] <= 90
        and features["prose_words"] == 0
        and features["math_fonts"] >= 1
        and features["symbol_density"] >= 0.10
        and (
            features["operators"] >= 1
            or features["strong_math"] >= 1
            or features["subscripts"] >= 1
            or features["greek"] >= 1
        )
    )
    return bool(
        formula_block
        or compact_relation
        or matrix_or_system
        or compact_function
        or compact_symbolic_expression
    )


def _graph_recall_safe_formula_review(
    features: dict[str, Any],
    source_line_count: int,
) -> bool:
    """Require explicit equation structure before overriding graph morphology."""
    text = features["text"]
    relation_count = len(re.findall(r"[=≠≈≤≥]|(?:<|>)(?!=)", text))
    return bool(
        (
            relation_count >= 1
            and features["prose_words"] <= features["functions"]
            and (
                features["operators"] >= 1
                or features["functions"] >= 1
                or features["generic_functions"] >= 1
                or features["digits"] >= 1
                or features["subscripts"] >= 1
                or features["greek"] >= 1
            )
        )
        or (
            features["has_matrix_delimiter"]
            and source_line_count >= 2
            and features["digits"] + features["letters"] >= 3
        )
    )


def text_features(text: str, fonts: str | list[str] = "") -> dict[str, Any]:
    compact = _compact_text(text)
    font_values = (
        [item for item in fonts.split(";") if item]
        if isinstance(fonts, str)
        else [str(item) for item in fonts]
    )
    strong = len(STRONG_MATH_RE.findall(compact))
    greek = len(GREEK_RE.findall(compact))
    operators = len(ASCII_OPERATOR_RE.findall(compact))
    functions = len(FUNCTION_RE.findall(compact))
    function_syntax = len(FUNCTION_SYNTAX_RE.findall(compact))
    generic_functions = len(GENERIC_FUNCTION_CALL_RE.findall(compact))
    differentials = len(DIFFERENTIAL_RE.findall(compact))
    subscripts = len(SUBSCRIPT_RE.findall(compact))
    math_fonts = sum(bool(MATH_FONT_RE.search(font)) for font in font_values)
    words = [
        match.group(0).lower()
        for match in PROSE_WORD_RE.finditer(compact)
        if match.start() == 0 or compact[match.start() - 1] != "\\"
    ]
    stopwords = sum(word in PROSE_STOPWORDS for word in words)
    single_symbols = len(SINGLE_SYMBOL_RE.findall(compact))
    digits = len(re.findall(r"\d", compact))
    letters = len(re.findall(r"[A-Za-zΑ-Ωα-ω]", compact))
    symbol_chars = len(re.findall(r"[=+\-−*/^_<>≤≥∑∏∫√∞∂∇±×÷()[\]{}|]", compact))
    length = len(compact)
    return {
        "text": compact,
        "length": length,
        "strong_math": strong,
        "greek": greek,
        "operators": operators,
        "functions": functions,
        "function_syntax": function_syntax,
        "generic_functions": generic_functions,
        "differentials": differentials,
        "subscripts": subscripts,
        "math_fonts": math_fonts,
        "prose_words": len(words),
        "prose_stopwords": stopwords,
        "single_symbols": single_symbols,
        "digits": digits,
        "letters": letters,
        "symbol_chars": symbol_chars,
        "symbol_density": round(symbol_chars / max(length, 1), 5),
        "has_url": bool(URL_RE.search(compact)),
        "has_boilerplate": bool(
            BOILERPLATE_RE.search(compact)
            or SHORT_BOOK_HEADING_RE.fullmatch(compact)
        ),
        "is_date": bool(DATE_RE.fullmatch(compact)),
        "is_page_number": bool(ONLY_PAGE_NUMBER_RE.fullmatch(compact)),
        "looks_like_source_code": bool(SOURCE_CODE_RE.search(compact)),
        "looks_like_code_assignment": bool(CODE_ASSIGNMENT_RE.search(compact)),
        "has_fill_blank": bool(FILL_BLANK_RE.search(compact)),
        "has_matrix_delimiter": bool(MATRIX_DELIMITER_RE.search(compact)),
        "orphan_delimiter_fragment": bool(
            ORPHAN_DELIMITER_RE.fullmatch(compact)
            or (
                not re.search(r"[A-Za-z0-9Α-Ωα-ω]", compact)
                and f"{compact} /".count("/") >= 1
            )
        ),
        "has_collapsed_prose_run": bool(COLLAPSED_PROSE_RUN_RE.search(compact)),
        "has_collapsed_prose_layout": bool(
            " " not in compact
            and length >= 18
            and letters / max(length, 1) >= 0.72
            and symbol_chars / max(length, 1) < 0.12
        ),
        "isolated_symbol_or_scalar": bool(
            ISOLATED_SYMBOL_RE.fullmatch(compact)
            or ISOLATED_SCALAR_RE.fullmatch(compact)
        ),
        "leading_relation_fragment": bool(LEADING_RELATION_RE.search(compact)),
        "trailing_incomplete_fragment": bool(TRAILING_INCOMPLETE_RE.search(compact)),
    }


def classify_text_candidate(
    text: str,
    fonts: str | list[str] = "",
    *,
    merge_reason: str = "",
    source_line_count: int = 1,
    visual: dict[str, Any] | None = None,
) -> dict[str, Any]:
    """Return accepted_high_confidence, accepted_review, or rejected_pre_ocr."""
    f = text_features(text, fonts)
    compact = f["text"]
    if not compact:
        return {
            "decision": "rejected_pre_ocr",
            "reason": "empty_pdf_text_layer",
            "score": -20.0,
            "features": f,
        }
    if f["has_url"] or f["has_boilerplate"]:
        return {
            "decision": "rejected_pre_ocr",
            "reason": "url_or_book_boilerplate",
            "score": -20.0,
            "features": f,
        }
    if f["is_date"] or f["is_page_number"]:
        return {
            "decision": "rejected_pre_ocr",
            "reason": "date_or_page_number_only",
            "score": -15.0,
            "features": f,
        }
    if f["looks_like_source_code"] or f["looks_like_code_assignment"]:
        return {
            "decision": "rejected_pre_ocr",
            "reason": "source_code_or_console_text",
            "score": -12.0,
            "features": f,
        }
    if (
        INSTRUCTION_OR_ANSWER_PROSE_RE.search(compact)
        and f["prose_words"] >= 2
    ):
        return {
            "decision": "rejected_pre_ocr",
            "reason": "instruction_or_answer_prose_not_formula",
            "score": -11.0,
            "features": f,
        }
    fill_blank_formula = bool(
        f["has_fill_blank"]
        and source_line_count <= 60
        and not SIMPLE_BLANK_ANSWER_RE.fullmatch(compact)
        and (
            _recall_safe_formula_review(f, source_line_count)
            or (
                f["symbol_density"] >= 0.05
                and (
                    f["strong_math"]
                    + f["operators"]
                    + f["functions"]
                    + f["generic_functions"]
                    + f["subscripts"]
                ) >= 3
            )
        )
    )
    if f["has_fill_blank"] and not fill_blank_formula:
        return {
            "decision": "rejected_pre_ocr",
            "reason": "exercise_fill_blank_or_answer_field",
            "score": -12.0,
            "features": f,
        }
    if (
        CLIPPED_PROSE_PREFIX_RE.search(compact)
        and f["strong_math"] == 0
        and f["functions"] == 0
        and f["generic_functions"] == 0
        and f["prose_words"] >= 1
    ):
        return {
            "decision": "rejected_pre_ocr",
            "reason": "clipped_prose_or_label_fragment",
            "score": -11.0,
            "features": f,
        }
    if (
        compact.rstrip().endswith("?")
        and f["prose_words"] >= 1
        and f["symbol_density"] < 0.12
    ):
        return {
            "decision": "rejected_pre_ocr",
            "reason": "question_or_prompt_with_inline_math",
            "score": -10.5,
            "features": f,
        }
    # A bracket plus a left-hand assignment is not enough to prove that the
    # matrix entries are inside the crop.  v3.3 showed edge-only glyph stacks;
    # complete matrices are now repaired in build_ebook_full_index before this
    # classifier is called.
    if (
        visual
        and source_line_count >= 2
        and f["strong_math"] >= 1
        and f["digits"] == 0
        and f["functions"] == 0
        and f["generic_functions"] == 0
        and float(visual.get("aspect_ratio", 99.0)) < 0.8
        and int(visual.get("row_bands", 0)) >= 5
        and re.search(r"[\ue000-\uf8ff-]", compact)
    ):
        return {
            "decision": "rejected_pre_ocr",
            "reason": "incomplete_matrix_edge_fragment",
            "score": -10.5,
            "features": f,
        }
    if f["isolated_symbol_or_scalar"]:
        return {
            "decision": "rejected_pre_ocr",
            "reason": "isolated_symbol_or_scalar_fragment",
            "score": -12.0,
            "features": f,
        }
    # A leading/trailing open relation must be repaired upstream by joining
    # its neighbouring PDF span.  Sending an unresolved continuation to OCR
    # produces an incomplete formula record, so it remains rejected here.
    if f["leading_relation_fragment"] or f["trailing_incomplete_fragment"]:
        # A single open continuation is still rejected.  A multi-line formula
        # block may merely end with an extra joined relation marker; preserve
        # it for downstream OCR/parser review instead of deleting the complete
        # equations already present in the crop.
        if (
            not f["leading_relation_fragment"]
            and source_line_count >= 2
            and len(re.findall(r"[=≠≈≤≥]", compact)) >= 2
            and _recall_safe_formula_review(f, source_line_count)
        ):
            return {
                "decision": "accepted_review",
                "reason": "structured_formula_boundary_requires_ocr_review",
                "score": 2.0,
                "features": f,
            }
        return {
            "decision": "rejected_pre_ocr",
            "reason": "incomplete_relation_or_delimiter_fragment",
            "score": -11.5,
            "features": f,
        }
    if f["orphan_delimiter_fragment"]:
        if (
            re.search(r"[\[(].*∞.*[,;].*∞.*[\])]", compact)
        ):
            return {
                "decision": "accepted_review",
                "reason": "symbolic_delimiter_expression_requires_ocr_review",
                "score": 1.5,
                "features": f,
            }
        return {
            "decision": "rejected_pre_ocr",
            "reason": "orphan_math_delimiter_fragment",
            "score": -11.0,
            "features": f,
        }
    if (
        (f["has_collapsed_prose_run"] or f["has_collapsed_prose_layout"])
        and f["strong_math"] <= 1
        and f["symbol_density"] < 0.12
    ):
        return {
            "decision": "rejected_pre_ocr",
            "reason": "collapsed_prose_with_weak_math_evidence",
            "score": -10.5,
            "features": f,
        }
    if _axis_like_numeric_stack(compact, source_line_count):
        if (
            re.search(r"[=≠≈≤≥]", compact)
            and _recall_safe_formula_review(f, source_line_count)
        ):
            return {
                "decision": "accepted_review",
                "reason": "axis_ambiguous_structured_formula_requires_ocr_review",
                "score": 1.5,
                "features": f,
            }
        return {
            "decision": "rejected_pre_ocr",
            "reason": "axis_tick_or_answer_list_stack",
            "score": -10.0,
            "features": f,
        }
    if merge_reason == "compact_vertical_math_stack" and visual:
        graph_like_stack = (
            source_line_count >= 6
            and not f["has_matrix_delimiter"]
            and (
                int(visual.get("row_bands", 0)) >= 14
                or float(visual.get("height", 0))
                > float(visual.get("width", 1)) * 2.2
            )
        )
        if graph_like_stack:
            return {
                "decision": "rejected_pre_ocr",
                "reason": "graph_axis_text_stack",
                "score": -9.0,
                "features": f,
            }
    if _graph_like_text_crop(f, visual, merge_reason, source_line_count):
        if _graph_recall_safe_formula_review(f, source_line_count):
            return {
                "decision": "accepted_review",
                "reason": "graph_ambiguous_structured_formula_requires_ocr_review",
                "score": 1.5,
                "features": f,
            }
        return {
            "decision": "rejected_pre_ocr",
            "reason": "graph_axis_visual_morphology",
            "score": -9.0,
            "features": f,
        }

    if fill_blank_formula:
        return {
            "decision": "accepted_review",
            "reason": "formula_with_answer_field_requires_ocr_review",
            "score": 3.0,
            "features": f,
        }

    if (
        f["prose_words"] >= 2
        and f["strong_math"] == 0
        and f["operators"] <= 1
        and f["functions"] == 0
        and f["function_syntax"] == 0
        and f["generic_functions"] == 0
        and f["subscripts"] == 0
    ):
        return {
            "decision": "rejected_pre_ocr",
            "reason": "descriptive_math_label_not_formula",
            "score": -8.0,
            "features": f,
        }

    evidence = (
        f["strong_math"] * 4.0
        + min(f["operators"], 5) * 1.7
        + min(f["functions"], 3) * 2.2
        + min(f["generic_functions"], 3) * 1.6
        + min(f["differentials"], 3) * 1.3
        + min(f["subscripts"], 4) * 1.7
        + min(f["greek"], 4) * 1.3
        + min(f["math_fonts"], 5) * 1.1
        + min(f["single_symbols"], 6) * 0.25
    )
    prose_penalty = max(0, f["prose_words"] - 3) * 0.9
    prose_penalty += f["prose_stopwords"] * 0.8
    if f["length"] > 260:
        prose_penalty += 4.0
    if f["prose_words"] >= 8 and f["strong_math"] == 0:
        prose_penalty += 6.0
    score = round(evidence - prose_penalty, 4)

    explicit_relation = f["strong_math"] >= 1
    leading_formula_relation = _has_leading_formula_relation(compact)
    structured_math = (
        f["operators"] >= 1
        or f["functions"] >= 1
        or f["generic_functions"] >= 1
        or f["differentials"] >= 1
        or f["subscripts"] >= 1
        or f["greek"] >= 1
    )
    dense_prose = (
        f["prose_words"] >= 8
        and f["strong_math"] == 0
        and f["operators"] <= 1
        and f["functions"] == 0
        and f["generic_functions"] == 0
        and f["subscripts"] == 0
    )
    prose_with_inline_math = (
        f["prose_words"] >= 4
        and f["length"] >= 35
        and f["symbol_density"] < 0.16
        and f["prose_stopwords"] >= 1
        and not leading_formula_relation
    )

    if dense_prose:
        decision, reason = "rejected_pre_ocr", "long_prose_with_weak_math_evidence"
    elif prose_with_inline_math:
        decision, reason = (
            "rejected_pre_ocr",
            "prose_with_inline_math_not_isolated",
        )
    elif (
        explicit_relation
        and (structured_math or score >= 5.0)
        and (
            f["prose_words"] <= 4
            or f["symbol_density"] >= 0.18
            or (f["strong_math"] >= 2 and f["prose_words"] <= 6)
            or (leading_formula_relation and f["prose_words"] <= 7)
        )
    ):
        decision, reason = "accepted_high_confidence", "explicit_relation_and_math_structure"
    elif (
        f["strong_math"] >= 2
        and f["prose_words"] <= 2
        and f["symbol_density"] >= 0.12
    ):
        decision, reason = "accepted_high_confidence", "multiple_strong_math_symbols"
    elif f["function_syntax"] >= 1 and (
        f["operators"] >= 1 or f["subscripts"] >= 1 or f["greek"] >= 1
    ) and (
        f["prose_words"] <= 2
        and f["prose_stopwords"] == 0
        and f["length"] <= 90
        and source_line_count <= 4
    ):
        decision, reason = "accepted_high_confidence", "function_with_structured_argument"
    elif (
        score >= 6.0
        and f["prose_words"] <= 2
        and f["prose_stopwords"] == 0
        and f["math_fonts"] >= 1
        and (
            f["operators"] >= 2
            or f["function_syntax"] >= 1
            or f["subscripts"] >= 1
            or f["greek"] >= 1
        )
    ):
        decision, reason = "accepted_high_confidence", "high_combined_math_evidence"
    elif (
        score >= 3.5
        and f["prose_words"] <= 2
        and f["length"] <= 100
        and (
            (
                f["strong_math"] >= 1
                and (
                    f["operators"] >= 1
                    or f["functions"] >= 1
                    or f["subscripts"] >= 1
                    or f["greek"] >= 1
                    or f["symbol_density"] >= 0.18
                )
            )
            or (
                f["generic_functions"] >= 1
                and (
                    f["operators"] >= 1
                    or f["differentials"] >= 1
                    or f["subscripts"] >= 1
                    or f["greek"] >= 1
                )
            )
            or (
                f["greek"] >= 1
                and (f["operators"] >= 1 or f["math_fonts"] >= 2)
            )
            or (
                f["operators"] >= 2
                and f["prose_words"] == 0
                and f["symbol_density"] >= 0.18
            )
            or (
                f["operators"] >= 1
                and f["digits"] >= 2
                and f["prose_words"] == 0
                and f["symbol_density"] >= 0.20
            )
        )
    ):
        decision, reason = "accepted_review", "moderate_math_evidence"
    elif (
        source_line_count <= 2
        and f["length"] <= 40
        and f["prose_words"] == 0
        and f["math_fonts"] >= 1
        and f["symbol_density"] >= 0.20
        and (
            f["subscripts"] >= 1
            or (f["greek"] >= 1 and f["digits"] >= 1)
            or (f["operators"] >= 1 and f["single_symbols"] >= 3)
        )
    ):
        decision, reason = "accepted_review", "compact_structured_math_expression"
    elif _clean_compact_formula_crop(f, visual, source_line_count):
        decision, reason = "accepted_review", "clean_compact_formula_crop"
    elif (
        COORDINATE_LIST_RE.fullmatch(compact)
        and visual
        and float(visual.get("color_ratio", 0.0)) < 0.02
        and int(visual.get("long_vertical_line_count", 0)) <= 1
    ):
        decision, reason = "accepted_review", "clean_coordinate_expression"
    elif SIMPLE_SCALAR_RELATION_RE.fullmatch(compact):
        decision, reason = "accepted_review", "simple_scalar_relation"
    elif _recall_safe_formula_review(f, source_line_count):
        decision, reason = (
            "accepted_review",
            "structured_formula_requires_downstream_review",
        )
    else:
        decision, reason = "rejected_pre_ocr", "insufficient_math_evidence"

    return {
        "decision": decision,
        "reason": reason,
        "score": score,
        "features": f,
    }


def visual_features(image: Image.Image) -> dict[str, Any]:
    rgb = np.asarray(image.convert("RGB"))
    gray = np.asarray(image.convert("L"))
    height, width = gray.shape
    ink = gray < 210
    dark = gray < 110
    color_range = rgb.max(axis=2).astype(np.int16) - rgb.min(axis=2).astype(np.int16)
    colored = (color_range > 28) & (gray < 245)
    row_density = ink.mean(axis=1) if height else np.array([0.0])
    col_density = ink.mean(axis=0) if width else np.array([0.0])

    active_rows = row_density > max(0.003, float(row_density.mean()) * 0.55)
    row_bands = 0
    inside = False
    for active in active_rows:
        if active and not inside:
            row_bands += 1
            inside = True
        elif not active:
            inside = False

    edge = np.concatenate([
        ink[: max(1, height // 20), :].ravel(),
        ink[-max(1, height // 20):, :].ravel(),
        ink[:, : max(1, width // 50)].ravel(),
        ink[:, -max(1, width // 50):].ravel(),
    ])
    return {
        "width": int(width),
        "height": int(height),
        "aspect_ratio": round(width / max(height, 1), 5),
        "ink_ratio": round(float(ink.mean()), 6),
        "dark_ratio": round(float(dark.mean()), 6),
        "color_ratio": round(float(colored.mean()), 6),
        "row_bands": int(row_bands),
        "active_row_ratio": round(float(active_rows.mean()), 6),
        "active_column_ratio": round(float((col_density > 0.002).mean()), 6),
        "long_horizontal_line_count": int((row_density > 0.55).sum()),
        "long_vertical_line_count": int((col_density > 0.55).sum()),
        "edge_ink_ratio": round(float(edge.mean()), 6),
    }


def classify_visual_candidate(
    image: Image.Image,
    method: str,
    *,
    context_text: str = "",
    position: dict[str, float] | None = None,
) -> dict[str, Any]:
    f = visual_features(image)
    compact_context = _compact_text(context_text)
    position = position or {}
    center_y = float(position.get("center_y_ratio", 0.5))
    context_is_figure = bool(VISUAL_CONTEXT_RE.search(compact_context))
    if (
        method == "raster_high_recall_scanned_page"
        and (center_y < 0.075 or center_y > 0.925)
    ):
        decision, reason, score = "rejected_pre_ocr", "page_header_footer_region", -12.0
    elif method == "embedded_image_region" and context_is_figure:
        decision, reason, score = (
            "rejected_pre_ocr",
            "embedded_figure_caption_context",
            -11.0,
        )
    elif f["width"] < 28 or f["height"] < 12:
        decision, reason, score = "rejected_pre_ocr", "tiny_visual_fragment", -10.0
    elif f["ink_ratio"] < 0.003:
        decision, reason, score = "rejected_pre_ocr", "near_blank_region", -10.0
    elif f["color_ratio"] > 0.12:
        decision, reason, score = "rejected_pre_ocr", "colored_figure_or_diagram", -8.0
    elif f["dark_ratio"] > 0.55 or f["ink_ratio"] > 0.72:
        decision, reason, score = "rejected_pre_ocr", "dense_graphic_region", -8.0
    elif f["aspect_ratio"] < 0.45:
        decision, reason, score = "rejected_pre_ocr", "vertical_margin_or_fragment", -7.0
    elif (
        f["long_horizontal_line_count"] >= 3
        and f["long_vertical_line_count"] >= 3
        and f["row_bands"] >= 4
    ):
        decision, reason, score = "rejected_pre_ocr", "wide_grid_or_table_graphic", -7.0
    elif (
        f["long_horizontal_line_count"] >= 1
        and f["long_vertical_line_count"] >= 1
        and f["aspect_ratio"] < 4.0
        and f["row_bands"] >= 4
    ):
        decision, reason, score = "rejected_pre_ocr", "axis_table_or_boxed_graphic", -6.0
    elif f["edge_ink_ratio"] > 0.42 and f["aspect_ratio"] < 1.2:
        decision, reason, score = "rejected_pre_ocr", "edge_touching_graphic_region", -5.0
    elif method == "embedded_image_region" and (
        (f["height"] > 360 and f["aspect_ratio"] < 5.0)
        or f["row_bands"] > 14
        or f["active_row_ratio"] > 0.66
        or f["color_ratio"] > 0.05
    ):
        decision, reason, score = (
            "rejected_pre_ocr",
            "large_or_complex_embedded_graphic",
            -5.0,
        )
    elif method == "embedded_image_region" and not (
        f["aspect_ratio"] >= 1.35
        and 0.003 <= f["ink_ratio"] <= 0.36
        and 1 <= f["row_bands"] <= 12
        and f["color_ratio"] <= 0.05
    ):
        decision, reason, score = (
            "rejected_pre_ocr",
            "non_formula_embedded_graphic",
            -4.0,
        )
    elif method == "embedded_image_region":
        # The v3.1 audit sampled 20/20 false positives from the 112 surviving
        # embedded images (plots, logos, circuits and diagrams).  Embedded
        # images have no isolated text evidence at this stage, so they are
        # retained only as rejected audit evidence and never sent to OCR.
        decision, reason, score = (
            "rejected_pre_ocr",
            "embedded_image_without_isolated_formula_text",
            -4.0,
        )
    elif method == "raster_high_recall_scanned_page" and not (
        1.2 <= f["aspect_ratio"] <= 8.0
        and 0.008 <= f["ink_ratio"] <= 0.26
        and f["color_ratio"] <= 0.02
        and 1 <= f["row_bands"] <= 6
        and f["active_row_ratio"] <= 0.72
        and 0.15 <= f["active_column_ratio"] <= 0.90
        and f["long_horizontal_line_count"] <= 1
        and (
            f["long_vertical_line_count"] <= 1
            or (
                f["height"] <= 40
                and f["long_horizontal_line_count"] == 0
                and f["long_vertical_line_count"] >= 6
                and f["aspect_ratio"] <= 8.0
            )
        )
        and f["edge_ink_ratio"] <= 0.30
    ):
        decision, reason, score = (
            "rejected_pre_ocr",
            "raster_non_formula_layout",
            -4.0,
        )
    elif (
        method == "raster_high_recall_scanned_page"
        and f["height"] <= 40
        and f["long_horizontal_line_count"] == 0
        and f["long_vertical_line_count"] >= 6
    ):
        # The v3.3 audit contained one clear textless equation (E_x = 0) whose
        # compact glyph strokes create several dense vertical columns.  Rescue
        # only this narrow morphology family.  Ordinary title/version/prose
        # bands and graph fragments remain rejected, so the branch does not
        # become a generic morphology-only OCR bypass.
        decision, reason, score = (
            "accepted_review",
            "raster_formula_candidate_requires_ocr_review",
            3.0,
        )
    elif method == "raster_high_recall_scanned_page":
        decision, reason, score = (
            "rejected_pre_ocr",
            "raster_without_isolated_formula_text",
            -4.0,
        )
    else:
        score = round(
            4.0
            + min(f["row_bands"], 5) * 0.35
            + min(f["active_column_ratio"], 0.9) * 1.5
            - max(0.0, f["color_ratio"] - 0.02) * 10.0,
            4,
        )
        # No text evidence exists. Keep the gate conservative and let the
        # frozen downstream image screen make the next decision.
        decision = "accepted_review"
        reason = (
            "raster_formula_candidate_requires_ocr_review"
            if method == "raster_high_recall_scanned_page"
            else "embedded_image_candidate_requires_ocr_review"
        )
    return {
        "decision": decision,
        "reason": reason,
        "score": score,
        "features": f,
    }


def classify_candidate(
    *,
    text: str,
    fonts: str | list[str],
    image: Image.Image,
    method: str,
    context_text: str = "",
    position: dict[str, float] | None = None,
    merge_reason: str = "",
    source_line_count: int = 1,
) -> dict[str, Any]:
    if method == "pdf_text_math_layout":
        visual = visual_features(image)
        result = classify_text_candidate(
            text,
            fonts,
            merge_reason=merge_reason,
            source_line_count=source_line_count,
            visual=visual,
        )
        result["visual_features"] = visual
        return result
    result = classify_visual_candidate(
        image,
        method,
        context_text=context_text,
        position=position,
    )
    result["text_features"] = text_features(text, fonts)
    return result
