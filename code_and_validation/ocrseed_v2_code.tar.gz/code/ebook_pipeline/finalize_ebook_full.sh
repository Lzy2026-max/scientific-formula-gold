#!/usr/bin/env bash
set -euo pipefail

PROJECT=${PROJECT:-$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)}
BASE_PACKAGE=${BASE_PACKAGE:-$PROJECT/common/formula_kb_production}
EXTENSION=${EXTENSION:-$PROJECT/ebook_pipeline}
PY=${PY:-$(command -v python3 || command -v python || true)}
RESULT_PARENT=${RESULT_PARENT:-$PROJECT/results}
SEED=${1:-2026081001}
RUN_ROOT="$RESULT_PARENT/ebook30_ocrseed_v2_seed${SEED}"
MANIFEST="$RUN_ROOT/index/execution_manifest.json"
MERGED="$RUN_ROOT/merged_results"
OFFICIAL="$RUN_ROOT/official_results"
ARCHIVE_DIR="$RESULT_PARENT/archives"
ARCHIVE="$ARCHIVE_DIR/ebook30_ocrseed_v2_seed${SEED}_official_audit_results.tar.gz"

if [[ ! -f "$MANIFEST" ]]; then
  echo "missing_index_manifest=$MANIFEST" >&2
  exit 1
fi
EXPECTED=$("$PY" -c "import json; print(json.load(open('$MANIFEST',encoding='utf-8'))['shard_count'])")
DONE=$(find "$RUN_ROOT/workers" -name SHARD_COMPLETE.json | wc -l)
ACTIVE=$(pgrep -af "run_ebook_local_shard.py.*$RUN_ROOT|server_pipeline.py.*$RUN_ROOT" | wc -l || true)
if [[ "$ACTIVE" -ne 0 || "$DONE" -ne "$EXPECTED" ]]; then
  echo "not_ready completed_shards=$DONE/$EXPECTED active_processes=$ACTIVE" >&2
  exit 1
fi

mkdir -p "$MERGED" "$OFFICIAL" "$ARCHIVE_DIR"
"$PY" "$EXTENSION/merge_ebook_full_results.py" \
  --run-root "$RUN_ROOT" \
  --output-dir "$MERGED" \
  --package-dir "$BASE_PACKAGE" \
  --index-manifest "$MANIFEST" \
  --run-clustering \
  --min-support 5 \
  > "$RUN_ROOT/logs/finalize.log" 2>&1
"$PY" "$BASE_PACKAGE/organize_official_results.py" \
  --run-root "$RUN_ROOT" \
  --merged-dir "$MERGED" \
  --official-dir "$OFFICIAL" \
  >> "$RUN_ROOT/logs/finalize.log" 2>&1
"$PY" "$BASE_PACKAGE/audit_results.py" \
  --run-root "$RUN_ROOT" \
  --official-dir "$OFFICIAL" \
  >> "$RUN_ROOT/logs/finalize.log" 2>&1
"$PY" "$EXTENSION/summarize_ebook_full_results.py" \
  --index-dir "$RUN_ROOT/index" \
  --official-dir "$OFFICIAL" \
  >> "$RUN_ROOT/logs/finalize.log" 2>&1

LIST="$RUN_ROOT/ebook_package_file_list.txt"
cd "$RUN_ROOT"
{
  printf '%s\n' \
    official_results \
    run_manifest.json \
    index/execution_manifest.json \
    index/index_build_config.json \
    index/ebook_book_catalog.csv \
    index/ebook_page_candidate_summary.csv \
    index/ebook_formula_candidate_catalog.csv \
    index/candidate_index_all.jsonl \
    index/ebook_pre_ocr_rejected_catalog.csv \
    index/ebook_pre_ocr_rejected_catalog.jsonl \
    index/prefilter_audit \
    index/candidate_images \
    index/rejected_candidate_images \
    logs
  find workers -type f -name SHARD_COMPLETE.json -print | sort
  find workers -type f -name ocr_results.jsonl -print | sort
  find workers -type f -name 'ocr_results.jsonl.stage_manifest.json' -print | sort
  find . -maxdepth 1 -type f -name 'worker_*.complete' -printf '%P\n' | sort
  find . -maxdepth 1 -type f -name 'GPU_AUDIT_APPROVED.sha256' -printf '%P\n'
} > "$LIST"

tar -czf "${ARCHIVE}.part" -T "$LIST"
mv "${ARCHIVE}.part" "$ARCHIVE"
tar -tzf "$ARCHIVE" >/dev/null
echo "finalization_complete official=$OFFICIAL"
echo "archive=$ARCHIVE"
ls -lh "$ARCHIVE"
