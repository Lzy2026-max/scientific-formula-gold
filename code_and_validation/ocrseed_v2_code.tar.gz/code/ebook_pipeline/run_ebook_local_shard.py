#!/usr/bin/env python3
"""OCR and analyze one immutable local-e-book image shard with the frozen package."""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import subprocess
import sys
from pathlib import Path


def read_jsonl(path: Path):
    with path.open(encoding="utf-8-sig", errors="replace") as handle:
        for line in handle:
            if line.strip():
                yield json.loads(line)


def formula_id_digest(rows: list[dict]) -> str:
    value = "\n".join(sorted(str(row.get("formula_id", "")) for row in rows))
    return hashlib.sha256(value.encode("utf-8")).hexdigest()


def enrich_jsonl(path: Path, provenance: dict[str, dict]) -> None:
    if not path.exists():
        return
    temporary = path.with_suffix(path.suffix + ".enriching")
    with temporary.open("w", encoding="utf-8", newline="\n") as out:
        for row in read_jsonl(path):
            source = provenance.get(str(row.get("formula_id", "")), {})
            if source:
                row.update({
                    "source_title": source.get("title", row.get("source_title", "")),
                    "source_file": source.get("source_file", row.get("source_file", "")),
                    "page": source.get("page", row.get("page", "")),
                    "page_number": source.get("page_number", ""),
                    "page_index": source.get("page_index", ""),
                    "locator": source.get("provenance_locator", row.get("locator", "")),
                    "screenshot_path": source.get("image_path", row.get("screenshot_path", "")),
                    "bbox": source.get("candidate_bbox", row.get("bbox", "")),
                    "candidate_number": source.get("candidate_number", ""),
                    "candidate_detection_method": source.get("candidate_detection_method", ""),
                    "candidate_detection_score": source.get("candidate_detection_score", ""),
                    "candidate_text_layer": source.get("candidate_text_layer", ""),
                    "candidate_original_text_layer": source.get(
                        "candidate_original_text_layer", ""
                    ),
                    "candidate_fonts": source.get("candidate_fonts", ""),
                    "equation_number_text_layer": source.get(
                        "equation_number_text_layer", ""
                    ),
                    "context_after_text_layer": source.get("context_after_text_layer", ""),
                    "candidate_context_text_layer": source.get(
                        "candidate_context_text_layer", ""
                    ),
                    "candidate_source_line_count": source.get(
                        "candidate_source_line_count", ""
                    ),
                    "candidate_position_json": source.get(
                        "candidate_position_json", ""
                    ),
                    "pre_ocr_filter_decision": source.get("pre_ocr_filter_decision", ""),
                    "pre_ocr_filter_reason": source.get("pre_ocr_filter_reason", ""),
                    "pre_ocr_filter_score": source.get("pre_ocr_filter_score", ""),
                    "pre_ocr_text_features_json": source.get(
                        "pre_ocr_text_features_json", ""
                    ),
                    "pre_ocr_visual_features_json": source.get(
                        "pre_ocr_visual_features_json", ""
                    ),
                    "book_id": source.get("book_id", ""),
                    "book_sha256": source.get("book_sha256", ""),
                    "authors": source.get("authors", ""),
                    "year": source.get("year", ""),
                    "page_provenance_status": source.get("page_provenance_status", ""),
                    "extraction_method": source.get("extraction_method", row.get("extraction_method", "")),
                })
            out.write(json.dumps(row, ensure_ascii=False) + "\n")
    temporary.replace(path)


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--shard-index", required=True)
    parser.add_argument("--workspace", required=True)
    parser.add_argument("--package-dir", required=True)
    parser.add_argument("--device", default="cuda:0")
    args = parser.parse_args()

    shard_index = Path(args.shard_index).expanduser().resolve()
    workspace = Path(args.workspace).expanduser().resolve()
    package_dir = Path(args.package_dir).expanduser().resolve()
    extension_dir = Path(__file__).resolve().parent
    sys.path.insert(0, str(package_dir))
    from runtime_fingerprint import runtime_versions, sha256_file, static_fingerprint

    workspace.mkdir(parents=True, exist_ok=True)
    candidate_index = workspace / "candidate_index.jsonl"
    extraction_errors = workspace / "extraction_errors.jsonl"
    ocr_path = workspace / "ocr_results.jsonl"
    analysis_dir = workspace / "formula_analysis"
    done_marker = workspace / "SHARD_COMPLETE.json"
    rows = list(read_jsonl(shard_index))
    fingerprint = static_fingerprint(package_dir, shard_index)
    fingerprint["ebook_extension_runner_sha256"] = sha256_file(Path(__file__).resolve())
    input_digest = formula_id_digest(rows)

    if done_marker.exists():
        previous = json.loads(done_marker.read_text(encoding="utf-8"))
        if (
            previous.get("status") == "complete"
            and previous.get("schema_version") == 3
            and previous.get("input_records") == len(rows)
            and previous.get("input_formula_ids_sha256") == input_digest
            and previous.get("fingerprint") == fingerprint
            and previous.get("accounted_records") == len(rows)
        ):
            print(f"shard_already_complete_validated={done_marker}")
            return
        raise SystemExit(
            "Existing SHARD_COMPLETE.json does not match this shard/code. "
            "Use a new run directory or inspect this one shard manually."
        )

    valid_rows = []
    error_rows = []
    for row in rows:
        image_path = Path(str(row.get("image_path", "")))
        if image_path.is_file():
            valid_rows.append(row)
        else:
            error_rows.append({**row, "stage": "local_image_check", "error": "image_path_missing"})
    with candidate_index.open("w", encoding="utf-8", newline="\n") as handle:
        for row in valid_rows:
            handle.write(json.dumps(row, ensure_ascii=False) + "\n")
    with extraction_errors.open("w", encoding="utf-8", newline="\n") as handle:
        for row in error_rows:
            handle.write(json.dumps(row, ensure_ascii=False) + "\n")
    if not valid_rows:
        raise SystemExit("No local candidate images are available in this shard")

    env = os.environ.copy()
    env.update({
        "OMP_NUM_THREADS": "1",
        "MKL_NUM_THREADS": "1",
        "OPENBLAS_NUM_THREADS": "1",
        "NUMEXPR_NUM_THREADS": "1",
        "NO_ALBUMENTATIONS_UPDATE": "1",
    })
    ocr_command = [
        sys.executable,
        str(package_dir / "server_pipeline.py"),
        "ocr",
        "--index",
        str(candidate_index),
        "--out",
        str(ocr_path),
        "--device",
        args.device,
        "--ocr-seed-mode",
        "per_formula_v1",
        "--log-every",
        "100",
    ]
    if ocr_path.exists():
        ocr_command.append("--resume")
    subprocess.run(ocr_command, check=True, env=env)

    analyze_command = [
        sys.executable,
        str(package_dir / "server_pipeline.py"),
        "analyze",
        "--ocr",
        str(ocr_path),
        "--engine",
        str(package_dir / "scripts" / "formula_engine.py"),
        "--out-dir",
        str(analysis_dir),
        "--log-every",
        "200",
    ]
    if (analysis_dir / "analyze_stage_manifest.json").exists():
        analyze_command.append("--resume")
    subprocess.run(analyze_command, check=True, env=env)

    provenance = {str(row["formula_id"]): row for row in valid_rows}
    enrich_jsonl(analysis_dir / "formula_trees.jsonl", provenance)
    enrich_jsonl(analysis_dir / "parse_failures.jsonl", provenance)

    ocr_rows = list(read_jsonl(ocr_path))
    input_ids = {str(row.get("formula_id", "")) for row in rows}
    ocr_ids = {str(row.get("formula_id", "")) for row in ocr_rows}
    error_ids = {str(row.get("formula_id", "")) for row in error_rows}
    if len(input_ids) != len(rows) or "" in input_ids:
        raise SystemExit("Duplicate or empty formula_id in shard index")
    if ocr_ids & error_ids or ocr_ids | error_ids != input_ids:
        raise SystemExit("Shard count conservation failed")
    summary_path = analysis_dir / "analysis_summary.json"
    summary = json.loads(summary_path.read_text(encoding="utf-8"))
    marker = {
        "schema_version": 3,
        "status": "complete",
        "shard_index": str(shard_index),
        "input_records": len(rows),
        "input_formula_ids_sha256": input_digest,
        "extracted": len(valid_rows),
        "extraction_failed": len(error_rows),
        "ocr_records": len(ocr_rows),
        "accounted_records": len(ocr_rows) + len(error_rows),
        "fingerprint": fingerprint,
        "runtime_versions": runtime_versions(),
        "analysis_summary": summary,
        "extension_dir": str(extension_dir),
    }
    done_marker.write_text(json.dumps(marker, ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"shard_complete={done_marker}")


if __name__ == "__main__":
    main()
