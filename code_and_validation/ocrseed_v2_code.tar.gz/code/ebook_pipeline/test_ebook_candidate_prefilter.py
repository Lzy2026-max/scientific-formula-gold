#!/usr/bin/env python3
"""Focused regression tests for the PDF pre-OCR candidate filter."""

from __future__ import annotations

import unittest

import numpy as np
from PIL import Image

from ebook_candidate_prefilter import (
    classify_text_candidate,
    classify_visual_candidate,
    text_features,
)


class TextCandidateTests(unittest.TestCase):
    def assertAccepted(self, text: str, fonts: str = "STIXTwoMath"):
        result = classify_text_candidate(text, fonts)
        self.assertIn(
            result["decision"],
            {"accepted_high_confidence", "accepted_review"},
            result,
        )

    def assertRejected(self, text: str, fonts: str = "TimesNewRoman"):
        result = classify_text_candidate(text, fonts)
        self.assertEqual(result["decision"], "rejected_pre_ocr", result)

    def test_known_valid_equations_are_retained(self):
        values = [
            "f(x) = x + x^2 - x^3",
            "(A+B)^T = A^T + B^T",
            "mu_x|y = mu_x + Sigma_xy Sigma_yy^-1 (y-mu_y)",
            "f(x,y) = 200 x^0.7 y^0.3, where x and y represent the inputs",
            "x(t) = (a-b) cos(t) + b cos((a-b)/b) t",
            "1 + cot^2 theta = csc^2 theta",
            "∫_a^b f(x) dx = F(b)-F(a)",
            "sin(x+y) = sin(x)cos(y)+cos(x)sin(y)",
        ]
        for value in values:
            with self.subTest(value=value):
                self.assertAccepted(value)

    def test_known_boilerplate_is_rejected(self):
        values = [
            "This OpenStax book is available for free at https://openstax.org/",
            "Copyright 2025. All rights reserved.",
            "Chapter 4 Learning Objectives",
            "Download from www.example.com/section/2",
            "The solution manual and powerpoint slides can be obtained online",
            "where x and y represent the two values used in the following example",
            "2026-07-30",
            "Page 414",
        ]
        for value in values:
            with self.subTest(value=value):
                self.assertRejected(value)

    def test_old_core_proxy_with_relation_and_operator_is_retained(self):
        self.assertAccepted(r"\mathrm{~\cal~\cal~4}\qquad\mathcal{M}V=x+2", "")

    def test_latex_arrow_relation_is_retained(self):
        self.assertAccepted(r"\mu_3:8\rightarrow3.7", "")

    def test_short_math_font_text_without_structure_is_rejected(self):
        self.assertRejected("Introduction", "STIXTwoMath")
        self.assertRejected("EXERCISES", "CambriaMath")

    def test_decimal_is_not_misclassified_as_date(self):
        features = text_features("0.052")
        self.assertFalse(features["is_date"], features)

    def test_mathematical_section_sentence_is_not_boilerplate(self):
        features = text_features("In this section, f(x)=x^2+1 for x>0.")
        self.assertFalse(features["has_boilerplate"], features)

    def test_prose_with_inline_math_is_not_sent_to_ocr(self):
        result = classify_text_candidate(
            "The following values x=2 and y=3 are used in this example to "
            "illustrate the relationship between the two variables.",
            "TimesNewRoman",
        )
        self.assertEqual(result["decision"], "rejected_pre_ocr", result)
        self.assertIn(
            result["reason"],
            {"prose_with_inline_math_not_isolated", "long_prose_with_weak_math_evidence"},
        )

    def test_v2_audit_prose_false_positives_are_rejected(self):
        values = [
            (
                "Find a pair of parametric equations that models the graph of "
                "y = 1 − x2, using the parameter x(t) = t. Plot some points."
            ),
            (
                "This result tells us the average rate of change between t=0 "
                "and any other point t=a. For example, consider the following."
            ),
            (
                "Figure 8.18 An electron transition from the n=3 to the n=2 shell."
            ),
        ]
        for value in values:
            with self.subTest(value=value):
                self.assertRejected(value)

    def test_compact_multiple_relations_are_retained(self):
        self.assertAccepted("x=2, y=3, z=x+y", "STIXTwoMath")

    def test_unicode_minus_compact_formula_is_retained(self):
        result = classify_text_candidate("e6−e−7", "STIXTwoMath")
        self.assertIn(
            result["decision"],
            {"accepted_high_confidence", "accepted_review"},
            result,
        )


    def test_source_code_or_console_text_is_rejected(self):
        values = [
            ">>> wave1.corr(wave2)",
            "args = np.outer(ts, fs)",
            "def b(z): return np.exp(z)",
            "n = len(years)",
            "dim=len(M)",
            "curve = []",
            "Cell = Yes",
            'ylab ="MPG")',
        ]
        for value in values:
            with self.subTest(value=value):
                result = classify_text_candidate(value, "TimesNewRoman")
                self.assertEqual(result["decision"], "rejected_pre_ocr", result)
                self.assertEqual(result["reason"], "source_code_or_console_text")

    def test_audit_inline_relation_prose_is_rejected(self):
        value = (
            "Read this as X is a random variable with a Poisson distribution. "
            "The parameter is mu or lambda; mu = the mean for the distribution."
        )
        result = classify_text_candidate(value, "TimesNewRoman")
        self.assertEqual(result["decision"], "rejected_pre_ocr", result)
        self.assertEqual(result["reason"], "prose_with_inline_math_not_isolated")

    def test_collapsed_audit_prose_is_rejected(self):
        values = [
            "sufficienttoguaranteethatNisinreducedrow-echelonform.",
            "characteristicequationhasarepeatedrealrootlambda=-1(step3).",
        ]
        for value in values:
            with self.subTest(value=value):
                result = classify_text_candidate(value, "STIXTwoMath")
                self.assertEqual(result["decision"], "rejected_pre_ocr", result)
                self.assertEqual(
                    result["reason"],
                    "collapsed_prose_with_weak_math_evidence",
                )

    def test_isolated_or_incomplete_fragments_are_rejected(self):
        values = ["θ.", "-1", "M = {", "= (-1)^(1+1)"]
        for value in values:
            with self.subTest(value=value):
                self.assertRejected(value, "STIXTwoMath")

    def test_axis_tick_stack_is_rejected(self):
        result = classify_text_candidate(
            "-10 / -20 / -30",
            "STIXTwoMath",
            merge_reason="compact_vertical_math_stack",
            source_line_count=3,
            visual={"row_bands": 3, "width": 80, "height": 120},
        )
        self.assertEqual(result["decision"], "rejected_pre_ocr", result)
        self.assertEqual(result["reason"], "axis_tick_or_answer_list_stack")

    def test_v32_unicode_axis_stack_is_rejected(self):
        result = classify_text_candidate(
            "− π / − / − 2 / − 4 / − 6 / − 8 / − 10",
            "STIXTwoMath",
            merge_reason="compact_vertical_math_stack",
            source_line_count=7,
            visual={
                "row_bands": 2,
                "width": 125,
                "height": 155,
                "aspect_ratio": 0.806,
                "color_ratio": 0.041,
                "edge_ink_ratio": 0.043,
                "long_horizontal_line_count": 1,
                "long_vertical_line_count": 3,
            },
        )
        self.assertEqual(result["decision"], "rejected_pre_ocr", result)

    def test_v32_colored_graph_label_stack_is_rejected(self):
        result = classify_text_candidate(
            "x − 3 / f ( x − 3) / g ( x )",
            "STIXTwoMath",
            merge_reason="compact_vertical_math_stack",
            source_line_count=3,
            visual={
                "row_bands": 4,
                "width": 132,
                "height": 182,
                "aspect_ratio": 0.725,
                "color_ratio": 0.011,
                "edge_ink_ratio": 0.016,
                "long_horizontal_line_count": 0,
                "long_vertical_line_count": 0,
            },
        )
        self.assertEqual(result["decision"], "rejected_pre_ocr", result)

    def test_v32_weak_nonformula_review_samples_are_rejected(self):
        values = [
            ("Mass (GeV/c^2)", "STIXTwoMath"),
            ("iii. n = ______", "TimesNewRoman"),
            ("wiki/Largest_cities_in_the_United_States_by_population", ""),
            ("eters µk, Σk, πk:", "STIXTwoMath"),
        ]
        for value, fonts in values:
            with self.subTest(value=value):
                self.assertRejected(value, fonts)

    def test_formula_after_exercise_blank_marker_is_retained(self):
        result = classify_text_candidate(
            "___ / 11. tan(7 π / 12)",
            "STIXTwoMath",
            merge_reason="compact_vertical_math_stack",
            source_line_count=2,
            visual={
                "color_ratio": 0.0,
                "edge_ink_ratio": 0.0,
                "long_horizontal_line_count": 0,
                "long_vertical_line_count": 0,
                "aspect_ratio": 3.0,
                "row_bands": 2,
            },
        )
        self.assertIn(
            result["decision"],
            {"accepted_high_confidence", "accepted_review"},
            result,
        )

    def test_v33_answer_field_formula_is_reviewed_but_empty_answer_is_rejected(self):
        formula = classify_text_candidate(
            "31. P ( X < 4 ) = _______",
            "STIXTwoMath",
            source_line_count=1,
            visual={
                "color_ratio": 0.0,
                "edge_ink_ratio": 0.0,
                "long_horizontal_line_count": 0,
                "long_vertical_line_count": 0,
                "aspect_ratio": 6.0,
                "row_bands": 2,
            },
        )
        self.assertEqual(formula["decision"], "accepted_review", formula)
        self.assertEqual(
            formula["reason"],
            "formula_with_answer_field_requires_ocr_review",
        )
        empty_answer = classify_text_candidate("iii. n = ______", "TimesNewRoman")
        self.assertEqual(empty_answer["decision"], "rejected_pre_ocr", empty_answer)

    def test_v33_generic_density_expression_is_retained(self):
        self.assertAccepted("p ( x , y ) d y", "STIXTwoMath")

    def test_v33_clean_coordinate_list_is_reviewed_but_colored_callout_is_rejected(self):
        clean = classify_text_candidate(
            "28. (8, −2) and (4, 6)",
            "STIXTwoMath",
            visual={
                "color_ratio": 0.0,
                "edge_ink_ratio": 0.0,
                "long_horizontal_line_count": 0,
                "long_vertical_line_count": 0,
                "aspect_ratio": 5.0,
                "row_bands": 1,
            },
        )
        self.assertEqual(clean["decision"], "accepted_review", clean)
        colored = classify_text_candidate(
            "(0, −9)",
            "STIXTwoMath",
            visual={
                "color_ratio": 0.083,
                "edge_ink_ratio": 0.023,
                "long_horizontal_line_count": 0,
                "long_vertical_line_count": 2,
                "aspect_ratio": 2.42,
                "row_bands": 2,
            },
        )
        self.assertEqual(colored["decision"], "rejected_pre_ocr", colored)
        self.assertEqual(colored["reason"], "graph_axis_visual_morphology")

    def test_v33_colored_directrix_and_derivative_callouts_are_rejected(self):
        cases = [
            (
                "x = 5 Directrix",
                2,
                {"color_ratio": 0.063, "edge_ink_ratio": 0.018,
                 "long_horizontal_line_count": 0, "long_vertical_line_count": 0,
                 "aspect_ratio": 1.10, "row_bands": 5},
            ),
            (
                "∂t",
                1,
                {"color_ratio": 0.108, "edge_ink_ratio": 0.345,
                 "long_horizontal_line_count": 7, "long_vertical_line_count": 0,
                 "aspect_ratio": 1.48, "row_bands": 6},
            ),
        ]
        for text, line_count, visual in cases:
            with self.subTest(text=text):
                result = classify_text_candidate(
                    text,
                    "STIXTwoMath",
                    source_line_count=line_count,
                    visual=visual,
                )
                self.assertEqual(result["decision"], "rejected_pre_ocr", result)

    def test_v33_numeric_axis_stack_is_rejected_outside_compact_merge_reason(self):
        result = classify_text_candidate(
            "– 5 / – 4 / – 3 / – 2 / – 1 / – 2 / – 4",
            "STIXTwoMath",
            merge_reason="adjacent_text_fragments",
            source_line_count=7,
            visual={
                "color_ratio": 0.0,
                "edge_ink_ratio": 0.048,
                "long_horizontal_line_count": 2,
                "long_vertical_line_count": 2,
                "aspect_ratio": 2.0,
                "row_bands": 8,
            },
        )
        self.assertEqual(result["decision"], "rejected_pre_ocr", result)

    def test_clean_short_formulas_are_retained_without_graph_artifacts(self):
        cases = [
            ("27. (4 p + 9) 2", 1),
            ("3 / 2", 2),
            ("φ 0 .", 1),
            ("78. [−100,100]", 1),
            ("4 \ue02a . / 3 \ue02a .", 2),
        ]
        clean_visual = {
            "color_ratio": 0.0,
            "edge_ink_ratio": 0.0,
            "long_horizontal_line_count": 0,
            "long_vertical_line_count": 0,
            "aspect_ratio": 3.0,
            "row_bands": 1,
        }
        for value, line_count in cases:
            with self.subTest(value=value):
                result = classify_text_candidate(
                    value,
                    "STIXTwoMath",
                    merge_reason=(
                        "compact_vertical_math_stack"
                        if line_count > 1
                        else "single_text_line"
                    ),
                    source_line_count=line_count,
                    visual=clean_visual,
                )
                self.assertIn(
                    result["decision"],
                    {"accepted_high_confidence", "accepted_review"},
                    result,
                )

    def test_graph_labels_do_not_enter_clean_short_formula_rescue(self):
        graph_visual = {
            "color_ratio": 0.03,
            "edge_ink_ratio": 0.05,
            "long_horizontal_line_count": 1,
            "long_vertical_line_count": 3,
            "aspect_ratio": 1.0,
            "row_bands": 3,
        }
        for value in ("−π", "(0, −c)", "x − 2", "(−4,5)"):
            with self.subTest(value=value):
                result = classify_text_candidate(
                    value,
                    "STIXTwoMath",
                    merge_reason="single_text_line",
                    source_line_count=1,
                    visual=graph_visual,
                )
                self.assertEqual(result["decision"], "rejected_pre_ocr", result)

    def test_prompt_and_incomplete_matrix_edge_are_rejected(self):
        prompt = classify_text_candidate(
            "n = 4 state?",
            "STIXTwoMath",
            merge_reason="single_text_line",
            source_line_count=1,
            visual={
                "color_ratio": 0.0,
                "edge_ink_ratio": 0.10,
                "long_horizontal_line_count": 0,
                "long_vertical_line_count": 0,
                "aspect_ratio": 3.0,
                "row_bands": 2,
            },
        )
        self.assertEqual(prompt["decision"], "rejected_pre_ocr", prompt)
        matrix_edge = classify_text_candidate(
            "\uf8f9 / \uf8fb = B",
            "STIXTwoMath",
            merge_reason="compact_vertical_math_stack",
            source_line_count=2,
            visual={
                "color_ratio": 0.009,
                "edge_ink_ratio": 0.02,
                "long_horizontal_line_count": 0,
                "long_vertical_line_count": 0,
                "aspect_ratio": 0.52,
                "row_bands": 6,
            },
        )
        self.assertEqual(matrix_edge["decision"], "rejected_pre_ocr", matrix_edge)

    def test_glyph_encoded_matrix_edge_without_entries_is_rejected(self):
        result = classify_text_candidate(
            "\uf8ee / A = / \uf8ef\uf8ef\uf8f0",
            "STIXTwoMath",
            merge_reason="compact_vertical_math_stack",
            source_line_count=4,
            visual={
                "color_ratio": 0.0,
                "edge_ink_ratio": 0.02,
                "long_horizontal_line_count": 0,
                "long_vertical_line_count": 0,
                "aspect_ratio": 0.60,
                "row_bands": 6,
            },
        )
        self.assertEqual(result["decision"], "rejected_pre_ocr", result)
        self.assertEqual(result["reason"], "incomplete_matrix_edge_fragment")

    def test_unresolved_leading_relation_continuation_is_rejected(self):
        for value in (
            "= 6 t − 4.",
            "= 1 / 4 ∫ (1 + cos θ) 4 sin θ dθ",
            "= 2(−5) − 5(2) − 1(−1)",
        ):
            with self.subTest(value=value):
                result = classify_text_candidate(value, "STIXTwoMath")
                self.assertEqual(result["decision"], "rejected_pre_ocr", result)
                self.assertEqual(
                    result["reason"],
                    "incomplete_relation_or_delimiter_fragment",
                )

    def test_trailing_open_relation_remains_rejected(self):
        result = classify_text_candidate("14. a 1 = 8, r =", "STIXTwoMath")
        self.assertEqual(result["decision"], "rejected_pre_ocr", result)

    def test_fill_blank_rule_keeps_equations_not_plain_answer_fields(self):
        reviewed = classify_text_candidate(
            "1 − 378 / _____ / _____ / 1,001 = 623 / 1,001",
            "STIXTwoMath",
        )
        self.assertEqual(reviewed["decision"], "accepted_review", reviewed)
        plain = classify_text_candidate("x = _______", "TimesNewRoman")
        self.assertEqual(plain["decision"], "rejected_pre_ocr", plain)
        prose = classify_text_candidate(
            "Calculate the following central limit value X = _______",
            "TimesNewRoman",
        )
        self.assertEqual(prose["decision"], "rejected_pre_ocr", prose)

    def test_descriptive_math_labels_are_not_functions(self):
        for value in ("rank-k approximation", "quantum of radiation, Δ E :"):
            with self.subTest(value=value):
                result = classify_text_candidate(value, "STIXTwoMath")
                self.assertEqual(result["decision"], "rejected_pre_ocr", result)

    def test_single_function_below_ruling_is_rejected_as_fragment(self):
        result = classify_text_candidate(
            "sin θ",
            "STIXTwoMath",
            merge_reason="single_text_line",
            source_line_count=1,
            visual={
                "color_ratio": 0.0,
                "edge_ink_ratio": 0.28,
                "long_horizontal_line_count": 4,
                "long_vertical_line_count": 0,
                "aspect_ratio": 1.44,
                "row_bands": 3,
            },
        )
        self.assertEqual(result["decision"], "rejected_pre_ocr", result)

    def test_review_branch_keeps_compact_formula_expressions(self):
        for value in ("Z ∼ N(µ, σ^2/n)", "ρ_B(u)", "(h−|2p|, k+p)", "5π/4"):
            with self.subTest(value=value):
                self.assertAccepted(value, "STIXTwoMath")

    def test_matrix_stack_is_not_rejected_as_axis(self):
        result = classify_text_candidate(
            "[ 1 / 2 / 3 ]",
            "STIXTwoMath",
            merge_reason="compact_vertical_math_stack",
            source_line_count=3,
            visual={"row_bands": 3, "width": 80, "height": 120},
        )
        self.assertNotEqual(result["reason"], "axis_tick_or_answer_list_stack")

    def test_v34_audit_url_fragment_is_rejected(self):
        result = classify_text_candidate(
            "org/details/rhapblue11924",
            "STIXTwoMath",
        )
        self.assertEqual(result["decision"], "rejected_pre_ocr", result)
        self.assertEqual(result["reason"], "url_or_book_boilerplate")

    def test_v34_fraction_bar_artifacts_keep_formula_block_for_review(self):
        result = classify_text_candidate(
            "sin 2 t = 1 − 144 ___ 169; sin 2 t = 25 ___ 169; "
            "sin t = ± 5 ___ 13",
            "STIXTwoMath",
            source_line_count=8,
        )
        self.assertEqual(result["decision"], "accepted_review", result)
        self.assertEqual(
            result["reason"],
            "formula_with_answer_field_requires_ocr_review",
        )

    def test_v34_colored_complete_relation_is_reviewed_not_deleted(self):
        result = classify_text_candidate(
            "f ( x ) = − 6 sec ( 4 x + 2 ) − 8",
            "STIXTwoMath",
            source_line_count=1,
            visual={
                "color_ratio": 0.04,
                "edge_ink_ratio": 0.16,
                "long_horizontal_line_count": 1,
                "long_vertical_line_count": 1,
                "aspect_ratio": 3.2,
                "row_bands": 3,
            },
        )
        self.assertEqual(result["decision"], "accepted_review", result)
        self.assertEqual(
            result["reason"],
            "graph_ambiguous_structured_formula_requires_ocr_review",
        )

    def test_v34_axis_stack_with_equation_is_reviewed(self):
        result = classify_text_candidate(
            "− 4 / − 2 / x / (b) M = 1",
            "STIXTwoMath",
            source_line_count=4,
            visual={"row_bands": 5, "width": 100, "height": 180},
        )
        self.assertEqual(result["decision"], "accepted_review", result)
        self.assertEqual(
            result["reason"],
            "axis_ambiguous_structured_formula_requires_ocr_review",
        )

    def test_v34_multiline_formula_block_with_trailing_relation_is_reviewed(self):
        result = classify_text_candidate(
            "47. − 0.01 x + 0.12 y = 0.15; "
            "50. − 0.71 x + 0.92 y = 0.83 x + 0.05 y =",
            "STIXTwoMath",
            source_line_count=4,
        )
        self.assertEqual(result["decision"], "accepted_review", result)
        self.assertEqual(
            result["reason"],
            "structured_formula_boundary_requires_ocr_review",
        )

    def test_v34_compact_function_without_relation_is_reviewed(self):
        result = classify_text_candidate("Q ( x , y )", "STIXTwoMath")
        self.assertEqual(result["decision"], "accepted_review", result)
        self.assertEqual(
            result["reason"],
            "structured_formula_requires_downstream_review",
        )


class VisualCandidateTests(unittest.TestCase):
    def test_blank_region_rejected(self):
        image = Image.new("RGB", (300, 50), "white")
        result = classify_visual_candidate(image, "embedded_image_region")
        self.assertEqual(result["decision"], "rejected_pre_ocr")

    def test_colored_figure_rejected(self):
        data = np.zeros((100, 200, 3), dtype=np.uint8)
        data[:, :, 0] = 220
        data[:, :, 1] = 30
        data[:, :, 2] = 40
        result = classify_visual_candidate(
            Image.fromarray(data),
            "embedded_image_region",
        )
        self.assertEqual(result["decision"], "rejected_pre_ocr")

    def test_compact_formula_like_raster_band_is_bounded_review(self):
        data = np.full((27, 169), 255, dtype=np.uint8)
        for column in (10, 27, 44, 61, 78, 95, 112, 129, 146):
            data[5:23, column:column + 3] = 0
        image = Image.fromarray(data, mode="L").convert("RGB")
        result = classify_visual_candidate(
            image,
            "raster_high_recall_scanned_page",
        )
        self.assertEqual(result["decision"], "accepted_review", result)
        self.assertEqual(result["reason"], "raster_formula_candidate_requires_ocr_review")

    def test_morphology_only_prose_band_is_rejected(self):
        data = np.full((43, 208), 255, dtype=np.uint8)
        data[14:31, 12:196] = 0
        result = classify_visual_candidate(
            Image.fromarray(data, mode="L").convert("RGB"),
            "raster_high_recall_scanned_page",
        )
        self.assertEqual(result["decision"], "rejected_pre_ocr", result)

    def test_embedded_figure_caption_context_is_rejected(self):
        data = np.full((55, 320), 255, dtype=np.uint8)
        data[20:24, 20:250] = 0
        result = classify_visual_candidate(
            Image.fromarray(data, mode="L").convert("RGB"),
            "embedded_image_region",
            context_text="Figure 4.2 Graph of the response curve",
        )
        self.assertEqual(result["decision"], "rejected_pre_ocr", result)
        self.assertEqual(result["reason"], "embedded_figure_caption_context")

    def test_raster_page_header_is_rejected_by_position(self):
        data = np.full((45, 320), 255, dtype=np.uint8)
        data[18:23, 20:280] = 0
        result = classify_visual_candidate(
            Image.fromarray(data, mode="L").convert("RGB"),
            "raster_high_recall_scanned_page",
            position={"center_y_ratio": 0.03},
        )
        self.assertEqual(result["decision"], "rejected_pre_ocr", result)
        self.assertEqual(result["reason"], "page_header_footer_region")

    def test_embedded_band_without_isolated_text_is_rejected(self):
        data = np.full((55, 320), 255, dtype=np.uint8)
        data[20:24, 20:80] = 0
        data[12:39, 90:94] = 0
        data[25:29, 110:210] = 0
        result = classify_visual_candidate(
            Image.fromarray(data, mode="L").convert("RGB"),
            "embedded_image_region",
            context_text="where x denotes the input variable",
            position={"center_y_ratio": 0.5},
        )
        self.assertEqual(result["decision"], "rejected_pre_ocr", result)
        self.assertEqual(
            result["reason"],
            "embedded_image_without_isolated_formula_text",
        )

    def test_wide_grid_table_is_rejected(self):
        data = np.full((120, 600), 255, dtype=np.uint8)
        for row in (15, 45, 75, 105):
            data[row:row + 2, 10:590] = 0
        for column in (20, 160, 300, 440, 580):
            data[10:110, column:column + 2] = 0
        result = classify_visual_candidate(
            Image.fromarray(data, mode="L").convert("RGB"),
            "embedded_image_region",
        )
        self.assertEqual(result["decision"], "rejected_pre_ocr", result)
        self.assertEqual(result["reason"], "wide_grid_or_table_graphic")


    def test_raster_wide_header_is_rejected(self):
        data = np.full((40, 900), 255, dtype=np.uint8)
        data[17:21, 5:895] = 0
        result = classify_visual_candidate(
            Image.fromarray(data, mode="L").convert("RGB"),
            "raster_high_recall_scanned_page",
            position={"center_y_ratio": 0.5},
        )
        self.assertEqual(result["decision"], "rejected_pre_ocr", result)


if __name__ == "__main__":
    unittest.main(verbosity=2)
