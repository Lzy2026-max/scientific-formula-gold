# Formula Extraction and Analysis Pipeline for 30 E-books

This repository contains the code for indexing formula candidates from PDF books, reviewing the pre-OCR filter, running GPU-based OCR and formula analysis, and merging the results.

## What is included

- `ebook_pipeline/`: PDF page indexing, candidate filtering and audit, sharded OCR workers, result merging, monitoring, and finalization.
- `common/formula_kb_production/`: shared OCR, formula parsing/classification, and result-audit modules used by the book pipeline.
- `run_ebook30.sh`: command-line entry point, including an interactive full-run mode.
- `requirements.txt`: Python packages used by the pipeline. PyTorch must be installed separately with a CUDA build compatible with the host.

## Requirements

- Linux with Bash
- Python 3.10 (the production environment used Python 3.10.20)
- NVIDIA GPU and a working NVIDIA driver for OCR; PDF indexing and prefilter review can run before GPU processing
- CUDA-compatible PyTorch, installed according to the host's CUDA/driver setup
- The Python packages in `requirements.txt`

Create an environment and install the Python packages:

```bash
python3 -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip
# Install a CUDA-compatible PyTorch build for this host first.
python -m pip install -r requirements.txt
```

## Quick start

The simplest entry is the interactive full run. It verifies the input count, builds the PDF index and audit samples, then pauses for a human review before starting any GPU workers:

```bash
GPU_IDS=0 bash run_ebook30.sh full /path/to/pdf_directory /path/to/results 2026102801
```

The input directory must contain exactly 30 PDF files. The default is one worker on physical GPU 0. To configure multiple workers, pass one GPU index per worker, for example:

```bash
GPU_IDS=0,0,1 bash run_ebook30.sh full /path/to/pdf_directory /path/to/results 2026102801
```

For servers where a GPU must not be used, list its physical index in `FORBIDDEN_GPU_IDS`:

```bash
GPU_IDS=0,1 FORBIDDEN_GPU_IDS=2 bash run_ebook30.sh full /path/to/pdf_directory /path/to/results 2026102801
```

`full` does not bypass the audit gate: it prints the audit summary and sample location, and proceeds only if the operator reviews the samples and types `APPROVE`.

## Separate stages

The same workflow can be run stage by stage:

```bash
# Check dependencies, GPU visibility, and that there are exactly 30 PDFs
bash run_ebook30.sh check /path/to/pdf_directory

# Build the index and pre-OCR audit; this does not start GPU workers
bash run_ebook30.sh index /path/to/pdf_directory /path/to/results 2026102801

# Print the audit summary and sample location
bash run_ebook30.sh review /path/to/results 2026102801

# Run only after inspecting the audit samples
bash run_ebook30.sh approve /path/to/results 2026102801
bash run_ebook30.sh gpu /path/to/pdf_directory /path/to/results 2026102801

# Check progress, then finalize after every shard is complete
bash run_ebook30.sh monitor /path/to/results 2026102801
bash run_ebook30.sh finalize /path/to/results 2026102801
```

The run directory is named `ebook30_ocrseed_v2_seed<SEED>` under the selected results directory. This isolated variant seeds PyTorch separately for each `formula_id` and each primary/enhanced OCR pass, and requests deterministic PyTorch kernels. The original ZIP and its run directories are not modified. The `SEED` argument still controls indexing; OCR seeds are derived from the stable formula IDs.

This is an experimental stability change, not a verified OCR accuracy improvement. Test the same fixed candidate images in two fresh run directories before processing all 30 books. Compare `formula_latex`, `ocr_variant_latex`, `ocr_quality_status`, formula trees and core eligibility by `formula_id`. If a deterministic PyTorch operation is unsupported, the OCR worker stops rather than silently writing an empty result. The final audit archive now also includes each shard's `ocr_results.jsonl` and stage manifest; these may contain source text and are internal audit material, not a ready-to-publish data package.

Finalization writes merged and official outputs there and creates a distinct audit archive under `results/archives/`. The resulting counts are a new version and must be recomputed; the original report counts are not preserved by design.

## Tests

Run the PDF-pipeline unit tests:

```bash
cd ebook_pipeline
python -m unittest discover -p 'test_*.py' -v
```

The tests cover PDF indexing, candidate prefiltering, and merge validation. They do not require starting GPU workers.

Run the shared formula-core tests from that component's root:

```bash
cd common/formula_kb_production
PYTHONPATH=. python -m unittest discover -s tests -p 'test_*.py' -v
```

These tests cover formula-tree semantics, classification policies, and merge-marker validation.

## Notes

- GPU IDs are physical host IDs as reported by `nvidia-smi`; adjust `GPU_IDS` for the target server.
- First-time OCR model setup may require network access, depending on the installed OCR package and its model cache.
- The exact numerical throughput depends on the GPU, driver, PyTorch/CUDA build, and worker configuration.
