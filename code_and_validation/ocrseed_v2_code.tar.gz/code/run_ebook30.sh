#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
BASE_PACKAGE="$ROOT/common/formula_kb_production"
EXTENSION="$ROOT/ebook_pipeline"
PYTHON_BIN="${PYTHON:-python3}"
PYTHON_BIN="$(command -v "$PYTHON_BIN" || true)"
if [[ -z "$PYTHON_BIN" ]]; then
  echo "Python 3 not found. Set PYTHON=/absolute/path/to/python." >&2
  exit 2
fi
export PROJECT="$ROOT" BASE_PACKAGE EXTENSION PY="$PYTHON_BIN"
export GPU_IDS="${GPU_IDS:-0}"
export FORBIDDEN_GPU_IDS="${FORBIDDEN_GPU_IDS:-}"

usage() {
  cat <<'EOF'
30 本电子书公式处理入口

用法：
  bash run_ebook30.sh check PDF_ROOT
  bash run_ebook30.sh full PDF_ROOT RESULT_PARENT [SEED]
  bash run_ebook30.sh index PDF_ROOT RESULT_PARENT [SEED]
  bash run_ebook30.sh review RESULT_PARENT [SEED]
  bash run_ebook30.sh approve RESULT_PARENT [SEED]
  bash run_ebook30.sh gpu PDF_ROOT RESULT_PARENT [SEED]
  bash run_ebook30.sh monitor RESULT_PARENT [SEED]
  bash run_ebook30.sh finalize RESULT_PARENT [SEED]

full 会先建索引并生成预筛选审计样本，等待人工查看并确认后才启动 GPU。
GPU_IDS 支持一个或多个物理 GPU 编号，例如 GPU_IDS=0 或 GPU_IDS=0,0,1。
EOF
}

run_root() {
  local result_parent="$1" seed="$2"
  printf '%s/ebook30_ocrseed_v2_seed%s' "$result_parent" "$seed"
}

run_index() {
  local pdf_root="$1" result_parent="$2" seed="$3"
  PROJECT="$ROOT" BASE_PACKAGE="$BASE_PACKAGE" EXTENSION="$EXTENSION" \
  PY="$PYTHON_BIN" EBOOK_ROOT="$pdf_root" RESULT_PARENT="$result_parent" \
  GPU_IDS="$GPU_IDS" FORBIDDEN_GPU_IDS="$FORBIDDEN_GPU_IDS" \
  INDEX_ONLY=1 GPU_APPROVED=0 bash "$EXTENSION/start_ebook_full.sh" "$seed"
}

mode="${1:-}"
case "$mode" in
  check)
    pdf_root="${2:?Provide PDF_ROOT}"
    [[ -d "$pdf_root" ]] || { echo "PDF directory not found: $pdf_root" >&2; exit 2; }
    count="$(find "$pdf_root" -type f -iname '*.pdf' | wc -l | tr -d ' ')"
    echo "pdf_count=$count"
    [[ "$count" == 30 ]] || { echo "Expected exactly 30 PDF files." >&2; exit 2; }
    "$PYTHON_BIN" -c 'import fitz, numpy, PIL, torch; print("PyMuPDF=", fitz.VersionBind); print("NumPy=", numpy.__version__); print("Pillow=", PIL.__version__); print("PyTorch=", torch.__version__); print("CUDA available=", torch.cuda.is_available())'
    nvidia-smi --query-gpu=index,name,memory.total --format=csv
    ;;
  index)
    pdf_root="${2:?Provide PDF_ROOT}"; result_parent="${3:?Provide RESULT_PARENT}"
    run_index "$pdf_root" "$result_parent" "${4:-2026081001}"
    ;;
  review)
    result_parent="${2:?Provide RESULT_PARENT}"; seed="${3:-2026081001}"
    rr="$(run_root "$result_parent" "$seed")"
    [[ -f "$rr/index/prefilter_audit/prefilter_audit_summary.json" ]] || { echo "Audit summary missing: $rr" >&2; exit 2; }
    cat "$rr/index/prefilter_audit/prefilter_audit_summary.json"
    echo "Review the sample files here: $rr/index/prefilter_audit/samples"
    ;;
  approve)
    result_parent="${2:?Provide RESULT_PARENT}"; seed="${3:-2026081001}"
    rr="$(run_root "$result_parent" "$seed")"
    fp="$rr/index/prefilter_audit/prefilter_audit_fingerprint.sha256"
    [[ -f "$fp" ]] || { echo "Audit fingerprint missing: $fp" >&2; exit 2; }
    cp "$fp" "$rr/GPU_AUDIT_APPROVED.sha256"
    cmp -s "$fp" "$rr/GPU_AUDIT_APPROVED.sha256"
    echo "Audit approval recorded: $rr/GPU_AUDIT_APPROVED.sha256"
    ;;
  gpu)
    pdf_root="${2:?Provide PDF_ROOT}"; result_parent="${3:?Provide RESULT_PARENT}"; seed="${4:-2026081001}"
    PROJECT="$ROOT" BASE_PACKAGE="$BASE_PACKAGE" EXTENSION="$EXTENSION" \
    PY="$PYTHON_BIN" EBOOK_ROOT="$pdf_root" RESULT_PARENT="$result_parent" \
    GPU_IDS="$GPU_IDS" FORBIDDEN_GPU_IDS="$FORBIDDEN_GPU_IDS" \
    INDEX_ONLY=0 GPU_APPROVED=1 bash "$EXTENSION/start_ebook_full.sh" "$seed"
    ;;
  full)
    pdf_root="${2:?Provide PDF_ROOT}"; result_parent="${3:?Provide RESULT_PARENT}"; seed="${4:-2026081001}"
    "$0" check "$pdf_root"
    run_index "$pdf_root" "$result_parent" "$seed"
    rr="$(run_root "$result_parent" "$seed")"
    echo
    echo "Index and audit samples are ready. Inspect: $rr/index/prefilter_audit/samples"
    echo "Audit summary: $rr/index/prefilter_audit/prefilter_audit_summary.json"
    read -r -p "After reviewing the samples, type APPROVE to start GPU processing: " answer
    [[ "$answer" == "APPROVE" ]] || { echo "Stopped before GPU processing; no approval was recorded."; exit 0; }
    "$0" approve "$result_parent" "$seed"
    "$0" gpu "$pdf_root" "$result_parent" "$seed"
    echo "GPU workers launched. Use: $0 monitor '$result_parent' '$seed'"
    echo "When all shards complete, use: $0 finalize '$result_parent' '$seed'"
    ;;
  monitor)
    result_parent="${2:?Provide RESULT_PARENT}"; seed="${3:-2026081001}"
    bash "$EXTENSION/monitor_ebook_full.sh" "$(run_root "$result_parent" "$seed")"
    ;;
  finalize)
    result_parent="${2:?Provide RESULT_PARENT}"; seed="${3:-2026081001}"
    PROJECT="$ROOT" BASE_PACKAGE="$BASE_PACKAGE" EXTENSION="$EXTENSION" \
    PY="$PYTHON_BIN" RESULT_PARENT="$result_parent" \
    bash "$EXTENSION/finalize_ebook_full.sh" "$seed"
    ;;
  -h|--help|help|'') usage ;;
  *) echo "Unknown command: $mode" >&2; usage >&2; exit 2 ;;
esac
